"""
EthOS — Storage Manager Blueprint
Drive mounting/unmounting, file sharing (Samba, NFS, DLNA, WebDAV, SFTP),
WS-Discovery (wsdd), USB hotplug monitoring, network drive mounts.
"""

import json
import logging
import os
import re
import subprocess
import base64
import time
import threading
import sys
from flask import Blueprint, jsonify, request, Response, stream_with_context

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from host import host_run as _host_run_base, host_run_stream as _host_run_stream_base, data_path, q as _q_imported, apt_install as _apt_install, claim_dep, release_dep, ufw_allow, ufw_delete, get_data_disk as _get_data_disk
from utils import fmt_bytes, require_tools, check_tool
from blueprints.admin_required import admin_required

storage_bp = Blueprint('storage', __name__, url_prefix='/api/storage')

# ---------------------------------------------------------------------------
# USB hotplug monitor
# ---------------------------------------------------------------------------

_socketio = None
_usb_events = []          # recent USB plug/unplug events for notifications
_USB_EVENT_TTL = 300       # keep events for 5 minutes

# ---------------------------------------------------------------------------
# Keep-alive: auto-remount & USB anti-suspend
# ---------------------------------------------------------------------------

_KEEPALIVE_FILE = data_path('keepalive.json')
_keepalive_drives = {}     # dev_name → {mountpoint, fstype, label, disk}


def _load_keepalive():
    """Load keep-alive config from disk."""
    global _keepalive_drives
    try:
        with open(_KEEPALIVE_FILE, 'r') as f:
            _keepalive_drives = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        _keepalive_drives = {}


def _save_keepalive():
    """Persist keep-alive config to disk."""
    try:
        os.makedirs(os.path.dirname(_KEEPALIVE_FILE), exist_ok=True)
        with open(_KEEPALIVE_FILE, 'w') as f:
            json.dump(_keepalive_drives, f, indent=2)
    except Exception as e:
        print(f'[keepalive] save error: {e}')


def _disable_usb_autosuspend(dev_name):
    """Disable USB autosuspend for the physical disk so the kernel won't power it down."""
    # Find the parent disk (e.g. sda for sda1)
    r = host_run(f"lsblk -ndo PKNAME /dev/{dev_name} 2>/dev/null")
    disk = r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else dev_name
    # Walk sysfs to find the usb device node
    cmds = (
        # Method 1: set autosuspend via the block device's usb ancestor
        f"devpath=$(readlink -f /sys/block/{disk}/device); "
        f"while [ \"$devpath\" != \"/sys\" ] && [ -n \"$devpath\" ]; do "
        f"  if [ -f \"$devpath/power/autosuspend\" ]; then "
        f"    echo -1 > \"$devpath/power/autosuspend\" 2>/dev/null; "
        f"    echo -1 > \"$devpath/power/autosuspend_delay_ms\" 2>/dev/null; "
        f"    echo on > \"$devpath/power/control\" 2>/dev/null; "
        f"    echo on > \"$devpath/power/level\" 2>/dev/null; "
        f"    break; "
        f"  fi; "
        f"  devpath=$(dirname \"$devpath\"); "
        f"done"
    )
    host_run(cmds, timeout=10)


def keepalive_loop(sio):
    """Background greenlet: periodically check pinned drives and re-mount if needed."""
    import gevent
    _load_keepalive()
    print(f'[keepalive] Started — watching {len(_keepalive_drives)} drive(s)')

    while True:
        gevent.sleep(30)
        if not _keepalive_drives:
            continue
        try:
            for dev_name, info in list(_keepalive_drives.items()):
                mp = info.get('mountpoint', '')
                if not mp:
                    continue

                # Check if device exists
                dev_check = host_run(f"test -b /dev/{dev_name} && echo ok", timeout=5)
                if 'ok' not in (dev_check.stdout or ''):
                    # Device not present (physically disconnected) — skip
                    continue

                # Check if already mounted at correct path
                mnt_check = host_run(
                    f"findmnt -n -o TARGET /dev/{dev_name} 2>/dev/null", timeout=5
                )
                current_mp = mnt_check.stdout.strip() if mnt_check.returncode == 0 else ''

                if current_mp == mp:
                    # Mounted correctly — just keep USB awake
                    _disable_usb_autosuspend(dev_name)
                    continue

                # Drive present but not mounted at expected path → re-mount
                ok = _remount_keepalive_drive(dev_name, info)
                if ok and sio:
                    sio.emit('drive_remounted', {
                        'dev': dev_name, 'mountpoint': mp,
                        'label': info.get('label', dev_name),
                    })
        except Exception as e:
            print(f'[keepalive] error: {e}')


def _remount_keepalive_drive(dev_name, info):
    """Try to remount a keepalive drive.  Returns True on success."""
    mp = info.get('mountpoint', '')
    if not mp:
        return False

    # Check if device exists
    dev_check = host_run(f"test -b /dev/{dev_name} && echo ok", timeout=5)
    if 'ok' not in (dev_check.stdout or ''):
        return False

    # Already mounted at correct path?
    mnt_check = host_run(f"findmnt -n -o TARGET /dev/{dev_name} 2>/dev/null", timeout=5)
    current_mp = mnt_check.stdout.strip() if mnt_check.returncode == 0 else ''
    if current_mp == mp:
        _disable_usb_autosuspend(dev_name)
        return True

    print(f'[keepalive] Re-mounting /dev/{dev_name} → {mp}')
    fstype = info.get('fstype', 'auto')

    # Run quick fsck on ext filesystems before remounting
    if fstype in ('ext4', 'ext3', 'ext2'):
        print(f'[keepalive] Running e2fsck -p on /dev/{dev_name}')
        fsck_r = host_run(f'e2fsck -p /dev/{dev_name} 2>&1', timeout=300)
        if fsck_r.returncode in (0, 1):
            print(f'[keepalive] e2fsck OK (code {fsck_r.returncode})')
        else:
            print(f'[keepalive] e2fsck warning (code {fsck_r.returncode}): {fsck_r.stdout.strip()[:200]}')

    if fstype in ('ntfs', 'ntfs3'):
        fstype = 'ntfs-3g'

    uid_r = host_run('id -u', timeout=5)
    gid_r = host_run('id -g', timeout=5)
    uid = uid_r.stdout.strip() or '1000'
    gid = gid_r.stdout.strip() or '1000'

    if fstype == 'ntfs-3g':
        opts = f'rw,uid={uid},gid={gid},umask=000,nofail,remove_hiberfile'
    elif fstype in ('vfat', 'exfat'):
        opts = f'rw,uid={uid},gid={gid},umask=000,nofail'
    elif fstype in ('ext4', 'ext3', 'ext2', 'xfs', 'btrfs'):
        opts = 'defaults,nofail'
    else:
        opts = 'rw,nofail'

    host_run(f'umount /dev/{dev_name} 2>/dev/null || true', timeout=10)
    host_run(f'mkdir -p {Q(mp)}', timeout=5)

    if fstype == 'ntfs-3g':
        r = host_run(f'mount -t ntfs-3g -o {opts} /dev/{dev_name} {Q(mp)}', timeout=15)
    else:
        r = host_run(f'mount -t {fstype} -o {opts} /dev/{dev_name} {Q(mp)}', timeout=15)

    if r.returncode == 0:
        print(f'[keepalive] ✓ Remounted /dev/{dev_name} → {mp}')
        _disable_usb_autosuspend(dev_name)
        return True
    else:
        print(f'[keepalive] ✗ Failed to remount /dev/{dev_name}: {r.stderr.strip()}')
        return False


def try_wake_path(host_path):
    """If *host_path* lives under a keepalive drive that is currently
    unmounted, try to remount it.  Called from the file-manager listing.
    Also sends a lightweight read to wake a sleeping USB disk.
    *host_path* is the real host path (e.g. /media/devmon/4TB-external/…).
    Returns True if a remount was performed (or not needed), False on failure."""
    if not _keepalive_drives:
        return False

    for dev_name, info in _keepalive_drives.items():
        mp = info.get('mountpoint', '')
        if not mp:
            continue
        # Check if requested path is under this mountpoint
        if host_path == mp or host_path.startswith(mp + '/'):
            # First: poke the disk with a lightweight stat to wake from standby
            host_run(f"stat {Q(mp)} >/dev/null 2>&1", timeout=15)
            # Then check if still actually mounted
            mnt_check = host_run(f"findmnt -n -o TARGET {Q(mp)} 2>/dev/null", timeout=10)
            if mnt_check.returncode == 0 and mnt_check.stdout.strip() == mp:
                _disable_usb_autosuspend(dev_name)
                return True
            # Not mounted → remount
            return _remount_keepalive_drive(dev_name, info)
    return False


def init_storage(sio):
    """Initialize the storage blueprint with Socket.IO for USB monitoring."""
    global _socketio
    _socketio = sio
    _load_keepalive()
    sio.start_background_task(_health_monitor_loop)
    sio.start_background_task(_auto_mount_network_drives)


def get_usb_notifications():
    """Return active USB hotplug notification items."""
    now = time.time()
    active = [e for e in _usb_events if now - e['time'] < _USB_EVENT_TTL]
    _usb_events[:] = active
    return list(active)


def _usb_label_for_device(dev_name):
    """Get filesystem label for a device like 'sdc2' via lsblk on the host."""
    try:
        r = host_run(f"lsblk -no LABEL,SIZE,FSTYPE /dev/{dev_name} 2>/dev/null", timeout=5)
        if r.returncode == 0 and r.stdout.strip():
            parts = r.stdout.strip().split()
            label = parts[0] if parts else dev_name
            size = parts[1] if len(parts) > 1 else ''
            fstype = parts[2] if len(parts) > 2 else ''
            return label or dev_name, size, fstype
    except Exception:
        pass
    return dev_name, '', ''


def usb_monitor_loop(sio):
    """Background greenlet: watch /proc/partitions for USB block device changes."""
    import gevent
    known = set()
    # Track dev→mountpoint so we can clean up stale dirs on removal
    _dev_mounts = {}   # dev_name → mountpoint path

    def _current_usb_parts():
        """Return set of (dev_name,) for USB partitions from lsblk."""
        parts = set()
        try:
            r = host_run(
                "lsblk -Jno NAME,TRAN,TYPE,RM,MOUNTPOINT 2>/dev/null",
                timeout=10
            )
            if r.returncode == 0 and r.stdout.strip():
                data = json.loads(r.stdout)
                for dev in data.get('blockdevices', []):
                    is_usb = dev.get('tran') == 'usb' or dev.get('rm')
                    if is_usb:
                        children = dev.get('children', [])
                        if children:
                            for ch in children:
                                if ch.get('type') == 'part':
                                    parts.add(ch['name'])
                                    mp = ch.get('mountpoint')
                                    if mp:
                                        _dev_mounts[ch['name']] = mp
                        else:
                            if dev.get('type') in ('disk', 'part'):
                                parts.add(dev['name'])
                                mp = dev.get('mountpoint')
                                if mp:
                                    _dev_mounts[dev['name']] = mp
        except Exception:
            pass
        return parts

    def _cleanup_stale_mountpoint(dev_name):
        """Force-unmount stale mountpoint and remove the empty directory."""
        mp = _dev_mounts.pop(dev_name, None)
        if not mp:
            return
        # Lazy unmount in case kernel still holds a ref
        host_run(f"umount -l {_shell_quote(mp)} 2>/dev/null", timeout=5)
        # Remove the empty directory so devmon doesn't create -2 suffixes
        host_run(f"rmdir {_shell_quote(mp)} 2>/dev/null", timeout=5)

    def _cleanup_all_stale_devmon():
        """Remove any /media/devmon/* dirs that are not active mountpoints."""
        try:
            r = host_run(
                "for d in /media/devmon/*/; do "
                "  mountpoint -q \"$d\" 2>/dev/null || "
                "  { rmdir \"$d\" 2>/dev/null && echo \"removed:$d\"; }; "
                "done",
                timeout=10
            )
        except Exception:
            pass

    # Initial snapshot
    known = _current_usb_parts()
    # Clean any stale dirs from before we started
    _cleanup_all_stale_devmon()

    while True:
        gevent.sleep(10)  # was 3s — 10s sufficient for USB hot-plug detection
        try:
            current = _current_usb_parts()
            added = current - known
            removed = known - current

            for dev_name in added:
                label, size, fstype = _usb_label_for_device(dev_name)
                size_str = f" ({size})" if size else ""
                evt = {
                    'type': 'success',
                    'title': 'USB connected',
                    'message': f'{label}{size_str} — /dev/{dev_name}',
                    'time': time.time(),
                    'action': {'app': 'storage'},
                    'dev': dev_name,
                    'label': label,
                }
                _usb_events.append(evt)
                sio.emit('usb_connected', {
                    'dev': dev_name, 'label': label,
                    'size': size, 'fstype': fstype,
                })

            for dev_name in removed:
                label = _dev_mounts.get(dev_name, '').split('/')[-1] or dev_name
                # Clean up stale mountpoint BEFORE notifying
                _cleanup_stale_mountpoint(dev_name)
                evt = {
                    'type': 'warning',
                    'title': 'USB disconnected',
                    'message': f'{label} (/dev/{dev_name})',
                    'time': time.time(),
                    'dev': dev_name,
                }
                _usb_events.append(evt)
                sio.emit('usb_disconnected', {'dev': dev_name, 'label': label})

            # Periodic cleanup of any stale dirs (safety net)
            if removed:
                gevent.sleep(2)
                _cleanup_all_stale_devmon()

            known = current
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Helpers – execute on the HOST via nsenter
# ---------------------------------------------------------------------------

def host_run(cmd, timeout=30):
    return _host_run_base(cmd, timeout=timeout)


def host_run_stream(cmd):
    return _host_run_stream_base(cmd)


def _shell_quote(s):
    return _q_imported(s)

Q = _shell_quote


def _host_write_json(filepath, data):
    """Safely write a JSON object to a file on the host.
    Uses base64 encoding to avoid any shell/quote injection."""
    raw = json.dumps(data).encode('utf-8')
    b64 = base64.b64encode(raw).decode('ascii')
    host_run(f"echo '{b64}' | base64 -d > {_shell_quote(filepath)}")


def _host_write_script(filepath, script_text):
    """Safely write a Python script to the host using heredoc with single-quoted delimiter."""
    host_run(f"cat > {_shell_quote(filepath)} << 'PYSCRIPT_EOF_MARKER'\n" + script_text + "\nPYSCRIPT_EOF_MARKER")


def _host_write_file(filepath, content):
    """Safely write text content to a file on the host using base64."""
    raw = content.encode('utf-8')
    b64 = base64.b64encode(raw).decode('ascii')
    host_run(f"echo '{b64}' | base64 -d > {_shell_quote(filepath)}")


def _sanitize_mount_path(path):
    parts = path.rsplit('/', 1)
    if len(parts) == 2:
        dirname, basename = parts
        basename = re.sub(r'[^\w.\-]', '_', basename)
        basename = re.sub(r'_+', '_', basename).strip('_')
        return f"{dirname}/{basename}"
    return path


def _validate_drive_name(name):
    """Validate drive name to prevent command injection.
    Accepts: sda, sda1, nvme0n1, nvme0n1p1, mmcblk0p1, etc."""
    if not name:
        return False
    return bool(re.match(r'^[a-zA-Z0-9]+$', name))


def _validate_disk_name(name):
    """Validate base disk name (no partition number).
    Accepts: sda, sdb, nvme0n1, mmcblk0, etc."""
    if not name:
        return False
    return bool(re.match(r'^[a-zA-Z]+$', name) or re.match(r'^nvme\d+n\d+$', name) or re.match(r'^mmcblk\d+$', name))


def _is_system_disk(disk_name):
    """Robust check whether a disk is used by the system.
    Checks root, /boot, /home, swap, and LVM PVs."""
    # 1. Check root device
    r = host_run("findmnt -n -o SOURCE / 2>/dev/null")
    root_dev = r.stdout.strip() if r.returncode == 0 else ""

    # For LVM: root_dev might be /dev/mapper/vg-root or /dev/dm-0
    # Resolve to physical disk via lsblk
    if root_dev:
        # Direct match: /dev/sda1 on root, checking sda
        if f"/dev/{disk_name}" in root_dev or root_dev.startswith(f"/dev/{disk_name}"):
            return True
        # LVM/dm resolution: find which physical disk backs root
        pkdev_r = host_run(f"lsblk -nso NAME,TYPE /dev/{disk_name} 2>/dev/null")
        if pkdev_r.returncode == 0:
            for line in pkdev_r.stdout.strip().splitlines():
                parts = line.split()
                if len(parts) >= 1:
                    child_dev = f"/dev/{parts[0]}"
                    if child_dev in root_dev or root_dev.startswith(child_dev):
                        return True

    # 2. Check critical mount points
    for mp in ('/', '/boot', '/boot/efi', '/home', '/var', '/usr'):
        r2 = host_run(f"findmnt -n -o SOURCE {Q(mp)} 2>/dev/null")
        if r2.returncode == 0 and r2.stdout.strip():
            src = r2.stdout.strip()
            if f"/dev/{disk_name}" in src or src.startswith(f"/dev/{disk_name}"):
                return True

    # 3. Check swap
    r3 = host_run("cat /proc/swaps 2>/dev/null")
    if r3.returncode == 0:
        for line in r3.stdout.strip().splitlines()[1:]:
            if f"/dev/{disk_name}" in line or f"/{disk_name}" in line:
                return True

    return False


# fstab management removed — USB drives are auto-mounted by devmon


# ---------------------------------------------------------------------------
# API – Keep-alive
# ---------------------------------------------------------------------------

@storage_bp.route('/keepalive')
def list_keepalive():
    """Return the set of drives with keep-alive enabled."""
    return jsonify({'drives': _keepalive_drives})


@storage_bp.route('/keepalive', methods=['POST'])
def toggle_keepalive():
    """Toggle keep-alive for a drive.  Body: {drive, mountpoint?, fstype?, label?, enable}."""
    data = request.json or {}
    dev_name = data.get('drive', '').strip()
    enable = data.get('enable', True)

    if not dev_name or not _validate_drive_name(dev_name):
        return jsonify({'error': 'Invalid device name'}), 400

    if enable:
        mp = data.get('mountpoint', '').strip()
        if not mp:
            return jsonify({'error': 'Mountpoint required'}), 400
        _keepalive_drives[dev_name] = {
            'mountpoint': mp,
            'fstype': data.get('fstype', 'auto'),
            'label': data.get('label', dev_name),
            'disk': data.get('disk', ''),
        }
        _save_keepalive()
        # Immediately disable USB autosuspend
        _disable_usb_autosuspend(dev_name)
        print(f'[keepalive] Enabled for /dev/{dev_name} → {mp}')
        return jsonify({'success': True, 'enabled': True, 'drive': dev_name})
    else:
        _keepalive_drives.pop(dev_name, None)
        _save_keepalive()
        print(f'[keepalive] Disabled for /dev/{dev_name}')
        return jsonify({'success': True, 'enabled': False, 'drive': dev_name})


# ---------------------------------------------------------------------------
# API – Drives
# ---------------------------------------------------------------------------

_drives_cache = {'data': None, 'ts': 0}
_DRIVES_CACHE_TTL = 10  # seconds

def _invalidate_drives_cache():
    _drives_cache['ts'] = 0

@storage_bp.route('/drives')
def list_drives():
    """List block devices with useful info (including main system disk)."""
    now = time.time()
    if _drives_cache['data'] is not None and now - _drives_cache['ts'] < _DRIVES_CACHE_TTL:
        return jsonify(_drives_cache['data'])
    r = host_run(
        "lsblk -J -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT,LABEL,MODEL,TRAN,UUID,HOTPLUG"
    )
    if r.returncode != 0:
        return jsonify({"error": r.stderr.strip()}), 500

    try:
        data = json.loads(r.stdout)
    except json.JSONDecodeError:
        return jsonify({"error": "Failed to parse lsblk output"}), 500



    # Collect SMART temperature (quick check, cached per-disk)
    smart_temps = {}
    smart_health = {}
    smart_r = host_run(
        "for d in /dev/sd? /dev/nvme?n?; do "
        "[ -b \"$d\" ] && smartctl -A -H \"$d\" 2>/dev/null | "
        "awk -v dev=\"$d\" '"
        "/Temperature_Celsius|Airflow_Temperature/{print dev\"\ttemp\t\"$10} "
        "/^Temperature:/{for(i=1;i<=NF;i++){if($i+0==$i && $i>0){print dev\"\ttemp\t\"$i; break}}} "
        "/SMART overall-health/{print dev\"\thealth\t\"$NF} "
        "'; done",
        timeout=10
    )
    if smart_r.returncode == 0:
        for line in smart_r.stdout.strip().splitlines():
            cols = line.split('\t')
            if len(cols) >= 3:
                dname = cols[0].replace('/dev/', '')
                if cols[1] == 'temp':
                    try:
                        smart_temps[dname] = int(cols[2])
                    except ValueError:
                        pass
                elif cols[1] == 'health':
                    smart_health[dname] = cols[2]

    # Collect df info for disk usage
    df_map = {}
    dfr = host_run("df -B1 --output=source,size,used,avail,pcent,target 2>/dev/null")
    if dfr.returncode == 0:
        for line in dfr.stdout.strip().split('\n')[1:]:
            parts = line.split()
            if len(parts) >= 6:
                mp = parts[-1]
                try:
                    df_map[mp] = {
                        'total': int(parts[1]),
                        'used': int(parts[2]),
                        'free': int(parts[3]),
                        'percent': float(parts[4].replace('%', '')),
                    }
                except (ValueError, IndexError):
                    pass

    drives = []
    _SKIP = {'loop', 'rom'}

    def _collect(dev, parent_info=None):
        dtype = dev.get('type', '')
        name = dev.get('name', '')
        if dtype in _SKIP or name.startswith(('loop', 'nbd', 'zram')):
            return

        children = dev.get('children', [])
        # Recurse into children (partitions, LVM, etc.)
        for child in children:
            _collect(child, parent_info=parent_info or dev)

        # Only include partitions, LVMs, and whole-disk with fs
        if dtype not in ('part', 'lvm', 'disk'):
            return
        # For parent disks with children: include as a summary entry
        if dtype == 'disk' and children:
            child_names = [c.get('name', '') for c in children if c.get('type') in ('part', 'lvm')]
            p = parent_info or dev
            tran = p.get('tran') or dev.get('tran') or ''
            hotplug = p.get('hotplug') or dev.get('hotplug')
            is_usb = tran == 'usb' or hotplug == '1' or hotplug is True
            model = p.get('model') or dev.get('model') or ''
            mp = dev.get('mountpoint')
            category = 'usb' if is_usb else ('system' if mp == '/' or (mp and mp.startswith('/boot')) else 'storage')
            drives.append({
                'name': name,
                'size': dev.get('size'),
                'type': 'disk',
                'fstype': dev.get('fstype'),
                'mountpoint': mp,
                'label': dev.get('label'),
                'model': model.strip() if model else None,
                'uuid': dev.get('uuid'),
                'parent': None,
                'tran': tran,
                'category': category,
                'usage': None,
                'smart_temp': smart_temps.get(name),
                'smart_health': smart_health.get(name),
                'children': child_names,
                'children_count': len(child_names),
            })
            return

        fstype = dev.get('fstype')
        mountpoint = dev.get('mountpoint')

        # Determine transport / category
        p = parent_info or dev
        tran = p.get('tran') or dev.get('tran') or ''
        hotplug = p.get('hotplug') or dev.get('hotplug')
        is_usb = tran == 'usb' or hotplug == '1' or hotplug is True
        model = p.get('model') or dev.get('model') or ''

        # Determine category
        if is_usb:
            category = 'usb'
        elif tran in ('nvme', 'sata', 'ata', 'scsi', '') and dtype == 'lvm':
            category = 'system'
        elif mountpoint == '/':
            category = 'system'
        elif mountpoint and mountpoint.startswith('/boot'):
            category = 'system'
        else:
            category = 'storage'

        usage = df_map.get(mountpoint) if mountpoint else None

        dev_uuid = dev.get('uuid')

        # SMART temp from parent disk
        parent_name = (parent_info or {}).get('name', '')
        temp = smart_temps.get(parent_name) or smart_temps.get(name)
        health = smart_health.get(parent_name) or smart_health.get(name)

        drives.append({
            'name': name,
            'size': dev.get('size'),
            'type': dtype,
            'fstype': fstype,
            'mountpoint': mountpoint,
            'label': dev.get('label'),
            'model': model.strip() if model else None,
            'uuid': dev_uuid,
            'parent': parent_name or None,
            'tran': tran,
            'category': category,
            'usage': usage,
            'smart_temp': temp,
            'smart_health': health,
        })

    for dev in data.get('blockdevices', []):
        _collect(dev)

    result = {'drives': drives}
    _drives_cache['data'] = result
    _drives_cache['ts'] = time.time()
    return jsonify(result)


# USB auto-mount is handled by devmon; fstab entries are reserved for network mounts only


@storage_bp.route('/mount', methods=['POST'])
def mount_drive():
    """Mount a drive to a specified path."""
    data = request.json or {}
    drive_name = data.get("drive", "").strip()
    mount_path = data.get("path", "").strip()

    if not drive_name or not mount_path:
        return jsonify({"error": "drive and path are required"}), 400

    # Validate drive name to prevent command injection
    if not _validate_drive_name(drive_name):
        return jsonify({"error": "Invalid device name"}), 400
    if not mount_path.startswith('/'):
        return jsonify({"error": "path must be absolute"}), 400
    if '..' in mount_path:
        return jsonify({"error": "Path cannot contain '..'"}), 400

    mount_path = _sanitize_mount_path(mount_path)

    r = host_run(f"lsblk -no FSTYPE /dev/{drive_name}")
    fstype = r.stdout.strip() or "auto"

    if fstype in ("ntfs", "ntfs3"):
        fstype = "ntfs-3g"

    uid_r = host_run("id -u")
    gid_r = host_run("id -g")
    uid = uid_r.stdout.strip() or "1000"
    gid = gid_r.stdout.strip() or "1000"

    if fstype == "ntfs-3g":
        mount_opts = f"rw,uid={uid},gid={gid},umask=000,nofail,remove_hiberfile"
    elif fstype in ("vfat", "exfat"):
        mount_opts = f"rw,uid={uid},gid={gid},umask=000,nofail"
    elif fstype in ("ext4", "ext3", "ext2"):
        mount_opts = "defaults,nofail,noatime,commit=60"
    elif fstype in ("xfs", "btrfs"):
        mount_opts = "defaults,nofail,noatime"
    else:
        mount_opts = "rw,nofail"

    uuid_r = host_run(f"lsblk -no UUID /dev/{drive_name}")
    uuid = uuid_r.stdout.strip()

    host_run(f"umount /dev/{drive_name} 2>/dev/null || true")
    host_run(f"mkdir -p {Q(mount_path)}")

    if fstype == "ntfs-3g":
        r = host_run(f"mount -t ntfs-3g -o {mount_opts} /dev/{drive_name} {Q(mount_path)}")
    else:
        r = host_run(f"mount {Q(mount_path)}")
    if r.returncode != 0:
        r = host_run(f"mount -t {fstype} -o {mount_opts} /dev/{drive_name} {Q(mount_path)}")
        if r.returncode != 0:
            return jsonify({"error": f"Mount failed: {r.stderr.strip()}"}), 500

    if fstype in ("ext4", "ext3", "ext2", "xfs", "btrfs"):
        host_run(f"chmod 0777 {Q(mount_path)}")
        host_run(f"chown {uid}:{gid} {Q(mount_path)}")

    auto_mount = data.get("auto_mount", False)
    # USB auto-mount at boot is handled by devmon; fstab entries are reserved for network mounts

    _invalidate_drives_cache()
    return jsonify({
        "success": True,
        "device": f"/dev/{drive_name}",
        "mountpoint": mount_path,
        "fstype": fstype,
        "auto_mount": bool(auto_mount and uuid),
    })


def _fstab_add(uuid, mount_path, fstype, opts):
    """Add a UUID-based fstab entry with nofail. Idempotent."""
    fstab = host_run("cat /etc/fstab").stdout or ""
    marker = f"# ethos-auto:{mount_path}"
    if marker in fstab or f"UUID={uuid}" in fstab:
        return
    line = f"UUID={uuid}  {mount_path}  {fstype}  {opts}  0  2  {marker}\n"
    host_run(f"echo {Q(line)} >> /etc/fstab")


def _fstab_remove(mount_path):
    """Remove ethos-auto fstab entries for a mount point."""
    escaped = mount_path.replace('/', '\\/')
    marker = f"# ethos-auto:{escaped}"
    host_run(f"sed -i '/{marker}/d' /etc/fstab 2>/dev/null || true")


@storage_bp.route('/auto-mount', methods=['POST'])
def toggle_auto_mount():
    """Enable/disable auto-mount on boot for a drive."""
    data = request.json or {}
    mount_path = data.get("path", "").strip()
    enable = data.get("enable", True)
    if not mount_path:
        return jsonify({"error": "path required"}), 400

    # USB auto-mount at boot is handled by devmon; fstab is reserved for network mounts
    return jsonify({"ok": True, "auto_mount": enable, "note": "USB auto-mount is managed by devmon"})


@storage_bp.route('/unmount', methods=['POST'])
def unmount_drive():
    """Unmount a drive."""
    data = request.json or {}
    mount_path = data.get("path")
    if not mount_path:
        return jsonify({"error": "path is required"}), 400

    check = host_run(f"findmnt -n -o SOURCE {Q(mount_path)}")
    is_mounted = check.returncode == 0 and check.stdout.strip() != ""

    if is_mounted:
        loop_dev = None
        src = check.stdout.strip()
        if src.startswith("/dev/loop"):
            loop_dev = src

        r = host_run(f"umount {Q(mount_path)}")
        if r.returncode != 0:
            r = host_run(f"umount -l {Q(mount_path)}")
            if r.returncode != 0:
                return jsonify({"error": f"Unmount failed: {r.stderr.strip()}"}), 500

        if loop_dev:
            host_run(f"losetup -d {loop_dev} 2>/dev/null || true")

    return jsonify({"success": True, "mountpoint": mount_path})


@storage_bp.route('/eject', methods=['POST'])
def eject_drive():
    """Safely eject a USB drive: unmount all partitions, then power-off the device."""
    data = request.json or {}
    disk_name = data.get("disk", "").strip()

    if not disk_name:
        return jsonify({"error": "disk is required"}), 400
    if not _validate_disk_name(disk_name):
        return jsonify({"error": "Invalid disk name"}), 400

    dev_path = f"/dev/{disk_name}"

    # Verify it's a USB device
    r = host_run(f"lsblk -ndo TRAN,HOTPLUG {dev_path} 2>/dev/null")
    if r.returncode != 0:
        return jsonify({"error": f"Device {dev_path} does not exist"}), 404
    parts = r.stdout.strip().split()
    tran = parts[0] if parts else ''
    hotplug = parts[1] if len(parts) > 1 else '0'
    if tran != 'usb' and hotplug != '1':
        return jsonify({"error": "Not a USB device"}), 400

    # Unmount all partitions
    r = host_run(f"lsblk -nlo NAME,MOUNTPOINT {dev_path} 2>/dev/null")
    unmounted = []
    if r.returncode == 0:
        for line in r.stdout.strip().splitlines():
            cols = line.split(None, 1)
            if len(cols) >= 2 and cols[1].strip():
                mp = cols[1].strip()
                ur = host_run(f"umount {Q(mp)}")
                if ur.returncode != 0:
                    host_run(f"umount -l {Q(mp)}")
                unmounted.append(mp)

    # Sync filesystem
    host_run("sync")

    # Power off the USB device via udisksctl or kernel sysfs
    r = host_run(f"udisksctl power-off -b {dev_path} 2>/dev/null")
    if r.returncode != 0:
        # Fallback: remove device via sysfs
        host_run(f"echo 1 > /sys/block/{disk_name}/device/delete 2>/dev/null")

    _invalidate_drives_cache()
    return jsonify({
        "success": True,
        "disk": disk_name,
        "unmounted": unmounted,
        "message": "Disk safely ejected",
    })


@storage_bp.route('/smart')
def smart_info():
    """Get SMART info for a specific disk."""
    err = require_tools('smartctl')
    if err:
        return err
    disk_name = request.args.get('disk', '').strip()
    if not disk_name or not _validate_disk_name(disk_name):
        return jsonify({"error": "Invalid disk name"}), 400

    dev_path = f"/dev/{disk_name}"
    r = host_run(f"smartctl -A -H -i {dev_path} 2>/dev/null", timeout=15)

    info = {'disk': disk_name, 'available': False}

    if r.returncode in (0, 4):  # 4 = some SMART data available but device has errors
        info['available'] = True
        info['raw'] = r.stdout

        # Parse health
        for line in r.stdout.splitlines():
            if 'SMART overall-health' in line:
                info['health'] = line.split(':')[-1].strip()
            elif 'Temperature_Celsius' in line or 'Airflow_Temperature' in line:
                parts = line.split()
                if len(parts) >= 10:
                    try:
                        info['temperature'] = int(parts[9])
                    except ValueError:
                        pass
            elif line.startswith('Temperature:') and 'temperature' not in info:
                # NVMe format: "Temperature:                        43 Celsius"
                parts = line.split()
                for p in parts[1:]:
                    try:
                        info['temperature'] = int(p)
                        break
                    except ValueError:
                        continue
            elif 'Power_On_Hours' in line:
                parts = line.split()
                if len(parts) >= 10:
                    try:
                        info['power_on_hours'] = int(parts[9])
                    except ValueError:
                        pass
            elif 'Reallocated_Sector_Ct' in line:
                parts = line.split()
                if len(parts) >= 10:
                    try:
                        info['reallocated_sectors'] = int(parts[9])
                    except ValueError:
                        pass
            elif 'Model Family' in line or 'Device Model' in line or 'Model Number' in line:
                info['model'] = line.split(':')[-1].strip()
            elif 'Serial Number' in line:
                info['serial'] = line.split(':')[-1].strip()
            elif 'Firmware Version' in line:
                info['firmware'] = line.split(':')[-1].strip()

    return jsonify(info)


# ---------------------------------------------------------------------------
# API – Samba
# ---------------------------------------------------------------------------

def _detect_lan_subnet():
    """Detect the primary LAN subnet (e.g. '192.168.1.0/24') from the default route interface."""
    try:
        r = host_run("ip -4 route show default 2>/dev/null | awk '{print $5}' | head -1")
        iface = r.stdout.strip()
        if not iface:
            return '192.168.0.0/16'
        r2 = host_run(f"ip -4 -o addr show {Q(iface)} 2>/dev/null | awk '{{print $4}}' | head -1")
        cidr = r2.stdout.strip()
        if '/' not in cidr:
            return '192.168.0.0/16'
        import ipaddress
        net = ipaddress.ip_network(cidr, strict=False)
        return str(net)
    except Exception:
        return '192.168.0.0/16'


def _detect_lan_interfaces():
    """Return space-separated list of physical LAN interface names (excluding docker/veth)."""
    try:
        r = host_run("ip -4 -o addr show scope global | awk '{print $2}' | grep -v '^docker\\|^br-\\|^veth' | sort -u")
        ifaces = [i.strip() for i in r.stdout.strip().split('\n') if i.strip()]
        return ' '.join(ifaces) if ifaces else 'eth0'
    except Exception:
        return 'eth0'


def _detect_primary_user():
    """Return the primary non-root user and group for Samba force user/group."""
    try:
        r = host_run("awk -F: '$3 >= 1000 && $3 < 60000 {print $1; exit}' /etc/passwd")
        user = r.stdout.strip()
        if user:
            r2 = host_run(f"id -gn {Q(user)}")
            group = r2.stdout.strip() or user
            return user, group
    except Exception:
        pass
    return 'nobody', 'nogroup'


@storage_bp.route('/samba/status')
def samba_status():
    r = host_run("command -v smbd")
    installed = r.returncode == 0
    running = False
    if installed:
        r2 = host_run("systemctl is-active smbd 2>/dev/null || systemctl is-active smb 2>/dev/null")
        running = "active" in r2.stdout.strip()
    return jsonify({"installed": installed, "running": running})


@storage_bp.route('/samba/install', methods=['POST'])
@admin_required
def samba_install():
    r = host_run("command -v smbd")
    if r.returncode == 0:
        return jsonify({"status": "ok", "installed": True}), 200

    subnet = _detect_lan_subnet()
    ifaces = _detect_lan_interfaces()

    def generate():
        install_script = f"""
export DEBIAN_FRONTEND=noninteractive
echo '::STEP::Repairing package manager...'
dpkg --configure -a 2>/dev/null || true
echo '::STEP::Updating package lists...'
apt-get update -y 2>&1
echo '::STEP::Installing Samba...'
apt-get install -y samba samba-common-bin smbclient 2>&1
echo '::STEP::Configuring Samba...'
if [ ! -f /etc/samba/smb.conf ] || ! grep -q 'map to guest' /etc/samba/smb.conf 2>/dev/null; then
  cat > /etc/samba/smb.conf << 'SMBEOF'
[global]
    workgroup = WORKGROUP
    server string = EthOS NAS
    security = user
    map to guest = Bad User
    guest account = nobody
    server min protocol = SMB3
    server signing = mandatory
    smb encrypt = if_required
    interfaces = 127.0.0.0/8 {ifaces}
    bind interfaces only = yes
    hosts allow = 127.0.0.1 {subnet}
    hosts deny = 0.0.0.0/0
    log file = /var/log/samba/log.%m
    max log size = 1000
    logging = file
    log level = 2 auth:3
    dns proxy = no
    unix extensions = yes
    wide links = no
    follow symlinks = no
    load printers = no
    printing = bsd
    printcap name = /dev/null
    disable spoolss = yes

    # Performance tuning
    socket options = TCP_NODELAY IPTOS_LOWDELAY
    read raw = yes
    write raw = yes
    use sendfile = yes
    aio read size = 16384
    aio write size = 16384
    dead time = 15
SMBEOF
fi
echo '::STEP::Enabling Samba services...'
systemctl unmask smbd nmbd 2>/dev/null || true
systemctl enable smbd nmbd 2>/dev/null || true
systemctl start smbd nmbd 2>/dev/null || true
echo '::STEP::Samba installation complete!'
echo '::DONE::'
"""
        for line in host_run_stream(install_script):
            line = line.rstrip("\n")
            if line.startswith("__EXIT_CODE__:"):
                code = line.split(":")[1]
                yield f"data: {json.dumps({'type': 'exit', 'code': int(code)})}\n\n"
            elif line.startswith("::STEP::"):
                yield f"data: {json.dumps({'type': 'step', 'message': line[8:]})}\n\n"
            elif line.startswith("::DONE::"):
                yield f"data: {json.dumps({'type': 'done'})}\n\n"
            else:
                yield f"data: {json.dumps({'type': 'log', 'message': line})}\n\n"

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@storage_bp.route('/samba/shares')
def samba_shares():
    r = host_run("cat /etc/samba/smb.conf 2>/dev/null || echo ''")
    shares = []
    current_share = None

    for line in r.stdout.splitlines():
        line = line.strip()
        match = re.match(r"^\[(.+)\]$", line)
        if match:
            name = match.group(1)
            if name.lower() != "global":
                current_share = {"name": name, "path": "", "writable": False, "guest_ok": False}
                shares.append(current_share)
            else:
                current_share = None
            continue
        if current_share and "=" in line:
            key, val = line.split("=", 1)
            key = key.strip().lower().replace(" ", "_")
            val = val.strip()
            if key == "path":
                current_share["path"] = val
            elif key in ("writable", "writeable"):
                current_share["writable"] = val.lower() == "yes"
            elif key == "guest_ok":
                current_share["guest_ok"] = val.lower() == "yes"

    return jsonify(shares)


@storage_bp.route('/samba/share', methods=['POST'])
@admin_required
def samba_share_add():
    # Check if Samba is installed first
    r_smb = host_run("command -v smbd")
    if r_smb.returncode != 0:
        return jsonify({"error": "Samba is not installed. Install it first in Disks → Samba."}), 400

    data = request.json or {}
    share_name = data.get("name", "").strip()
    share_path = data.get("path", "").strip()
    guest_ok = data.get("guest_ok", False)

    if not share_name or not share_path:
        return jsonify({"error": "name and path are required"}), 400

    # Validate share name: alphanumeric, hyphens, underscores, spaces only
    if not re.match(r'^[a-zA-Z0-9][a-zA-Z0-9 _\-]{0,63}$', share_name):
        return jsonify({"error": "Share name may only contain letters, numbers, spaces, - and _"}), 400

    # Validate share path: must be absolute, no traversal, no suspicious chars
    if not share_path.startswith('/'):
        return jsonify({"error": "Path must be absolute (start with /)"}), 400
    if '..' in share_path:
        return jsonify({"error": "Path cannot contain '..'"}), 400
    # Block sharing critical system directories
    _BLOCKED_PATHS = ('/', '/etc', '/proc', '/sys', '/dev', '/boot', '/root',
                       '/bin', '/sbin', '/usr', '/lib', '/lib64', '/var')
    norm_share = share_path.rstrip('/')
    if norm_share in _BLOCKED_PATHS or not norm_share:
        return jsonify({"error": f"Cannot share system path: {share_path}"}), 403

    uid_r = host_run("id -un")
    user = uid_r.stdout.strip() or "nobody"
    gid_r = host_run("id -gn")
    group = gid_r.stdout.strip() or "nogroup"
    # Service runs as root — detect the actual primary user
    if user == "root":
        user, group = _detect_primary_user()

    writable = data.get("writable", True)
    guest_str = "yes" if guest_ok else "no"
    writable_str = "yes" if writable else "no"

    # Use safe temp-file approach to avoid shell/Python injection
    subnet = _detect_lan_subnet()
    ifaces = _detect_lan_interfaces()
    share_conf = {
        "name": share_name,
        "path": share_path,
        "guest_ok": guest_str,
        "writable": writable_str,
        "user": user,
        "group": group,
        "subnet": subnet,
        "ifaces": ifaces,
    }
    script = """import json, re
NL = chr(10)
params = json.loads(open('/tmp/_samba_params.json').read())
name = params['name']
path = params['path']
guest = params['guest_ok']
user = params['user']
group = params['group']
subnet = params['subnet']
ifaces = params.get('ifaces', 'eth0')
try:
    conf = open('/etc/samba/smb.conf').read()
except FileNotFoundError:
    conf = ''

# Ensure [global] section has required settings
GLOBAL_DEFAULTS = {
    'workgroup': 'WORKGROUP',
    'server string': 'EthOS NAS',
    'security': 'user',
    'map to guest': 'Bad User',
    'guest account': 'nobody',
    'server min protocol': 'SMB3',
    'server signing': 'mandatory',
    'smb encrypt': 'if_required',
    'dns proxy': 'no',
    'interfaces': f'127.0.0.0/8 {ifaces}',
    'bind interfaces only': 'yes',
    'hosts allow': f'127.0.0.1 {subnet}',
    'hosts deny': '0.0.0.0/0',
}
if '[global]' not in conf:
    header = '[global]' + NL
    for k, v in GLOBAL_DEFAULTS.items():
        header += f'    {k} = {v}' + NL
    conf = header + NL + conf
else:
    # Inject missing keys into existing [global]
    gstart = conf.index('[global]')
    # Find end of global: next section or end of file
    next_bracket = conf.find(NL + '[', gstart + 8)
    gend = next_bracket + 1 if next_bracket != -1 else len(conf)
    global_block = conf[gstart:gend]
    additions = ''
    for k, v in GLOBAL_DEFAULTS.items():
        if k not in global_block.lower():
            additions += f'    {k} = {v}' + NL
    if additions:
        insert_pos = conf.index(NL, gstart) + 1
        conf = conf[:insert_pos] + additions + conf[insert_pos:]

# Update guest/interface settings in existing global (use [^\\n]+ to match full value)
conf = re.sub(r'(?im)^(\\s*map to guest\\s*=\\s*).*$', r'\\1Bad User', conf)
conf = re.sub(r'(?im)^(\\s*interfaces\\s*=\\s*).*$', f'\\\\1127.0.0.0/8 {ifaces}', conf)
conf = re.sub(r'(?im)^(\\s*smb encrypt\\s*=\\s*).*$', r'\\1if_required', conf)

pattern = r'\\[' + re.escape(name) + r'\\][^\\[]*'
conf = re.sub(pattern, '', conf, flags=re.IGNORECASE)
conf = conf.rstrip() + NL + NL
block = f'[{name}]' + NL
block += f'    path = {path}' + NL
writable = params['writable']
read_only = 'no' if writable == 'yes' else 'yes'
block += '    browseable = yes' + NL
block += f'    writable = {writable}' + NL
block += f'    read only = {read_only}' + NL
block += f'    guest ok = {guest}' + NL
block += f'    force user = {user}' + NL
block += f'    force group = {group}' + NL
block += '    create mask = 0664' + NL
block += '    directory mask = 0775' + NL
open('/etc/samba/smb.conf', 'w').write(conf + block)

# Ensure share path exists
import os
os.makedirs(path, mode=0o775, exist_ok=True)
"""
    _host_write_json('/tmp/_samba_params.json', share_conf)
    _host_write_script('/tmp/_samba_edit.py', script)
    r = host_run("python3 /tmp/_samba_edit.py")
    host_run("rm -f /tmp/_samba_edit.py /tmp/_samba_params.json 2>/dev/null")

    if r.returncode != 0:
        return jsonify({"error": f"Failed to add share: {r.stderr.strip()}"}), 500

    host_run("systemctl restart smbd nmbd 2>/dev/null || systemctl restart smb nmb 2>/dev/null || true")
    return jsonify({"success": True, "share_name": share_name, "path": share_path})


@storage_bp.route('/samba/share', methods=['DELETE'])
@admin_required
def samba_share_remove():
    data = request.json or {}
    share_name = data.get("name", "").strip()
    if not share_name:
        return jsonify({"error": "name is required"}), 400

    # Validate share name
    if not re.match(r'^[a-zA-Z0-9][a-zA-Z0-9 _\-]{0,63}$', share_name):
        return jsonify({"error": "Invalid share name"}), 400

    script = """import json, re
NL = chr(10)
params = json.loads(open('/tmp/_samba_del_params.json').read())
name = params['name']
try:
    conf = open('/etc/samba/smb.conf').read()
except FileNotFoundError:
    exit(0)
pattern = r'\\[' + re.escape(name) + r'\\][^\\[]*'
conf = re.sub(pattern, '', conf, flags=re.IGNORECASE)
open('/etc/samba/smb.conf', 'w').write(conf.strip() + NL)
"""
    _host_write_json('/tmp/_samba_del_params.json', {"name": share_name})
    _host_write_script('/tmp/_samba_del.py', script)
    host_run("python3 /tmp/_samba_del.py")
    host_run("rm -f /tmp/_samba_del.py /tmp/_samba_del_params.json 2>/dev/null")
    host_run("systemctl restart smbd nmbd 2>/dev/null || systemctl restart smb nmb 2>/dev/null || true")
    return jsonify({"success": True})


@storage_bp.route('/samba/password', methods=['POST'])
@admin_required
def samba_password():
    """Set Samba password for a user (creates the user if needed)."""
    err = require_tools('smbpasswd')
    if err:
        return err
    data = request.json or {}
    username = data.get("username")
    password = data.get("password")
    if not username or not password:
        return jsonify({"error": "username and password are required"}), 400

    # Validate username: alphanumeric + underscores
    if not re.match(r'^[a-zA-Z0-9_]{1,32}$', username):
        return jsonify({"error": "Username may only contain letters, numbers, and _"}), 400

    # Validate password length
    if len(password) < 1 or len(password) > 128:
        return jsonify({"error": "Password must be 1-128 characters"}), 400

    # Ensure user exists on the host
    host_run(f"id {Q(username)} || useradd -M -s /usr/sbin/nologin {Q(username)}")

    # Set samba password safely — pass password via base64-encoded JSON file
    # This avoids any shell injection via password characters
    _host_write_json('/tmp/_smb_pw.json', {'pw': password, 'user': username})
    script = """import json, subprocess, sys
params = json.loads(open('/tmp/_smb_pw.json').read())
pw = params['pw']
user = params['user']
p = subprocess.Popen(['smbpasswd', '-s', '-a', user],
    stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out, err = p.communicate((pw + chr(10) + pw + chr(10)).encode())
sys.exit(p.returncode)
"""
    _host_write_script('/tmp/_smb_pw_set.py', script)
    r = host_run("python3 /tmp/_smb_pw_set.py")
    host_run("rm -f /tmp/_smb_pw.json /tmp/_smb_pw_set.py 2>/dev/null")

    if r.returncode != 0:
        return jsonify({"error": f"smbpasswd failed: {r.stderr.strip()}"}), 500

    return jsonify({"success": True})


# -- Samba package routes (for App Store install/uninstall) --

@storage_bp.route('/samba/pkg-install', methods=['POST'])
@admin_required
def samba_pkg_install():
    """Install Samba via apt — delegates to the existing /samba/install SSE endpoint logic."""
    r = host_run("command -v smbd")
    if r.returncode == 0:
        return jsonify({'status': 'ok', 'installed': True})
    ok, msg = claim_dep('smbd', 'sharing-samba')
    if not ok:
        return jsonify({'ok': False, 'error': msg or 'Samba installation failed'}), 500
    host_run("systemctl unmask smbd nmbd 2>/dev/null; systemctl enable smbd nmbd 2>/dev/null; systemctl start smbd nmbd 2>/dev/null || true")
    host_run("ufw allow from 192.168.0.0/16 to any port 139 proto tcp comment 'Samba NetBIOS' 2>/dev/null || true")
    host_run("ufw allow from 192.168.0.0/16 to any port 137 proto udp comment 'Samba NetBIOS NS' 2>/dev/null || true")
    host_run("ufw allow from 192.168.0.0/16 to any port 138 proto udp comment 'Samba NetBIOS DGM' 2>/dev/null || true")
    host_run("ufw allow from 192.168.0.0/16 to any port 445 proto tcp comment 'Samba SMB' 2>/dev/null || true")
    return jsonify({'status': 'ok'})


@storage_bp.route('/samba/pkg-uninstall', methods=['POST'])
@admin_required
def samba_pkg_uninstall():
    """Stop Samba services and disable them. Optionally wipe shares config."""
    wipe = (request.json or {}).get('wipe_data', False)

    # 1. Stop wsdd (WS-Discovery) — no purpose without Samba
    host_run("systemctl stop wsdd 2>/dev/null; systemctl disable wsdd 2>/dev/null || true")
    ufw_delete(3702, 'udp')
    ufw_delete(5357, 'tcp')

    # 2. Stop Samba services
    host_run("systemctl stop smbd nmbd 2>/dev/null || true")
    # 3. Disable so they don't restart on reboot
    host_run("systemctl disable smbd nmbd 2>/dev/null || true")

    ok, dep_msg = release_dep('smbd', 'sharing-samba')
    ufw_delete(139, 'tcp')
    ufw_delete(445, 'tcp')

    if wipe:
        # 3. Remove Samba configuration
        host_run("rm -f /etc/samba/smb.conf 2>/dev/null || true")

    # 4. Log event
    try:
        from blueprints.eventlog import log as elog
        elog('packages', 'info', f'Samba uninstalled (wipe={wipe})')
    except Exception:
        pass

    if not ok:
        return jsonify({'ok': False, 'error': dep_msg or 'Failed to remove Samba dependencies'}), 500
    return jsonify({'ok': True})


@storage_bp.route('/samba/pkg-status', methods=['GET'])
def samba_pkg_status():
    r = host_run("command -v smbd")
    installed = r.returncode == 0
    return jsonify({'status': 'ready' if installed else 'missing', 'samba_installed': installed})


# ═══════════════════════════════════════════════════════════
#  WS-Discovery (wsdd) — Windows 10+ Network browsing
# ═══════════════════════════════════════════════════════════

def _wsdd_workgroup():
    """Read workgroup from smb.conf, default to WORKGROUP."""
    try:
        with open('/etc/samba/smb.conf') as f:
            for line in f:
                m = re.match(r'\s*workgroup\s*=\s*(\S+)', line, re.IGNORECASE)
                if m:
                    return m.group(1)
    except Exception:
        pass
    return 'WORKGROUP'


@storage_bp.route('/samba/wsdd/status', methods=['GET'])
@admin_required
def wsdd_status():
    """Check if wsdd is installed and running."""
    r = host_run("command -v wsdd")
    installed = r.returncode == 0
    running = False
    enabled = False
    if installed:
        r2 = host_run("systemctl is-active wsdd 2>/dev/null")
        running = r2.stdout.strip() == 'active'
        r3 = host_run("systemctl is-enabled wsdd 2>/dev/null")
        enabled = r3.stdout.strip() == 'enabled'
    return jsonify({'installed': installed, 'running': running, 'enabled': enabled})


@storage_bp.route('/samba/wsdd/toggle', methods=['POST'])
@admin_required
def wsdd_toggle():
    """Enable or disable WS-Discovery for Windows network browsing."""
    enable = (request.json or {}).get('enable', True)

    if enable:
        # Install wsdd if not present
        r = host_run("command -v wsdd")
        if r.returncode != 0:
            r = _apt_install('wsdd', timeout=120)
            if r.returncode != 0:
                return jsonify({'ok': False, 'error': 'Failed to install wsdd: ' + r.stderr.strip()}), 500

        # Configure workgroup via /etc/default/wsdd
        workgroup = _wsdd_workgroup()
        hostname = host_run("hostname -s").stdout.strip() or 'ethos'
        # Detect LAN interface (first non-loopback, non-docker, non-bridge)
        iface_r = host_run(
            "ip -4 route get 8.8.8.8 2>/dev/null | grep -oP 'dev \\K\\S+' | head -1"
        )
        iface = iface_r.stdout.strip() or 'eth0'
        # Plain values (no shell-quoting) — env file is sourced by systemd, not bash
        wsdd_conf = f'WSDD_PARAMS="-n {hostname} -w {workgroup} -i {iface}"\n'
        try:
            os.makedirs('/etc/default', exist_ok=True)
            with open('/etc/default/wsdd', 'w') as f:
                f.write(wsdd_conf)
        except Exception as e:
            logging.warning('wsdd: failed to write /etc/default/wsdd: %s', e)

        # Ensure the systemd unit file exists (Debian wsdd package ships only the binary)
        unit_path = '/etc/systemd/system/wsdd.service'
        if not os.path.exists(unit_path):
            unit = (
                '[Unit]\n'
                'Description=Web Services Dynamic Discovery host daemon\n'
                'Documentation=man:wsdd(1)\n'
                'After=network-online.target smbd.service\n'
                'Wants=network-online.target\n\n'
                '[Service]\n'
                'Type=simple\n'
                'EnvironmentFile=-/etc/default/wsdd\n'
                'ExecStart=/usr/bin/wsdd $WSDD_PARAMS\n'
                'Restart=on-failure\n'
                'RestartSec=5\n\n'
                '[Install]\n'
                'WantedBy=multi-user.target\n'
            )
            try:
                with open(unit_path, 'w') as f:
                    f.write(unit)
                host_run("systemctl daemon-reload")
            except Exception as e:
                logging.warning('wsdd: failed to write unit file: %s', e)

        # Open firewall ports (WS-Discovery multicast + HTTP)
        host_run("ufw allow from 192.168.0.0/16 to any port 3702 proto udp comment 'WS-Discovery' 2>/dev/null || true")
        host_run("ufw allow from 192.168.0.0/16 to any port 5357 proto tcp comment 'WS-Discovery HTTP' 2>/dev/null || true")

        host_run("systemctl unmask wsdd 2>/dev/null; "
                 "systemctl enable wsdd 2>/dev/null; "
                 "systemctl restart wsdd 2>/dev/null || true")
        return jsonify({'ok': True, 'enabled': True})
    else:
        host_run("systemctl stop wsdd 2>/dev/null; "
                 "systemctl disable wsdd 2>/dev/null || true")
        ufw_delete(3702, 'udp')
        ufw_delete(5357, 'tcp')
        return jsonify({'ok': True, 'enabled': False})


# ═══════════════════════════════════════════════════════════
#  Share ACLs (per-user/group access control on Samba shares)
# ═══════════════════════════════════════════════════════════

_SHARE_ACLS_FILE = data_path('share_acls.json')


def _load_share_acls():
    """Load share ACL map: { share_name: { users: {user: perm}, groups: {group: perm} } }."""
    if os.path.isfile(_SHARE_ACLS_FILE):
        try:
            with open(_SHARE_ACLS_FILE) as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def _save_share_acls(acls):
    os.makedirs(os.path.dirname(_SHARE_ACLS_FILE), exist_ok=True)
    with open(_SHARE_ACLS_FILE, 'w') as f:
        json.dump(acls, f, indent=2)


def _apply_share_acl(share_name):
    """Rewrite the Samba share config and apply POSIX ACLs for a single share."""
    acls = _load_share_acls()
    share_acl = acls.get(share_name, {})
    users_acl = share_acl.get('users', {})
    groups_acl = share_acl.get('groups', {})

    # Build Samba directive lists
    valid_users = []
    write_list = []
    read_list = []
    for user, perm in users_acl.items():
        if perm in ('rw', 'ro'):
            valid_users.append(user)
        if perm == 'rw':
            write_list.append(user)
        elif perm == 'ro':
            read_list.append(user)
    for group, perm in groups_acl.items():
        g = f'@{group}'
        if perm in ('rw', 'ro'):
            valid_users.append(g)
        if perm == 'rw':
            write_list.append(g)
        elif perm == 'ro':
            read_list.append(g)

    # If no ACLs defined, skip (share remains open to all authenticated users)
    if not valid_users:
        return

    acl_params = {
        'name': share_name,
        'valid_users': ' '.join(valid_users),
        'write_list': ' '.join(write_list),
        'read_list': ' '.join(read_list),
    }

    # Inject ACL directives into smb.conf for this share
    script = """import json, re
NL = chr(10)
params = json.loads(open('/tmp/_samba_acl_params.json').read())
name = params['name']
try:
    conf = open('/etc/samba/smb.conf').read()
except FileNotFoundError:
    exit(0)

# Find the share block
pattern = r'\\[' + re.escape(name) + r'\\]([^\\[]*)'
m = re.search(pattern, conf, flags=re.IGNORECASE)
if not m:
    exit(0)

block = m.group(0)
# Remove old ACL directives
for directive in ('valid users', 'write list', 'read list', 'force user', 'force group'):
    block = re.sub(r'\\n\\s*' + directive + r'\\s*=.*', '', block, flags=re.IGNORECASE)

# Add new ACL directives
if params['valid_users']:
    block = block.rstrip() + NL + '    valid users = ' + params['valid_users'] + NL
if params['write_list']:
    block = block.rstrip() + NL + '    write list = ' + params['write_list'] + NL
if params['read_list']:
    block = block.rstrip() + NL + '    read list = ' + params['read_list'] + NL

conf = re.sub(pattern, block, conf, count=1, flags=re.IGNORECASE)
open('/etc/samba/smb.conf', 'w').write(conf)
"""
    _host_write_json('/tmp/_samba_acl_params.json', acl_params)
    _host_write_script('/tmp/_samba_acl.py', script)
    host_run("python3 /tmp/_samba_acl.py")
    host_run("rm -f /tmp/_samba_acl.py /tmp/_samba_acl_params.json 2>/dev/null")

    # Apply POSIX ACLs on the directory
    share_path = _get_share_path(share_name)
    if share_path:
        _apply_posix_acls(share_path, users_acl, groups_acl)

    host_run("systemctl restart smbd 2>/dev/null || true")


def _get_share_path(share_name):
    """Read the path for a share from smb.conf."""
    r = host_run(f"grep -A5 '\\[{_q_imported(share_name)}\\]' /etc/samba/smb.conf 2>/dev/null | grep 'path =' | head -1")
    if r.returncode == 0 and r.stdout.strip():
        return r.stdout.strip().split('=', 1)[-1].strip()
    return None


def _apply_posix_acls(path, users_acl, groups_acl):
    """Apply POSIX ACLs on the share directory using setfacl."""
    # Check if setfacl is available
    r = host_run("command -v setfacl")
    if r.returncode != 0:
        return

    # Reset ACLs
    host_run(f"setfacl -b {_q_imported(path)} 2>/dev/null")

    # Apply user ACLs
    for user, perm in users_acl.items():
        if perm == 'rw':
            host_run(f"setfacl -m u:{_q_imported(user)}:rwx {_q_imported(path)}")
        elif perm == 'ro':
            host_run(f"setfacl -m u:{_q_imported(user)}:r-x {_q_imported(path)}")
        elif perm == 'none':
            host_run(f"setfacl -m u:{_q_imported(user)}:--- {_q_imported(path)}")

    # Apply group ACLs
    for group, perm in groups_acl.items():
        if perm == 'rw':
            host_run(f"setfacl -m g:{_q_imported(group)}:rwx {_q_imported(path)}")
        elif perm == 'ro':
            host_run(f"setfacl -m g:{_q_imported(group)}:r-x {_q_imported(path)}")
        elif perm == 'none':
            host_run(f"setfacl -m g:{_q_imported(group)}:--- {_q_imported(path)}")

    # Set default ACLs (for new files/dirs)
    for user, perm in users_acl.items():
        if perm == 'rw':
            host_run(f"setfacl -dm u:{_q_imported(user)}:rwx {_q_imported(path)}")
        elif perm == 'ro':
            host_run(f"setfacl -dm u:{_q_imported(user)}:r-x {_q_imported(path)}")

    for group, perm in groups_acl.items():
        if perm == 'rw':
            host_run(f"setfacl -dm g:{_q_imported(group)}:rwx {_q_imported(path)}")
        elif perm == 'ro':
            host_run(f"setfacl -dm g:{_q_imported(group)}:r-x {_q_imported(path)}")


@storage_bp.route('/samba/share/acl', methods=['GET'])
@admin_required
def get_share_acl():
    """Get ACLs for a specific share."""
    share_name = request.args.get('name', '').strip()
    if not share_name:
        return jsonify({'error': 'name parameter required'}), 400
    acls = _load_share_acls()
    share_acl = acls.get(share_name, {'users': {}, 'groups': {}})
    return jsonify({'ok': True, 'share': share_name, 'acl': share_acl})


@storage_bp.route('/samba/share/acl', methods=['PUT'])
@admin_required
def set_share_acl():
    """Set ACLs for a specific share.

    Body: { name: "share_name", users: { "user1": "rw", "user2": "ro" },
            groups: { "group1": "rw" } }
    Permission values: "rw" (read-write), "ro" (read-only), "none" (no access)
    """
    data = request.json or {}
    share_name = data.get('name', '').strip()
    if not share_name:
        return jsonify({'error': 'name required'}), 400

    users_acl = data.get('users', {})
    groups_acl = data.get('groups', {})

    # Validate permission values
    valid_perms = {'rw', 'ro', 'none'}
    for perm in list(users_acl.values()) + list(groups_acl.values()):
        if perm not in valid_perms:
            return jsonify({'error': f'Invalid permission "{perm}". Use: rw, ro, none'}), 400

    # Remove 'none' entries (deny handled by exclusion from valid users)
    clean_users = {u: p for u, p in users_acl.items() if p != 'none'}
    clean_groups = {g: p for g, p in groups_acl.items() if p != 'none'}

    acls = _load_share_acls()
    acls[share_name] = {'users': users_acl, 'groups': groups_acl}
    _save_share_acls(acls)

    # Apply to Samba + filesystem
    _apply_share_acl(share_name)

    return jsonify({'ok': True, 'acl': acls[share_name]})


@storage_bp.route('/samba/share/acl', methods=['DELETE'])
@admin_required
def delete_share_acl():
    """Remove all ACLs for a share (revert to open access)."""
    data = request.json or {}
    share_name = data.get('name', '').strip()
    if not share_name:
        return jsonify({'error': 'name required'}), 400

    acls = _load_share_acls()
    if share_name in acls:
        del acls[share_name]
        _save_share_acls(acls)

    # Remove POSIX ACLs
    share_path = _get_share_path(share_name)
    if share_path:
        host_run(f"setfacl -b {_q_imported(share_path)} 2>/dev/null")

    # Remove ACL directives from smb.conf (restore default force user/group)
    host_run("systemctl restart smbd 2>/dev/null || true")
    return jsonify({'ok': True})


@storage_bp.route('/samba/shares/acls', methods=['GET'])
@admin_required
def get_all_share_acls():
    """Get ACLs for all shares."""
    return jsonify({'ok': True, 'acls': _load_share_acls()})


# ═══════════════════════════════════════════════════════════
#  NFS Sharing
# ═══════════════════════════════════════════════════════════

@storage_bp.route('/nfs/status')
def nfs_status():
    r = host_run("command -v exportfs")
    installed = r.returncode == 0
    running = False
    if installed:
        r2 = host_run("systemctl is-active nfs-server 2>/dev/null")
        running = "active" in r2.stdout.strip()
    return jsonify({"installed": installed, "running": running})


@storage_bp.route('/nfs/install', methods=['POST'])
def nfs_install():
    from host import ensure_dep
    ok, msg = ensure_dep('exportfs', install=True)
    if not ok:
        # Try direct package name
        r = _apt_install('nfs-kernel-server', timeout=120)
        if r.returncode != 0:
            return jsonify({"error": f"Installation failed: {r.stderr[-200:]}"}), 500
    host_run("systemctl enable nfs-server && systemctl start nfs-server", timeout=15)
    # Set optimal NFS thread count
    host_run("sed -i 's/^RPCNFSDCOUNT=.*/RPCNFSDCOUNT=16/' /etc/default/nfs-kernel-server 2>/dev/null || echo 'RPCNFSDCOUNT=16' >> /etc/default/nfs-kernel-server")
    host_run("systemctl restart nfs-server", timeout=15)
    return jsonify({"status": "ok"})


@storage_bp.route('/nfs/exports')
def nfs_exports():
    """List current NFS exports."""
    r = host_run("cat /etc/exports 2>/dev/null || echo ''")
    exports = []
    for line in r.stdout.strip().splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        parts = line.split()
        if len(parts) >= 2:
            exports.append({
                "path": parts[0],
                "clients": ' '.join(parts[1:]),
                "raw": line,
            })
    return jsonify({"exports": exports})


@storage_bp.route('/nfs/export', methods=['POST'])
def nfs_export_add():
    """Add an NFS export. Body: {path, network, options}"""
    data = request.json or {}
    path = data.get("path", "").strip()
    network = data.get("network", "*").strip() or "*"
    options = data.get("options", "rw,async,no_subtree_check,no_root_squash,insecure").strip()
    if not path or not os.path.isdir(path):
        return jsonify({"error": "Path not found"}), 400

    export_line = f'{path} {network}({options})'
    # Check for duplicates
    r = host_run("cat /etc/exports 2>/dev/null || echo ''")
    for line in r.stdout.splitlines():
        if line.strip().startswith(path + ' '):
            return jsonify({"error": "This directory is already exported"}), 409

    host_run(f"echo {Q(export_line)} >> /etc/exports")
    host_run("exportfs -ra", timeout=10)
    return jsonify({"ok": True})


@storage_bp.route('/nfs/export', methods=['DELETE'])
def nfs_export_remove():
    data = request.json or {}
    path = data.get("path", "").strip()
    if not path:
        return jsonify({"error": "Path required"}), 400
    # Remove line from /etc/exports
    host_run(f"sed -i '\\|^{path} |d' /etc/exports")
    host_run("exportfs -ra", timeout=10)
    return jsonify({"ok": True})


# -- NFS package routes (for EthOS Package Store) --

@storage_bp.route('/nfs/pkg-install', methods=['POST'])
def nfs_pkg_install():
    r = host_run("command -v exportfs")
    if r.returncode == 0:
        return jsonify({'status': 'ok', 'installed': True})
    ok, msg = claim_dep('exportfs', 'sharing-nfs')
    if not ok:
        return jsonify({'ok': False, 'error': msg or 'NFS installation failed'}), 500
    host_run("systemctl enable nfs-server && systemctl start nfs-server", timeout=15)
    ufw_allow(2049, 'tcp', 'NFS')
    return jsonify({'status': 'ok'})


@storage_bp.route('/nfs/pkg-uninstall', methods=['POST'])
def nfs_pkg_uninstall():
    wipe = (request.json or {}).get('wipe_data', False)
    host_run("systemctl stop nfs-server 2>/dev/null || true")
    host_run("systemctl disable nfs-server 2>/dev/null || true")
    ok, dep_msg = release_dep('exportfs', 'sharing-nfs')
    ufw_delete(2049, 'tcp')
    if wipe:
        host_run("rm -f /etc/exports 2>/dev/null || true")
    try:
        from blueprints.eventlog import log as elog
        elog('packages', 'info', f'NFS uninstalled (wipe={wipe})')
    except Exception:
        pass
    if not ok:
        return jsonify({'ok': False, 'error': dep_msg or 'Failed to remove NFS dependencies'}), 500
    return jsonify({'ok': True})


@storage_bp.route('/nfs/pkg-status', methods=['GET'])
def nfs_pkg_status():
    r = host_run("command -v exportfs")
    installed = r.returncode == 0
    return jsonify({'status': 'ready' if installed else 'missing', 'nfs_installed': installed})


# ═══════════════════════════════════════════════════════════
#  DLNA / MiniDLNA
# ═══════════════════════════════════════════════════════════

@storage_bp.route('/dlna/status')
def dlna_status():
    r = host_run("command -v minidlnad")
    installed = r.returncode == 0
    running = False
    if installed:
        r2 = host_run("systemctl is-active minidlna 2>/dev/null")
        running = "active" in r2.stdout.strip()
    return jsonify({"installed": installed, "running": running})


@storage_bp.route('/dlna/install', methods=['POST'])
def dlna_install():
    r = _apt_install('minidlna', timeout=120)
    if r.returncode != 0:
        return jsonify({"error": f"Installation failed: {r.stderr[-200:]}"}), 500
    host_run("systemctl enable minidlna", timeout=10)
    return jsonify({"status": "ok"})


@storage_bp.route('/dlna/config')
def dlna_config():
    """Get DLNA media directories."""
    r = host_run("cat /etc/minidlna.conf 2>/dev/null || echo ''")
    dirs = []
    friendly_name = "EthOS"
    for line in r.stdout.splitlines():
        line = line.strip()
        if line.startswith('media_dir='):
            dirs.append(line.split('=', 1)[1])
        elif line.startswith('friendly_name='):
            friendly_name = line.split('=', 1)[1]
    return jsonify({"dirs": dirs, "friendly_name": friendly_name})


@storage_bp.route('/dlna/config', methods=['POST'])
def dlna_config_set():
    """Set DLNA media directories. Body: {dirs: ["/home/media", ...], friendly_name: "..."}"""
    data = request.json or {}
    dirs = data.get("dirs", [])
    friendly_name = data.get("friendly_name", "EthOS").strip()

    config = f"""# EthOS MiniDLNA config
friendly_name={friendly_name}
db_dir=/var/cache/minidlna
log_dir=/var/log
inotify=yes
"""
    for d in dirs:
        d = d.strip()
        if d and os.path.isdir(d):
            config += f"media_dir={d}\n"

    _host_write_file('/etc/minidlna.conf', config)
    host_run("systemctl restart minidlna 2>/dev/null || systemctl start minidlna", timeout=10)
    return jsonify({"ok": True})


@storage_bp.route('/dlna/rescan', methods=['POST'])
def dlna_rescan():
    host_run("systemctl restart minidlna", timeout=10)
    return jsonify({"status": "ok"})


# -- DLNA package routes (for EthOS Package Store) --

@storage_bp.route('/dlna/pkg-install', methods=['POST'])
def dlna_pkg_install():
    r = host_run("command -v minidlnad")
    if r.returncode == 0:
        return jsonify({'status': 'ok', 'installed': True})
    ok, msg = claim_dep('minidlnad', 'sharing-dlna')
    if not ok:
        return jsonify({'ok': False, 'error': msg or 'MiniDLNA installation failed'}), 500
    host_run("systemctl enable minidlna", timeout=10)
    ufw_allow(8200, 'tcp', 'DLNA')
    return jsonify({'status': 'ok'})


@storage_bp.route('/dlna/pkg-uninstall', methods=['POST'])
def dlna_pkg_uninstall():
    wipe = (request.json or {}).get('wipe_data', False)
    host_run("systemctl stop minidlna 2>/dev/null || true")
    host_run("systemctl disable minidlna 2>/dev/null || true")
    ok, dep_msg = release_dep('minidlnad', 'sharing-dlna')
    ufw_delete(8200, 'tcp')
    if wipe:
        host_run("rm -f /etc/minidlna.conf 2>/dev/null || true")
    try:
        from blueprints.eventlog import log as elog
        elog('packages', 'info', f'MiniDLNA uninstalled (wipe={wipe})')
    except Exception:
        pass
    if not ok:
        return jsonify({'ok': False, 'error': dep_msg or 'Failed to remove MiniDLNA dependencies'}), 500
    return jsonify({'ok': True})


@storage_bp.route('/dlna/pkg-status', methods=['GET'])
def dlna_pkg_status():
    r = host_run("command -v minidlnad")
    installed = r.returncode == 0
    return jsonify({'status': 'ready' if installed else 'missing', 'dlna_installed': installed})


# ═══════════════════════════════════════════════════════════
#  SFTP
# ═══════════════════════════════════════════════════════════

@storage_bp.route('/sftp/status')
def sftp_status():
    r = host_run("systemctl is-active ssh 2>/dev/null || systemctl is-active sshd 2>/dev/null")
    running = "active" in r.stdout.strip()
    # Check if SFTP subsystem is enabled
    r2 = host_run("grep -q 'Subsystem.*sftp' /etc/ssh/sshd_config 2>/dev/null")
    sftp_enabled = r2.returncode == 0
    return jsonify({"installed": True, "running": running, "sftp_enabled": sftp_enabled})


@storage_bp.route('/sftp/toggle', methods=['POST'])
def sftp_toggle():
    """Enable or disable SFTP subsystem."""
    data = request.json or {}
    enable = data.get("enable", True)

    if enable:
        # Ensure Subsystem sftp line exists and is not commented
        host_run("grep -q '^Subsystem.*sftp' /etc/ssh/sshd_config || "
                 "echo 'Subsystem sftp /usr/lib/openssh/sftp-server' >> /etc/ssh/sshd_config")
        host_run("sed -i 's/^#Subsystem.*sftp/Subsystem sftp \\//g' /etc/ssh/sshd_config")
    else:
        host_run("sed -i 's/^Subsystem.*sftp/#Subsystem sftp/g' /etc/ssh/sshd_config")

    host_run("systemctl restart ssh 2>/dev/null || systemctl restart sshd 2>/dev/null", timeout=10)
    return jsonify({"ok": True, "enabled": enable})


@storage_bp.route('/sftp/users')
def sftp_users():
    """List system users that can use SFTP."""
    r = host_run("awk -F: '$3>=1000 && $3<65534{print $1\":\"$6}' /etc/passwd")
    users = []
    for line in r.stdout.strip().splitlines():
        parts = line.split(':', 1)
        if len(parts) == 2:
            users.append({"username": parts[0], "home": parts[1]})
    return jsonify({"users": users})


# -- SFTP package routes (for EthOS Package Store) --

@storage_bp.route('/sftp/pkg-install', methods=['POST'])
def sftp_pkg_install():
    """SFTP uses OpenSSH which is usually pre-installed. Enable the subsystem."""
    r = host_run("command -v sshd")
    if r.returncode != 0:
        _apt_install('openssh-server', timeout=120)
    # Enable SFTP subsystem
    host_run("grep -q '^Subsystem.*sftp' /etc/ssh/sshd_config || "
             "echo 'Subsystem sftp /usr/lib/openssh/sftp-server' >> /etc/ssh/sshd_config")
    host_run("sed -i 's/^#Subsystem.*sftp/Subsystem sftp \\/usr\\/lib\\/openssh\\/sftp-server/g' /etc/ssh/sshd_config")
    host_run("systemctl restart ssh 2>/dev/null || systemctl restart sshd 2>/dev/null", timeout=10)
    return jsonify({'status': 'ok'})


@storage_bp.route('/sftp/pkg-uninstall', methods=['POST'])
def sftp_pkg_uninstall():
    """Disable SFTP subsystem (don't remove sshd — that would kill SSH access)."""
    host_run("sed -i 's/^Subsystem.*sftp/#Subsystem sftp/g' /etc/ssh/sshd_config")
    host_run("systemctl restart ssh 2>/dev/null || systemctl restart sshd 2>/dev/null", timeout=10)
    try:
        from blueprints.eventlog import log as elog
        elog('packages', 'info', 'SFTP disabled (subsystem disabled)')
    except Exception:
        pass
    return jsonify({'ok': True})


@storage_bp.route('/sftp/pkg-status', methods=['GET'])
def sftp_pkg_status():
    r = host_run("grep -q '^Subsystem.*sftp' /etc/ssh/sshd_config 2>/dev/null")
    enabled = r.returncode == 0
    return jsonify({'status': 'ready' if enabled else 'missing', 'sftp_enabled': enabled})


# ═══════════════════════════════════════════════════════════
#  WebDAV (via lighttpd or built-in)
# ═══════════════════════════════════════════════════════════

_WEBDAV_CONF = '/etc/lighttpd/conf-enabled/90-webdav.conf'
_WEBDAV_PORT = 8888
_WEBDAV_SHARES_FILE = data_path('webdav_shares.json')


def _load_webdav_shares():
    try:
        with open(_WEBDAV_SHARES_FILE, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []


def _save_webdav_shares(shares):
    with open(_WEBDAV_SHARES_FILE, 'w') as f:
        json.dump(shares, f, indent=2)


def _rebuild_webdav_conf(shares):
    """Regenerate lighttpd config from JSON share list."""
    if not shares:
        host_run(f"rm -f {_WEBDAV_CONF}")
        host_run("systemctl restart lighttpd 2>/dev/null || true", timeout=10)
        return

    blocks = []
    for s in shares:
        auth = ""
        if s.get('username'):
            htpasswd = f"/etc/lighttpd/webdav_{s['url_path'].strip('/').replace('/', '_')}.htpasswd"
            auth = f"""
    auth.backend = "htdigest"
    auth.backend.htdigest.userfile = "{htpasswd}"
    auth.require = ( "{s['url_path']}" => ( "method" => "digest", "realm" => "WebDAV", "require" => "valid-user" ) )
"""
        blocks.append(f"""    alias.url += ( "{s['url_path']}" => "{s['fs_path']}" )
    webdav.activate = "enable"
    webdav.is-readonly = "disable"
    webdav.sqlite-db-name = "/var/cache/lighttpd/webdav.db"
{auth}""")

    conf = f"""# EthOS WebDAV — auto-generated, do not edit manually
server.modules += ( "mod_webdav", "mod_alias" )
$SERVER["socket"] == ":{_WEBDAV_PORT}" {{
{chr(10).join(blocks)}
}}
"""
    _host_write_file(_WEBDAV_CONF, conf)
    host_run("mkdir -p /var/cache/lighttpd && systemctl restart lighttpd", timeout=10)


@storage_bp.route('/webdav/status')
def webdav_status():
    r = host_run("command -v lighttpd")
    installed = r.returncode == 0
    running = False
    if installed:
        r2 = host_run("systemctl is-active lighttpd 2>/dev/null")
        running = "active" in r2.stdout.strip()
    return jsonify({"installed": installed, "running": running, "port": _WEBDAV_PORT})


@storage_bp.route('/webdav/install', methods=['POST'])
def webdav_install():
    r = _apt_install('lighttpd', timeout=120)
    if r.returncode != 0:
        return jsonify({"error": f"Installation failed: {r.stderr[-200:]}"}), 500
    # Enable WebDAV module
    host_run("lighttpd-enable-mod webdav 2>/dev/null || true")
    return jsonify({"status": "ok"})


@storage_bp.route('/webdav/shares')
def webdav_shares():
    """Get current WebDAV shares from JSON store."""
    shares = _load_webdav_shares()
    return jsonify({"shares": shares, "port": _WEBDAV_PORT})


@storage_bp.route('/webdav/share', methods=['POST'])
def webdav_add():
    """Add a WebDAV share. Body: {path, url_path, username, password}"""
    data = request.json or {}
    fs_path = data.get("path", "").strip()
    url_path = data.get("url_path", "").strip()
    username = data.get("username", "").strip()
    password = data.get("password", "").strip()

    if not fs_path or not os.path.isdir(fs_path):
        return jsonify({"error": "Path not found"}), 400
    if not url_path:
        url_path = '/' + os.path.basename(fs_path)

    # Validate username/password — reject shell-dangerous characters
    import re as _re_val
    if username and not _re_val.match(r'^[a-zA-Z0-9._@-]+$', username):
        return jsonify({"error": "Invalid characters in username"}), 400
    if password and any(c in password for c in "'\"\\`$"):
        return jsonify({"error": "Invalid characters in password"}), 400

    # Set up htpasswd for this share if auth requested
    if username and password:
        htpasswd = f"/etc/lighttpd/webdav_{url_path.strip('/').replace('/', '_')}.htpasswd"
        host_run(f"printf '%s\\n' {Q(password)} | htpasswd -i -c {htpasswd} {Q(username)} 2>/dev/null || "
                 f"printf '%s' {Q(username + ':WebDAV:' + password)} | md5sum | cut -d' ' -f1 | "
                 f"xargs -I{{}} printf '%s\\n' {Q(username)}':WebDAV:'{{}}'\\n' > {htpasswd}")

    # Save to JSON and rebuild config
    shares = _load_webdav_shares()
    # Remove existing share with same url_path (update)
    shares = [s for s in shares if s.get('url_path') != url_path]
    shares.append({
        "url_path": url_path,
        "fs_path": fs_path,
        "username": username or None,
    })
    _save_webdav_shares(shares)
    _rebuild_webdav_conf(shares)

    return jsonify({"ok": True, "port": _WEBDAV_PORT})


@storage_bp.route('/webdav/share', methods=['DELETE'])
def webdav_remove():
    """Remove a single WebDAV share by url_path, or all if no url_path given."""
    data = request.json or {}
    url_path = data.get("url_path", "").strip()

    shares = _load_webdav_shares()
    if url_path:
        shares = [s for s in shares if s.get('url_path') != url_path]
    else:
        shares = []

    _save_webdav_shares(shares)
    _rebuild_webdav_conf(shares)
    return jsonify({"ok": True})


# -- WebDAV package routes (for EthOS Package Store) --

@storage_bp.route('/webdav/pkg-install', methods=['POST'])
@admin_required
def webdav_pkg_install():
    r = host_run("command -v lighttpd")
    if r.returncode == 0:
        return jsonify({'status': 'ok', 'installed': True})
    ok, msg = claim_dep('lighttpd', 'sharing-webdav')
    if not ok:
        return jsonify({'ok': False, 'error': msg or 'lighttpd installation failed'}), 500
    host_run("lighttpd-enable-mod webdav 2>/dev/null || true")
    ufw_allow(8888, 'tcp', 'WebDAV')
    return jsonify({'status': 'ok'})


@storage_bp.route('/webdav/pkg-uninstall', methods=['POST'])
@admin_required
def webdav_pkg_uninstall():
    wipe = (request.json or {}).get('wipe_data', False)
    host_run("systemctl stop lighttpd 2>/dev/null || true")
    host_run("systemctl disable lighttpd 2>/dev/null || true")
    ok, dep_msg = release_dep('lighttpd', 'sharing-webdav')
    ufw_delete(8888, 'tcp')
    if wipe:
        host_run(f"rm -f {_WEBDAV_CONF} 2>/dev/null || true")
        host_run("rm -f /etc/lighttpd/webdav_*.htpasswd 2>/dev/null || true")
    try:
        from blueprints.eventlog import log as elog
        elog('packages', 'info', f'WebDAV uninstalled (wipe={wipe})')
    except Exception:
        pass
    if not ok:
        return jsonify({'ok': False, 'error': dep_msg or 'Failed to remove WebDAV dependencies'}), 500
    return jsonify({'ok': True})


@storage_bp.route('/webdav/pkg-status', methods=['GET'])
def webdav_pkg_status():
    r = host_run("command -v lighttpd")
    installed = r.returncode == 0
    return jsonify({'status': 'ready' if installed else 'missing', 'webdav_installed': installed})


# ═══════════════════════════════════════════════════════════
#  FTP (vsftpd)
# ═══════════════════════════════════════════════════════════

@storage_bp.route('/ftp/status')
def ftp_status():
    r = host_run("command -v vsftpd")
    installed = r.returncode == 0
    running = False
    if installed:
        r2 = host_run("systemctl is-active vsftpd 2>/dev/null")
        running = "active" in r2.stdout.strip()
    return jsonify({"installed": installed, "running": running})


@storage_bp.route('/ftp/install', methods=['POST'])
def ftp_install():
    r = _apt_install('vsftpd', timeout=120)
    if r.returncode != 0:
        return jsonify({"error": f"Installation failed: {r.stderr[-200:]}"}), 500
    # Sensible defaults
    config = """# EthOS vsftpd config
listen=YES
listen_ipv6=NO
anonymous_enable=NO
local_enable=YES
write_enable=YES
local_umask=022
chroot_local_user=YES
allow_writeable_chroot=YES
pasv_enable=YES
pasv_min_port=40000
pasv_max_port=40100
"""
    _host_write_file('/etc/vsftpd.conf', config)
    host_run("systemctl enable vsftpd && systemctl restart vsftpd", timeout=10)
    return jsonify({"status": "ok"})


@storage_bp.route('/ftp/toggle', methods=['POST'])
def ftp_toggle():
    """Start or stop vsftpd. Body: {enable: bool}"""
    data = request.json or {}
    enable = data.get("enable", True)
    if enable:
        host_run("systemctl start vsftpd", timeout=10)
    else:
        host_run("systemctl stop vsftpd", timeout=10)
    return jsonify({"ok": True, "enabled": enable})


# -- FTP package routes (for EthOS Package Store) --

@storage_bp.route('/ftp/pkg-install', methods=['POST'])
def ftp_pkg_install():
    r = host_run("command -v vsftpd")
    if r.returncode == 0:
        return jsonify({'status': 'ok', 'installed': True})
    ok, msg = claim_dep('vsftpd', 'sharing-ftp')
    if not ok:
        return jsonify({'ok': False, 'error': msg or 'vsftpd installation failed'}), 500
    host_run("systemctl enable vsftpd && systemctl restart vsftpd", timeout=10)
    ufw_allow(21, 'tcp', 'FTP')
    return jsonify({'status': 'ok'})


@storage_bp.route('/ftp/pkg-uninstall', methods=['POST'])
def ftp_pkg_uninstall():
    wipe = (request.json or {}).get('wipe_data', False)
    host_run("systemctl stop vsftpd 2>/dev/null || true")
    host_run("systemctl disable vsftpd 2>/dev/null || true")
    ok, dep_msg = release_dep('vsftpd', 'sharing-ftp')
    ufw_delete(21, 'tcp')
    if wipe:
        host_run("rm -f /etc/vsftpd.conf 2>/dev/null || true")
    try:
        from blueprints.eventlog import log as elog
        elog('packages', 'info', f'FTP (vsftpd) uninstalled (wipe={wipe})')
    except Exception:
        pass
    if not ok:
        return jsonify({'ok': False, 'error': dep_msg or 'Failed to remove FTP dependencies'}), 500
    return jsonify({'ok': True})


@storage_bp.route('/ftp/pkg-status', methods=['GET'])
def ftp_pkg_status():
    r = host_run("command -v vsftpd")
    installed = r.returncode == 0
    return jsonify({'status': 'ready' if installed else 'missing', 'ftp_installed': installed})


# ═══════════════════════════════════════════════════════════
#  Disk Formatting
# ═══════════════════════════════════════════════════════════

FORMAT_FS_OPTIONS = [
    {"value": "ext4",  "label": "ext4",  "desc": "Best for Linux — fast, reliable, journaling", "linux": True,  "windows": False, "mac": False},
    {"value": "btrfs", "label": "Btrfs", "desc": "Modern Linux — snapshots, compression, RAID", "linux": True,  "windows": False, "mac": False},
    {"value": "xfs",   "label": "XFS",   "desc": "High-performance Linux — large files, servers", "linux": True,  "windows": False, "mac": False},
    {"value": "ntfs",  "label": "NTFS",  "desc": "Windows — full Windows compatibility", "linux": True,  "windows": True,  "mac": True},
    {"value": "exfat", "label": "exFAT", "desc": "Universal — Windows, Mac, Linux, large files", "linux": True,  "windows": True,  "mac": True},
    {"value": "vfat",  "label": "FAT32", "desc": "Maximum compatibility — 4 GB file size limit", "linux": True,  "windows": True,  "mac": True},
    {"value": "ext3",  "label": "ext3",  "desc": "Legacy Linux — journaling, compatibility", "linux": True,  "windows": False, "mac": False},
    {"value": "f2fs",  "label": "F2FS",  "desc": "Flash-Friendly — SSD, USB drives, SD cards", "linux": True,  "windows": False, "mac": False},
]

# Mapping from fs value to mkfs command
MKFS_CMDS = {
    "ext4":  "mkfs.ext4 -F",
    "ext3":  "mkfs.ext3 -F",
    "btrfs": "mkfs.btrfs -f",
    "xfs":   "mkfs.xfs -f",
    "ntfs":  "mkfs.ntfs -f",
    "exfat": "mkfs.exfat",
    "vfat":  "mkfs.vfat -F 32",
    "f2fs":  "mkfs.f2fs -f",
}


@storage_bp.route('/relabel', methods=['POST'])
def relabel_drive():
    """Change the filesystem label of a partition.
    Expects JSON: { drive: 'sdb2', label: 'NewLabel' }
    For ext2/3/4 uses e2label, for ntfs uses ntfslabel, for fat uses fatlabel, for exfat uses exfatlabel.
    Ext can be relabeled while mounted; NTFS/FAT must be unmounted first.
    """
    data = request.json or {}
    drive = data.get('drive', '').strip()
    new_label = data.get('label', '').strip()

    if not drive or not re.match(r'^[a-zA-Z0-9]+$', drive):
        return jsonify({'error': 'Invalid drive name'}), 400
    if not new_label:
        return jsonify({'error': 'Label is required'}), 400
    # Sanitize label: no slashes, max 32 chars
    if '/' in new_label or len(new_label) > 32:
        return jsonify({'error': 'Label must be max 32 chars, no slashes'}), 400

    dev_path = f'/dev/{drive}'

    # Detect filesystem type
    r = host_run(f"lsblk -no FSTYPE {Q(dev_path)} 2>/dev/null")
    if r.returncode != 0 or not r.stdout.strip():
        return jsonify({'error': 'Cannot detect filesystem type'}), 400
    fstype = r.stdout.strip().lower()

    # Check if mounted
    r_mp = host_run(f"findmnt -n -o TARGET {Q(dev_path)} 2>/dev/null")
    is_mounted = r_mp.returncode == 0 and r_mp.stdout.strip() != ''
    mountpoint = r_mp.stdout.strip() if is_mounted else None

    # Build the label command based on filesystem
    # For filesystems that require unmount, handle it automatically
    needs_remount = False
    if fstype in ('ext2', 'ext3', 'ext4'):
        cmd = f"e2label {Q(dev_path)} {Q(new_label)}"
    elif fstype in ('ntfs', 'fuseblk'):
        if is_mounted:
            r_um = host_run(f"umount {Q(mountpoint)}")
            if r_um.returncode != 0:
                r_um = host_run(f"umount -l {Q(mountpoint)}")
                if r_um.returncode != 0:
                    return jsonify({'error': 'Failed to unmount NTFS disk'}), 500
            needs_remount = True
        cmd = f"ntfslabel --force {Q(dev_path)} {Q(new_label)}"
    elif fstype in ('vfat', 'fat32', 'fat16'):
        if is_mounted:
            r_um = host_run(f"umount {Q(mountpoint)}")
            if r_um.returncode != 0:
                return jsonify({'error': 'Failed to unmount FAT disk'}), 500
            needs_remount = True
        cmd = f"fatlabel {Q(dev_path)} {Q(new_label)}"
    elif fstype == 'exfat':
        if is_mounted:
            r_um = host_run(f"umount {Q(mountpoint)}")
            if r_um.returncode != 0:
                return jsonify({'error': 'Failed to unmount exFAT disk'}), 500
            needs_remount = True
        cmd = f"exfatlabel {Q(dev_path)} {Q(new_label)}"
    elif fstype == 'btrfs':
        cmd = f"btrfs filesystem label {Q(dev_path)} {Q(new_label)}"
    elif fstype == 'xfs':
        if is_mounted:
            r_um = host_run(f"umount {Q(mountpoint)}")
            if r_um.returncode != 0:
                return jsonify({'error': 'Failed to unmount XFS disk'}), 500
            needs_remount = True
        cmd = f"xfs_admin -L {Q(new_label)} {Q(dev_path)}"
    else:
        return jsonify({'error': f'Label change is not supported for {fstype}'}), 400

    r = host_run(cmd, timeout=15)
    if r.returncode != 0:
        # If we unmounted, try to remount before returning error
        if needs_remount and mountpoint:
            host_run(f"mount {Q(dev_path)} {Q(mountpoint)}", timeout=10)
        return jsonify({'error': f'Error: {r.stderr.strip() or r.stdout.strip()}'}), 500

    # Remount at new label path if it was auto-unmounted
    if needs_remount and mountpoint:
        # Mount to a path based on new label
        new_mp = f"/media/devmon/{new_label}"
        host_run(f"mkdir -p {Q(new_mp)}", timeout=5)
        r_rm = host_run(f"mount {Q(dev_path)} {Q(new_mp)}", timeout=15)
        if r_rm.returncode != 0:
            # Fallback: remount at old path
            host_run(f"mount {Q(dev_path)} {Q(mountpoint)}", timeout=10)
        else:
            # Clean up old empty mountpoint dir
            host_run(f"rmdir {Q(mountpoint)} 2>/dev/null", timeout=5)

    return jsonify({'success': True, 'drive': drive, 'label': new_label, 'fstype': fstype})


@storage_bp.route('/format/options')
def format_options():
    """Return available filesystem options with system recommendation."""
    # Detect current system filesystem
    r = host_run("findmnt -n -o FSTYPE / 2>/dev/null")
    system_fs = r.stdout.strip() if r.returncode == 0 else "ext4"

    # Check which mkfs tools are available
    options = []
    for fs in FORMAT_FS_OPTIONS:
        cmd = MKFS_CMDS.get(fs["value"], "").split()[0]
        if cmd:
            avail_r = host_run(f"command -v {cmd}")
            available = avail_r.returncode == 0
        else:
            available = False
        options.append({
            **fs,
            "available": available,
            "recommended": fs["value"] == system_fs,
        })

    return jsonify({
        "system_fs": system_fs,
        "options": options,
    })


@storage_bp.route('/format', methods=['POST'])
def format_drive():
    """Format a drive with a specified filesystem.
    Expects JSON: { drive: 'sda1', fstype: 'ext4', label: 'MyDisk' }
    The drive MUST be unmounted first.
    """
    data = request.json or {}
    drive_name = data.get("drive", "").strip()
    fstype = data.get("fstype", "").strip()
    label = data.get("label", "").strip()

    if not drive_name or not fstype:
        return jsonify({"error": "drive and fstype are required"}), 400

    # Validate drive name (prevent injection)
    if not re.match(r'^[a-zA-Z0-9]+$', drive_name):
        return jsonify({"error": "Invalid device name"}), 400

    # Validate fstype
    if fstype not in MKFS_CMDS:
        return jsonify({"error": f"Unsupported filesystem: {fstype}"}), 400

    dev_path = f"/dev/{drive_name}"

    # Check device exists
    r = host_run(f"lsblk -no NAME {dev_path} 2>/dev/null")
    if r.returncode != 0:
        return jsonify({"error": f"Device {dev_path} does not exist"}), 404

    # Check device is not mounted (including child partitions)
    r = host_run(f"findmnt -n -o TARGET {dev_path} 2>/dev/null")
    if r.returncode == 0 and r.stdout.strip():
        return jsonify({"error": f"Device is mounted on {r.stdout.strip()}. Unmount first."}), 400

    # Also check child devices (e.g. sda has sda1 mounted)
    r = host_run(f"lsblk -no MOUNTPOINT {dev_path} 2>/dev/null")
    if r.returncode == 0:
        mounted_children = [mp.strip() for mp in r.stdout.strip().split('\n') if mp.strip()]
        if mounted_children:
            # Check for system mounts first
            for mp in mounted_children:
                if mp in ('/', '/boot', '/boot/efi', '/home'):
                    return jsonify({"error": f"Device is in use by system ({mp})!"}), 403
            # Any other mount — must unmount first
            return jsonify({"error": f"Partition is mounted on {mounted_children[0]}. Unmount first."}), 400

    # Safety: refuse to format system disk (robust check incl. LVM)
    # Extract base disk name for system check
    _base_disk = re.sub(r'p?\d+$', '', drive_name)
    if _is_system_disk(drive_name) or (_base_disk != drive_name and _is_system_disk(_base_disk)):
        return jsonify({"error": "Cannot format system disk!"}), 403

    # Build mkfs command
    mkfs_base = MKFS_CMDS[fstype]
    label_flag = ""
    if label:
        safe_label = re.sub(r'[^a-zA-Z0-9_\-.]', '_', label)[:16]
        if fstype in ("ext4", "ext3", "btrfs", "f2fs"):
            label_flag = f"-L {Q(safe_label)}"
        elif fstype == "xfs":
            label_flag = f"-L {Q(safe_label)}"
        elif fstype == "ntfs":
            label_flag = f"-L {Q(safe_label)}"
        elif fstype in ("exfat", "vfat"):
            label_flag = f"-n {Q(safe_label[:11])}"

    cmd = f"{mkfs_base} {label_flag} {dev_path} 2>&1"

    def generate():
        yield f"data: {json.dumps({'type': 'step', 'message': f'Formatting {dev_path} as {fstype}...'})}\n\n"
        if label:
            yield f"data: {json.dumps({'type': 'step', 'message': f'Label: {label}'})}\n\n"

        for line in host_run_stream(cmd):
            line = line.rstrip("\n")
            if line.startswith("__EXIT_CODE__:"):
                code = int(line.split(":")[1])
                if code == 0:
                    # For ext filesystems, set periodic fsck (every 30 mounts or 90 days)
                    if fstype in ('ext4', 'ext3', 'ext2'):
                        host_run(f'tune2fs -c 30 -i 90d {dev_path} 2>/dev/null', timeout=10)
                        yield f"data: {json.dumps({'type': 'step', 'message': 'Periodic fsck configured (30 mounts / 90 days)'})}\n\n"
                    yield f"data: {json.dumps({'type': 'step', 'message': 'Format completed successfully!'})}\n\n"
                    yield f"data: {json.dumps({'type': 'done', 'success': True})}\n\n"
                else:
                    yield f"data: {json.dumps({'type': 'step', 'message': f'Format error (code: {code})'})}\n\n"
                    yield f"data: {json.dumps({'type': 'done', 'success': False})}\n\n"
            else:
                yield f"data: {json.dumps({'type': 'log', 'message': line})}\n\n"

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ---------------------------------------------------------------------------
# Merge Partitions (repartition to single partition + format)
# ---------------------------------------------------------------------------

@storage_bp.route('/merge', methods=['POST'])
def merge_partitions():
    """Merge all partitions on a disk into one and format it.
    Expects JSON: { disk: 'sdb', fstype: 'ext4', label: 'MyDisk' }
    ALL partitions on disk MUST be unmounted.
    """
    data = request.json or {}
    disk_name = data.get("disk", "").strip()
    fstype = data.get("fstype", "").strip()
    label = data.get("label", "").strip()

    if not disk_name or not fstype:
        return jsonify({"error": "disk and fstype are required"}), 400

    # Validate disk name (only base disk, no partition numbers)
    if not _validate_disk_name(disk_name):
        return jsonify({"error": "Invalid disk name (provide base disk e.g. sdb, not a partition)"}), 400

    if fstype not in MKFS_CMDS:
        return jsonify({"error": f"Unsupported filesystem: {fstype}"}), 400

    dev_path = f"/dev/{disk_name}"

    # Check device exists and is a disk
    r = host_run(f"lsblk -ndo TYPE {dev_path} 2>/dev/null")
    if r.returncode != 0:
        return jsonify({"error": f"Device {dev_path} does not exist"}), 404
    if r.stdout.strip() != 'disk':
        return jsonify({"error": f"{dev_path} is not a base disk"}), 400

    # Get all partitions on this disk
    r = host_run(f"lsblk -nlo NAME,MOUNTPOINT {dev_path} 2>/dev/null")
    if r.returncode != 0:
        return jsonify({"error": "Cannot read partitions"}), 500

    parts_mounted = []
    for line in r.stdout.strip().split('\n'):
        parts = line.split(None, 1)
        if len(parts) >= 2 and parts[1].strip():
            pname = parts[0].strip()
            mp = parts[1].strip()
            if pname != disk_name:  # Skip the disk itself
                parts_mounted.append(f"{pname} → {mp}")

    if parts_mounted:
        return jsonify({"error": f"Partitions are mounted: {', '.join(parts_mounted)}. Unmount them first."}), 400

    # Safety: refuse system disk (robust check incl. LVM)
    if _is_system_disk(disk_name):
        return jsonify({"error": "Cannot merge partitions of system disk!"}), 403

    # Build label flags
    safe_label = ""
    if label:
        safe_label = re.sub(r'[^a-zA-Z0-9_\-.]', '_', label)[:16]

    def generate():
        yield f"data: {json.dumps({'type': 'step', 'message': f'Merging partitions on {dev_path}...'})}\n\n"

        # Step 1: Wipe existing partition signatures
        yield f"data: {json.dumps({'type': 'step', 'message': 'Wiping partition table...'})}\n\n"
        for line in host_run_stream(f"wipefs -a {dev_path} 2>&1"):
            line = line.rstrip("\n")
            if line.startswith("__EXIT_CODE__:"):
                code = int(line.split(":")[1])
                if code != 0:
                    yield f"data: {json.dumps({'type': 'step', 'message': f'wipefs error (code: {code})'})}\n\n"
                    yield f"data: {json.dumps({'type': 'done', 'success': False})}\n\n"
                    return
            else:
                if line.strip():
                    yield f"data: {json.dumps({'type': 'log', 'message': line})}\n\n"

        # Step 2: Create new GPT partition table with single partition
        yield f"data: {json.dumps({'type': 'step', 'message': 'Creating new GPT partition table...'})}\n\n"
        parted_cmd = f"parted -s {dev_path} mklabel gpt mkpart primary 0% 100% 2>&1"
        for line in host_run_stream(parted_cmd):
            line = line.rstrip("\n")
            if line.startswith("__EXIT_CODE__:"):
                code = int(line.split(":")[1])
                if code != 0:
                    yield f"data: {json.dumps({'type': 'step', 'message': f'parted error (code: {code})'})}\n\n"
                    yield f"data: {json.dumps({'type': 'done', 'success': False})}\n\n"
                    return
            else:
                if line.strip():
                    yield f"data: {json.dumps({'type': 'log', 'message': line})}\n\n"

        # Wait for kernel to re-read partition table
        yield f"data: {json.dumps({'type': 'step', 'message': 'Refreshing partition table...'})}\n\n"
        host_run(f"partprobe {dev_path} 2>/dev/null")
        host_run("sleep 2")

        # Determine new partition name (sdb1, nvme0n1p1, etc.)
        if 'nvme' in disk_name:
            new_part = f"{dev_path}p1"
            new_part_name = f"{disk_name}p1"
        else:
            new_part = f"{dev_path}1"
            new_part_name = f"{disk_name}1"

        # Auto-unmount in case devmon/udisks auto-mounted the new partition
        host_run(f"umount {new_part} 2>/dev/null")
        host_run("sleep 1")

        # Verify new partition exists
        r2 = host_run(f"lsblk -no NAME {new_part} 2>/dev/null")
        if r2.returncode != 0:
            yield f"data: {json.dumps({'type': 'step', 'message': f'Partition {new_part} was not created'})}\n\n"
            yield f"data: {json.dumps({'type': 'done', 'success': False})}\n\n"
            return

        yield f"data: {json.dumps({'type': 'step', 'message': f'Created partition {new_part_name}'})}\n\n"

        # Step 3: Format the new partition
        mkfs_base = MKFS_CMDS[fstype]
        label_flag = ""
        if safe_label:
            if fstype in ("ext4", "ext3", "btrfs", "f2fs", "xfs"):
                label_flag = f"-L {Q(safe_label)}"
            elif fstype == "ntfs":
                label_flag = f"-L {Q(safe_label)}"
            elif fstype in ("exfat", "vfat"):
                label_flag = f"-n {Q(safe_label[:11])}"

        fmt_cmd = f"{mkfs_base} {label_flag} {new_part} 2>&1"
        yield f"data: {json.dumps({'type': 'step', 'message': f'Formatting as {fstype}...'})}\n\n"

        for line in host_run_stream(fmt_cmd):
            line = line.rstrip("\n")
            if line.startswith("__EXIT_CODE__:"):
                code = int(line.split(":")[1])
                if code == 0:
                    if fstype in ('ext4', 'ext3', 'ext2'):
                        host_run(f'tune2fs -c 30 -i 90d {new_part} 2>/dev/null', timeout=10)
                    yield f"data: {json.dumps({'type': 'step', 'message': 'Format completed successfully!'})}\n\n"
                    yield f"data: {json.dumps({'type': 'done', 'success': True, 'partition': new_part_name})}\n\n"
                else:
                    yield f"data: {json.dumps({'type': 'step', 'message': f'Format error (code: {code})'})}\n\n"
                    yield f"data: {json.dumps({'type': 'done', 'success': False})}\n\n"
            else:
                if line.strip():
                    yield f"data: {json.dumps({'type': 'log', 'message': line})}\n\n"

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ---------------------------------------------------------------------------
# Split / Partition a Disk
# ---------------------------------------------------------------------------

@storage_bp.route('/partition', methods=['POST'])
def partition_disk():
    """Repartition a disk into multiple partitions and format each.
    Expects JSON: {
        disk: 'sdb',
        partitions: [
            { size_mb: 50000, fstype: 'ext4', label: 'Dane' },
            { size_mb: 0, fstype: 'ntfs', label: 'Media' },   // 0 = remaining space
        ]
    }
    ALL existing partitions MUST be unmounted.
    """
    data = request.json or {}
    disk_name = data.get("disk", "").strip()
    partitions = data.get("partitions", [])

    if not disk_name:
        return jsonify({"error": "Disk name is required"}), 400
    if not partitions or len(partitions) < 1:
        return jsonify({"error": "Provide at least one partition"}), 400
    if len(partitions) > 8:
        return jsonify({"error": "Maximum 8 partitions"}), 400

    # Validate disk name
    if not _validate_disk_name(disk_name):
        return jsonify({"error": "Invalid disk name"}), 400

    # Validate each partition
    for i, p in enumerate(partitions):
        fs = p.get("fstype", "").strip()
        if not fs:
            return jsonify({"error": f"Partition {i+1}: no filesystem specified"}), 400
        if fs not in MKFS_CMDS:
            return jsonify({"error": f"Partition {i+1}: unsupported filesystem '{fs}'"}), 400

    # Count how many use size_mb=0 (remaining space)
    remaining_count = sum(1 for p in partitions if not p.get("size_mb"))
    if remaining_count > 1:
        return jsonify({"error": "Only one partition can use 'remaining space'"}), 400

    dev_path = f"/dev/{disk_name}"

    # Check device exists and is a disk
    r = host_run(f"lsblk -ndo TYPE {dev_path} 2>/dev/null")
    if r.returncode != 0:
        return jsonify({"error": f"Device {dev_path} does not exist"}), 404
    if r.stdout.strip() != 'disk':
        return jsonify({"error": f"{dev_path} is not a base disk"}), 400

    # Get disk size in bytes
    r = host_run(f"lsblk -ndbo SIZE {dev_path} 2>/dev/null")
    if r.returncode != 0:
        return jsonify({"error": "Cannot read disk size"}), 500
    disk_bytes = int(r.stdout.strip())
    disk_mb = disk_bytes // (1024 * 1024)

    # Validate total size
    total_requested_mb = sum(p.get("size_mb", 0) for p in partitions)
    if total_requested_mb > disk_mb:
        return jsonify({"error": f"Total partition size ({total_requested_mb} MB) exceeds disk size ({disk_mb} MB)"}), 400

    # Check all partitions unmounted
    r = host_run(f"lsblk -nlo NAME,MOUNTPOINT {dev_path} 2>/dev/null")
    if r.returncode == 0:
        for line in r.stdout.strip().split('\n'):
            cols = line.split(None, 1)
            if len(cols) >= 2 and cols[1].strip() and cols[0].strip() != disk_name:
                return jsonify({"error": f"Partition {cols[0].strip()} is mounted on {cols[1].strip()}. Unmount first."}), 400

    # Safety: refuse system disk (robust check incl. LVM)
    if _is_system_disk(disk_name):
        return jsonify({"error": "Cannot partition system disk!"}), 403

    def _label_flag(fstype, label):
        if not label:
            return ""
        safe = re.sub(r'[^a-zA-Z0-9_\-.]', '_', label)[:16]
        if fstype in ("ext4", "ext3", "btrfs", "f2fs", "xfs", "ntfs"):
            return f"-L {Q(safe)}"
        elif fstype in ("exfat", "vfat"):
            return f"-n {Q(safe[:11])}"
        return ""

    def generate():
        yield f"data: {json.dumps({'type': 'step', 'message': f'Partitioning {dev_path} into {len(partitions)} partitions...'})}\n\n"

        # Step 1: Wipe
        yield f"data: {json.dumps({'type': 'step', 'message': 'Wiping partition table...'})}\n\n"
        for line in host_run_stream(f"wipefs -a {dev_path} 2>&1"):
            line = line.rstrip("\n")
            if line.startswith("__EXIT_CODE__:"):
                if int(line.split(":")[1]) != 0:
                    yield f"data: {json.dumps({'type': 'step', 'message': 'wipefs error'})}\n\n"
                    yield f"data: {json.dumps({'type': 'done', 'success': False})}\n\n"
                    return
            elif line.strip():
                yield f"data: {json.dumps({'type': 'log', 'message': line})}\n\n"

        # Step 2: Create GPT label
        yield f"data: {json.dumps({'type': 'step', 'message': 'Creating GPT table...'})}\n\n"
        for line in host_run_stream(f"parted -s {dev_path} mklabel gpt 2>&1"):
            line = line.rstrip("\n")
            if line.startswith("__EXIT_CODE__:"):
                if int(line.split(":")[1]) != 0:
                    yield f"data: {json.dumps({'type': 'step', 'message': 'parted mklabel error'})}\n\n"
                    yield f"data: {json.dumps({'type': 'done', 'success': False})}\n\n"
                    return
            elif line.strip():
                yield f"data: {json.dumps({'type': 'log', 'message': line})}\n\n"

        # Step 3: Create partitions
        # Build parted mkpart commands with MB offsets
        offset_mb = 1  # Start at 1 MiB for alignment
        part_specs = []
        for i, p in enumerate(partitions):
            size_mb = p.get("size_mb", 0)
            if size_mb > 0:
                end_mb = offset_mb + size_mb
                part_specs.append((offset_mb, end_mb, p))
                offset_mb = end_mb
            else:
                # Remaining space — use 100%
                part_specs.append((offset_mb, -1, p))  # -1 means "100%"

        for idx, (start, end, p) in enumerate(part_specs):
            pnum = idx + 1
            end_str = "100%" if end == -1 else f"{end}MiB"
            parted_cmd = f"parted -s {dev_path} mkpart primary {start}MiB {end_str} 2>&1"
            yield f"data: {json.dumps({'type': 'step', 'message': f'Creating partition {pnum}/{len(partitions)}...'})}\n\n"
            for line in host_run_stream(parted_cmd):
                line = line.rstrip("\n")
                if line.startswith("__EXIT_CODE__:"):
                    if int(line.split(":")[1]) != 0:
                        yield f"data: {json.dumps({'type': 'step', 'message': f'Error creating partition {pnum}'})}\n\n"
                        yield f"data: {json.dumps({'type': 'done', 'success': False})}\n\n"
                        return
                elif line.strip():
                    yield f"data: {json.dumps({'type': 'log', 'message': line})}\n\n"

        # Step 4: Re-read partition table
        yield f"data: {json.dumps({'type': 'step', 'message': 'Refreshing partition table...'})}\n\n"
        host_run(f"partprobe {dev_path} 2>/dev/null")
        host_run("sleep 2")

        # Auto-unmount any auto-mounted partitions (devmon/udisks)
        for idx in range(len(partitions)):
            pnum = idx + 1
            if 'nvme' in disk_name:
                pdev = f"{dev_path}p{pnum}"
            else:
                pdev = f"{dev_path}{pnum}"
            host_run(f"umount {pdev} 2>/dev/null")
        host_run("sleep 1")

        # Step 5: Format each partition
        created = []
        for idx, (_, _, p) in enumerate(part_specs):
            pnum = idx + 1
            if 'nvme' in disk_name:
                pdev = f"{dev_path}p{pnum}"
                pname = f"{disk_name}p{pnum}"
            else:
                pdev = f"{dev_path}{pnum}"
                pname = f"{disk_name}{pnum}"

            fstype = p.get("fstype", "ext4")
            label = p.get("label", "").strip()
            mkfs_base = MKFS_CMDS[fstype]
            lbl = _label_flag(fstype, label)

            yield f"data: {json.dumps({'type': 'step', 'message': f'Formatting {pname} as {fstype}...'})}\n\n"

            fmt_ok = False
            for line in host_run_stream(f"{mkfs_base} {lbl} {pdev} 2>&1"):
                line = line.rstrip("\n")
                if line.startswith("__EXIT_CODE__:"):
                    code = int(line.split(":")[1])
                    if code == 0:
                        fmt_ok = True
                        yield f"data: {json.dumps({'type': 'step', 'message': f'{pname} formatted ✓'})}\n\n"
                    else:
                        yield f"data: {json.dumps({'type': 'step', 'message': f'Format error for {pname} (code: {code})'})}\n\n"
                        yield f"data: {json.dumps({'type': 'done', 'success': False})}\n\n"
                        return
                elif line.strip():
                    yield f"data: {json.dumps({'type': 'log', 'message': line})}\n\n"

            created.append(pname)

        parts_str = ", ".join(created)
        yield f"data: {json.dumps({'type': 'step', 'message': f'Partitioning complete! Created: {parts_str}'})}\n\n"
        yield f"data: {json.dumps({'type': 'done', 'success': True, 'partitions': created})}\n\n"

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ---------------------------------------------------------------------------
# Filesystem Dependencies
# ---------------------------------------------------------------------------

FS_DEPS = {
    "ntfs": {"label": "NTFS (ntfs-3g)", "check": "command -v ntfs-3g", "packages": "ntfs-3g"},
    "ntfs3": {"label": "NTFS3 (kernel)", "check": "modprobe -n ntfs3 2>/dev/null", "packages": "linux-modules-extra-$(uname -r)"},
    "exfat": {"label": "exFAT", "check": "command -v mount.exfat || command -v mount.exfat-fuse", "packages": "exfat-fuse exfatprogs"},
    "btrfs": {"label": "Btrfs", "check": "command -v btrfs", "packages": "btrfs-progs"},
    "xfs": {"label": "XFS", "check": "command -v xfs_repair", "packages": "xfsprogs"},
    "hfsplus": {"label": "HFS+", "check": "command -v fsck.hfsplus", "packages": "hfsplus hfsutils hfsprogs"},
    "f2fs": {"label": "F2FS", "check": "command -v fsck.f2fs", "packages": "f2fs-tools"},
}


@storage_bp.route('/deps')
def check_deps():
    results = []
    for fs, info in FS_DEPS.items():
        r = host_run(info["check"])
        results.append({
            "fs": fs,
            "label": info["label"],
            "installed": r.returncode == 0,
            "packages": info["packages"],
        })
    return jsonify(results)


@storage_bp.route('/deps/install', methods=['POST'])
def install_deps():
    data = request.json or {}
    packages_str = data.get("packages", "")
    if not packages_str:
        return jsonify({"error": "packages is required"}), 400

    # Validate package names to prevent command injection
    # Only allow alphanumeric, hyphens, dots, colons, plus signs (valid dpkg chars)
    packages = packages_str.split()
    for pkg in packages:
        if not re.match(r'^[a-zA-Z0-9][a-zA-Z0-9.+\-:~]+$', pkg):
            return jsonify({"error": f"Invalid package name: {pkg}"}), 400
    safe_packages = ' '.join(packages)

    def generate():
        install_script = f"""
export DEBIAN_FRONTEND=noninteractive
echo '::STEP::Repairing package manager...'
dpkg --configure -a 2>/dev/null || true
echo '::STEP::Updating package lists...'
apt-get update -y 2>&1
echo '::STEP::Installing {safe_packages}...'
apt-get install -y {safe_packages} 2>&1
echo '::STEP::Installation complete!'
echo '::DONE::'
"""
        for line in host_run_stream(install_script):
            line = line.rstrip("\n")
            if line.startswith("__EXIT_CODE__:"):
                code = line.split(":")[1]
                yield f"data: {json.dumps({'type': 'exit', 'code': int(code)})}\n\n"
            elif line.startswith("::STEP::"):
                yield f"data: {json.dumps({'type': 'step', 'message': line[8:]})}\n\n"
            elif line.startswith("::DONE::"):
                yield f"data: {json.dumps({'type': 'done'})}\n\n"
            else:
                yield f"data: {json.dumps({'type': 'log', 'message': line})}\n\n"

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ---------------------------------------------------------------------------
# API – Disk Usage Analytics
# ---------------------------------------------------------------------------

def _fmt_bytes(n):
    """Human-readable bytes."""
    return fmt_bytes(n)


@storage_bp.route('/analyze')
def analyze_path():
    """Analyze disk usage of a directory. Returns top-level children with sizes.
    Query params: path (required), limit (default 50)
    Uses du -k (1K blocks) which is much faster than du -b (apparent size).
    """
    path = request.args.get('path', '/')
    try:
        limit = min(int(request.args.get('limit', 50)), 200)
    except (ValueError, TypeError):
        limit = 50

    # Validate path is absolute
    if not path.startswith('/'):
        return jsonify({"error": "Path must be absolute"}), 400

    # du -k --max-depth=1: list direct children sizes in KB
    # Use -x (stay on same fs) for root-level paths that might have mounts under them
    # Don't use -x for specific mount points (user wants to scan that drive)
    use_x = path in ('/', '/home', '/var', '/usr', '/opt', '/tmp', '/root')
    x_flag = 'x' if use_x else ''
    cmd = f"du -k{x_flag} --max-depth=1 {Q(path)} 2>/dev/null | sort -rn | head -n {limit + 1}"
    r = host_run(cmd, timeout=90)
    if r.returncode != 0 and not r.stdout.strip():
        return jsonify({"error": "Cannot analyze path", "detail": r.stderr.strip()}), 400

    entries = []
    total_size = 0
    norm_path = path.rstrip('/')
    for line in r.stdout.strip().split('\n'):
        if not line.strip():
            continue
        parts = line.split('\t', 1)
        if len(parts) != 2:
            continue
        try:
            size_kb = int(parts[0])
        except ValueError:
            continue
        entry_path = parts[1].strip()
        size_bytes = size_kb * 1024

        ep_norm = entry_path.rstrip('/')
        if ep_norm == norm_path or ep_norm == '':
            total_size = size_bytes
            continue

        name = ep_norm[len(norm_path):].lstrip('/')
        if not name or '/' in name:
            continue

        entries.append({
            'path': entry_path,
            'name': name,
            'size': size_bytes,
            'size_human': _fmt_bytes(size_bytes),
        })

    # Compute percentages
    for e in entries:
        e['percent'] = round((e['size'] / total_size * 100) if total_size > 0 else 0, 1)

    return jsonify({
        'path': path,
        'total_size': total_size,
        'total_size_human': _fmt_bytes(total_size),
        'entries': entries[:limit],
    })


@storage_bp.route('/analyze/files')
def analyze_files():
    """Find the largest files in a directory.
    Query params: path (required), limit (default 50)
    """
    path = request.args.get('path', '/')
    try:
        limit = min(int(request.args.get('limit', 50)), 200)
    except (ValueError, TypeError):
        limit = 50

    if not path.startswith('/'):
        return jsonify({"error": "Path must be absolute"}), 400

    cmd = (
        f"find {Q(path)} -xdev -maxdepth 8 -type f -printf '%s\\t%T@\\t%p\\n' 2>/dev/null | "
        f"sort -rn | head -n {limit}"
    )
    r = host_run(cmd, timeout=90)
    if r.returncode != 0 and not r.stdout.strip():
        return jsonify({"error": "Cannot scan files", "detail": r.stderr.strip()}), 400

    files = []
    for line in r.stdout.strip().split('\n'):
        if not line.strip():
            continue
        parts = line.split('\t', 2)
        if len(parts) < 3:
            continue
        try:
            size = int(parts[0])
            mtime = float(parts[1])
        except ValueError:
            continue
        fpath = parts[2].strip()
        name = os.path.basename(fpath)
        ext = os.path.splitext(name)[1].lower()

        files.append({
            'path': fpath,
            'name': name,
            'ext': ext,
            'size': size,
            'size_human': _fmt_bytes(size),
            'modified': mtime,
        })

    return jsonify({
        'path': path,
        'files': files,
    })


# ---------------------------------------------------------------------------
# Storage Pool Wizard — endpoints
# ---------------------------------------------------------------------------

_POOLS_FILE = data_path('storage_pools.json')


def _load_pools():
    try:
        with open(_POOLS_FILE, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []


def _save_pools(pools):
    os.makedirs(os.path.dirname(_POOLS_FILE), exist_ok=True)
    with open(_POOLS_FILE, 'w') as f:
        json.dump(pools, f, indent=2)


@storage_bp.route('/pool/available-disks')
def pool_available_disks():
    """List disks/partitions available for pool creation.
    Excludes: system disks, mounted, RAID members, LVM PVs."""

    r = host_run(
        "lsblk -J -b -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT,LABEL,MODEL,TRAN,UUID,HOTPLUG,PKNAME"
    )
    if r.returncode != 0:
        return jsonify({"error": r.stderr.strip()}), 500
    try:
        data = json.loads(r.stdout)
    except json.JSONDecodeError:
        return jsonify({"error": "Failed to parse lsblk"}), 500

    # Collect RAID members
    raid_members = set()
    md_r = host_run("cat /proc/mdstat 2>/dev/null")
    if md_r.returncode == 0:
        for line in md_r.stdout.splitlines():
            for m in re.findall(r'(\w+)\[\d+\]', line):
                raid_members.add(m)

    # Collect LVM PVs
    lvm_pvs = set()
    pv_r = host_run("pvs --noheadings -o pv_name 2>/dev/null")
    if pv_r.returncode == 0:
        for line in pv_r.stdout.strip().splitlines():
            dev = line.strip().replace('/dev/', '')
            if dev:
                lvm_pvs.add(dev)

    available = []

    def _check(dev, parent=None):
        name = dev.get('name', '')
        dtype = dev.get('type', '')
        children = dev.get('children', [])

        if dtype in ('loop', 'rom') or name.startswith('loop') or name.startswith('nbd') or name.startswith('zram'):
            return

        # For whole disks with partitions — skip the disk itself,
        # only offer whole disks without partitions
        if dtype == 'disk' and children:
            for c in children:
                _check(c, parent=dev)
            return

        if dtype == 'disk' and not children:
            # Whole disk without partitions — candidate
            pass
        elif dtype == 'part':
            pass
        else:
            return

        # Skip system disks
        if _is_system_disk(name):
            return
        base = re.sub(r'p?\d+$', '', name)
        if base != name and _is_system_disk(base):
            return

        # Skip mounted
        if dev.get('mountpoint'):
            return

        # Skip RAID members
        if name in raid_members:
            return

        # Skip LVM PVs
        if name in lvm_pvs:
            return

        p = parent or dev
        tran = p.get('tran') or dev.get('tran') or ''
        model = (p.get('model') or dev.get('model') or '').strip()
        size_bytes = 0
        try:
            size_bytes = int(dev.get('size', 0))
        except (ValueError, TypeError):
            pass

        # Skip zero-size devices
        if size_bytes <= 0:
            return

        available.append({
            'name': name,
            'device': f'/dev/{name}',
            'size_bytes': size_bytes,
            'size': _fmt_bytes(size_bytes) if size_bytes else dev.get('size', '?'),
            'type': dtype,
            'model': model or None,
            'tran': tran,
            'removable': bool(p.get('hotplug') or dev.get('hotplug')),
            'fstype': dev.get('fstype'),
            'label': dev.get('label'),
        })

    for dev in data.get('blockdevices', []):
        _check(dev)

    return jsonify({'disks': available})


@storage_bp.route('/pool/create', methods=['POST'])
@admin_required
def pool_create():
    """Create a storage pool: [RAID] + format + mount + fstab + [Samba share].
    Streams progress via SSE."""
    data = request.get_json(force=True)

    disks = data.get('disks', [])
    raid_level = data.get('raid_level')  # None for single disk
    fstype = data.get('fstype', 'ext4')
    pool_name = data.get('name', '').strip()
    mount_path = data.get('mount_path', '').strip()
    samba = data.get('samba', False)
    samba_name = data.get('samba_name', '').strip()

    # --- Validation ---
    if not disks:
        return jsonify({"error": "No disks selected"}), 400
    if not pool_name or not re.match(r'^[a-zA-Z0-9][a-zA-Z0-9 _\-]{0,63}$', pool_name):
        return jsonify({"error": "Invalid pool name"}), 400
    if fstype not in ('ext4', 'btrfs'):
        return jsonify({"error": "Unsupported filesystem (ext4 or btrfs)"}), 400
    if not mount_path or not mount_path.startswith('/') or '..' in mount_path:
        return jsonify({"error": "Invalid mount path"}), 400
    mount_path = _sanitize_mount_path(mount_path)

    for d in disks:
        if not re.match(r'^[a-zA-Z0-9]+$', d):
            return jsonify({"error": f"Invalid disk name: {d}"}), 400

    if len(disks) > 1 and not raid_level:
        return jsonify({"error": "RAID level required for multiple disks"}), 400
    if raid_level and raid_level not in ('0', '1', '5', '6', '10'):
        return jsonify({"error": f"Invalid RAID level: {raid_level}"}), 400

    min_devs = {'0': 2, '1': 2, '5': 3, '6': 4, '10': 4}
    if raid_level and len(disks) < min_devs.get(raid_level, 2):
        return jsonify({"error": f"RAID {raid_level} requires at least {min_devs[raid_level]} disks"}), 400

    # Block USB/removable disks in RAID arrays
    if raid_level:
        r_chk = host_run(
            "lsblk -J -o NAME,TRAN,HOTPLUG "
            + " ".join(f"/dev/{Q(d)}" for d in disks)
        )
        if r_chk.returncode == 0:
            try:
                chk_data = json.loads(r_chk.stdout)
                for bdev in chk_data.get("blockdevices", []):
                    if bdev.get("tran") == "usb" or bdev.get("hotplug"):
                        return jsonify({
                            "error": f"USB/removable disk /dev/{bdev['name']} cannot be used in RAID. "
                                     "Create a single-disk pool instead."
                        }), 400
            except (json.JSONDecodeError, KeyError):
                pass

    def _sse(msg_type, message, **extra):
        payload = {'type': msg_type, 'message': message}
        payload.update(extra)
        return f"data: {json.dumps(payload)}\n\n"

    def generate():
        target_dev = None

        # ── Step 1: RAID creation (if multi-disk) ──
        if len(disks) > 1 and raid_level:
            yield _sse('step', f'Creating RAID {raid_level} with {len(disks)} disks...')

            # Wipe existing signatures
            for d in disks:
                host_run(f"wipefs -a /dev/{Q(d)} 2>/dev/null", timeout=10)
                host_run(f"mdadm --zero-superblock /dev/{Q(d)} 2>/dev/null", timeout=10)

            # Find free md name
            existing = set()
            md_r = host_run("cat /proc/mdstat 2>/dev/null")
            if md_r.returncode == 0:
                for line in md_r.stdout.splitlines():
                    m = re.match(r'^(md\d+)', line)
                    if m:
                        existing.add(m.group(1))
            md_name = None
            for i in range(128):
                cand = f'md{i}'
                if cand not in existing:
                    md_name = cand
                    break
            if not md_name:
                yield _sse('error', 'No free md device numbers')
                yield _sse('done', 'Failed', success=False)
                return

            dev_args = ' '.join(f'/dev/{Q(d)}' for d in disks)
            cmd = (
                f'yes | mdadm --create /dev/{md_name} '
                f'--level={Q(raid_level)} '
                f'--raid-devices={len(disks)} '
                f'--run --force {dev_args} 2>&1'
            )
            r = host_run(cmd, timeout=120)
            if r.returncode != 0:
                yield _sse('error', f'RAID creation failed: {r.stderr.strip() or r.stdout.strip()}')
                yield _sse('done', 'Failed', success=False)
                return

            # Save mdadm config
            host_run('mdadm --detail --scan >> /etc/mdadm/mdadm.conf 2>/dev/null || true')
            host_run('update-initramfs -u 2>/dev/null || true', timeout=120)

            target_dev = f'/dev/{md_name}'
            yield _sse('step', f'RAID {raid_level} array created: {target_dev}', device=target_dev)

            # Wait for RAID to become available
            time.sleep(2)
        else:
            # Single disk
            d = disks[0]
            target_dev = f'/dev/{d}'
            yield _sse('step', f'Using disk: {target_dev}')

            # Wipe signatures on single disk too
            host_run(f"wipefs -a {Q(target_dev)} 2>/dev/null", timeout=10)

        # ── Step 2: Format ──
        yield _sse('step', f'Formatting {target_dev} as {fstype}...')

        label_safe = re.sub(r'[^a-zA-Z0-9_\-.]', '_', pool_name)[:16]
        if fstype == 'ext4':
            mkfs_cmd = f"mkfs.ext4 -F -L {Q(label_safe)} {Q(target_dev)} 2>&1"
        else:
            mkfs_cmd = f"mkfs.btrfs -f -L {Q(label_safe)} {Q(target_dev)} 2>&1"

        for line in host_run_stream(mkfs_cmd):
            line = line.rstrip('\n')
            if line.startswith('__EXIT_CODE__:'):
                code = int(line.split(':')[1])
                if code != 0:
                    yield _sse('error', f'Format failed (exit code {code})')
                    yield _sse('done', 'Failed', success=False)
                    return
            else:
                if line.strip():
                    yield _sse('log', line)

        # ext4 tuning
        if fstype == 'ext4':
            host_run(f'tune2fs -c 30 -i 90d {Q(target_dev)} 2>/dev/null', timeout=10)

        yield _sse('step', 'Format completed')

        # ── Step 3: Mount ──
        yield _sse('step', f'Mounting to {mount_path}...')

        host_run(f"mkdir -p {Q(mount_path)}")
        if fstype == 'ext4':
            mount_opts = 'defaults,nofail,noatime,commit=60'
        else:
            mount_opts = 'defaults,nofail,noatime'

        r = host_run(f"mount -t {fstype} -o {mount_opts} {Q(target_dev)} {Q(mount_path)}")
        if r.returncode != 0:
            yield _sse('error', f'Mount failed: {r.stderr.strip()}')
            yield _sse('done', 'Failed', success=False)
            return

        # Set permissions
        host_run(f"chmod 0777 {Q(mount_path)}")
        uid_r = host_run("id -u")
        gid_r = host_run("id -g")
        uid = uid_r.stdout.strip() or '1000'
        gid = gid_r.stdout.strip() or '1000'
        host_run(f"chown {uid}:{gid} {Q(mount_path)}")

        yield _sse('step', f'Mounted at {mount_path}')

        # ── Step 4: fstab ──
        yield _sse('step', 'Adding to fstab for auto-mount on boot...')

        uuid_r = host_run(f"blkid -s UUID -o value {Q(target_dev)}")
        uuid = uuid_r.stdout.strip()
        if uuid:
            _fstab_add(uuid, mount_path, fstype, mount_opts)
            yield _sse('step', 'Added to fstab')
        else:
            yield _sse('log', 'Warning: UUID not found, skipping fstab')

        # ── Step 5: Samba share ──
        if samba and samba_name:
            yield _sse('step', f'Creating Samba share "{samba_name}"...')

            smbd_check = host_run("command -v smbd")
            if smbd_check.returncode != 0:
                yield _sse('log', 'Samba not installed — skipping share creation')
            else:
                safe_samba = re.sub(r'[^a-zA-Z0-9 _\-]', '_', samba_name)[:64]
                uid_r2 = host_run("id -un")
                user = uid_r2.stdout.strip() or "nobody"
                gid_r2 = host_run("id -gn")
                group = gid_r2.stdout.strip() or "nogroup"
                if user == "root":
                    user, group = _detect_primary_user()

                subnet = _detect_lan_subnet()
                ifaces = _detect_lan_interfaces()
                share_conf = {
                    "name": safe_samba,
                    "path": mount_path,
                    "guest_ok": "no",
                    "writable": "yes",
                    "user": user,
                    "group": group,
                    "subnet": subnet,
                    "ifaces": ifaces,
                }
                _host_write_json('/tmp/_samba_params.json', share_conf)

                script = """import json, re
NL = chr(10)
params = json.loads(open('/tmp/_samba_params.json').read())
name = params['name']
path = params['path']
guest = params['guest_ok']
user = params['user']
group = params['group']
subnet = params['subnet']
ifaces = params.get('ifaces', 'eth0')
try:
    conf = open('/etc/samba/smb.conf').read()
except FileNotFoundError:
    conf = ''

GLOBAL_DEFAULTS = {
    'workgroup': 'WORKGROUP',
    'server string': 'EthOS NAS',
    'security': 'user',
    'map to guest': 'Bad User',
    'guest account': 'nobody',
    'server min protocol': 'SMB3',
    'server signing': 'mandatory',
    'smb encrypt': 'if_required',
    'dns proxy': 'no',
    'interfaces': f'127.0.0.0/8 {ifaces}',
    'bind interfaces only': 'yes',
    'hosts allow': f'127.0.0.1 {subnet}',
    'hosts deny': '0.0.0.0/0',
}
if '[global]' not in conf:
    header = '[global]' + NL
    for k, v in GLOBAL_DEFAULTS.items():
        header += f'    {k} = {v}' + NL
    conf = header + NL + conf
else:
    gstart = conf.index('[global]')
    next_bracket = conf.find(NL + '[', gstart + 8)
    gend = next_bracket + 1 if next_bracket != -1 else len(conf)
    global_block = conf[gstart:gend]
    additions = ''
    for k, v in GLOBAL_DEFAULTS.items():
        if k not in global_block.lower():
            additions += f'    {k} = {v}' + NL
    if additions:
        insert_pos = conf.index(NL, gstart) + 1
        conf = conf[:insert_pos] + additions + conf[insert_pos:]

conf = re.sub(r'(?im)^(\\s*map to guest\\s*=\\s*).*$', r'\\1Bad User', conf)
conf = re.sub(r'(?im)^(\\s*interfaces\\s*=\\s*).*$', f'\\\\1127.0.0.0/8 {ifaces}', conf)
conf = re.sub(r'(?im)^(\\s*smb encrypt\\s*=\\s*).*$', r'\\1if_required', conf)

pattern = r'\\[' + re.escape(name) + r'\\][^\\[]*'
conf = re.sub(pattern, '', conf, flags=re.IGNORECASE)
conf = conf.rstrip() + NL + NL
block = f'[{name}]' + NL
block += f'    path = {path}' + NL
block += '    browseable = yes' + NL
block += '    writable = yes' + NL
block += '    read only = no' + NL
block += f'    guest ok = {guest}' + NL
block += f'    force user = {user}' + NL
block += f'    force group = {group}' + NL
block += '    create mask = 0664' + NL
block += '    directory mask = 0775' + NL
open('/etc/samba/smb.conf', 'w').write(conf + block)
import os
os.makedirs(path, mode=0o775, exist_ok=True)
"""
                _host_write_script('/tmp/_samba_edit.py', script)
                r = host_run("python3 /tmp/_samba_edit.py")
                host_run("rm -f /tmp/_samba_edit.py /tmp/_samba_params.json 2>/dev/null")

                if r.returncode != 0:
                    yield _sse('log', f'Samba share creation failed: {r.stderr.strip()}')
                else:
                    host_run("systemctl restart smbd nmbd 2>/dev/null || systemctl restart smb nmb 2>/dev/null || true")
                    yield _sse('step', f'Samba share "{safe_samba}" created')

        # ── Save pool config ──
        pools = _load_pools()
        pool_entry = {
            'name': pool_name,
            'created': time.strftime('%Y-%m-%dT%H:%M:%S'),
            'disks': disks,
            'raid_level': raid_level,
            'raid_device': target_dev if (len(disks) > 1 and raid_level) else None,
            'fstype': fstype,
            'mount_path': mount_path,
            'samba_share': samba_name if samba else None,
            'device': target_dev,
        }
        pools.append(pool_entry)
        _save_pools(pools)

        yield _sse('step', 'Pool configuration saved')
        yield _sse('done', f'Pool "{pool_name}" is ready!', success=True, pool=pool_entry)

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@storage_bp.route('/pool/list')
def pool_list():
    """List saved storage pools with live usage, RAID health, and shares.

    Always includes the system data volume (/mnt/data) as the first pool,
    matching Synology's model where Volume 1 is always visible.
    """
    pools = _load_pools()

    # Gather live df data for all mountpoints
    df_map = {}
    dfr = host_run("df -B1 --output=target,size,used,avail,pcent 2>/dev/null")
    if dfr.returncode == 0:
        for line in dfr.stdout.strip().split('\n')[1:]:
            parts = line.split()
            if len(parts) >= 5:
                try:
                    df_map[parts[0]] = {
                        'total': int(parts[1]),
                        'used': int(parts[2]),
                        'free': int(parts[3]),
                        'percent': float(parts[4].replace('%', '')),
                    }
                except (ValueError, IndexError):
                    pass

    # ── System Volume (like Synology's Volume 1) ──
    # Detect where EthOS data lives: /mnt/data (production) or /opt/ethos/data fs
    sys_pool = None
    sys_mount = None
    if '/mnt/data' in df_map:
        sys_mount = '/mnt/data'
    else:
        # Dev / legacy installs: find the filesystem holding /opt/ethos/data
        data_dir = data_path()
        if os.path.isdir(data_dir):
            fmr = host_run(f"findmnt -n -o TARGET --target {Q(data_dir)} 2>/dev/null", timeout=5)
            if fmr.returncode == 0 and fmr.stdout.strip():
                sys_mount = fmr.stdout.strip()

    if sys_mount and sys_mount in df_map:
        sys_disks = []
        sys_fstype = 'ext4'
        sys_device = None
        src_r = host_run(f"findmnt -n -o SOURCE,FSTYPE {Q(sys_mount)} 2>/dev/null", timeout=5)
        if src_r.returncode == 0 and src_r.stdout.strip():
            parts = src_r.stdout.strip().split()
            src_dev = parts[0].split('[')[0]  # strip btrfs subvol suffix
            sys_device = src_dev
            if len(parts) > 1:
                sys_fstype = parts[1]
            pk_r = host_run(f"lsblk -no PKNAME {Q(src_dev)} 2>/dev/null", timeout=5)
            if pk_r.returncode == 0 and pk_r.stdout.strip():
                sys_disks = [pk_r.stdout.strip()]
            else:
                sys_disks = [src_dev.replace('/dev/', '')]
        sys_pool = {
            'name': 'Volume 1',
            'system': True,
            'created': None,
            'disks': sys_disks,
            'raid_level': None,
            'raid_device': None,
            'fstype': sys_fstype,
            'mount_path': sys_mount,
            'samba_share': None,
            'device': sys_device,
            'usage': df_map.get(sys_mount),
            'mounted': True,
            'raid_status': None,
            'shares': [],
        }

    # Gather RAID status for md devices
    raid_status = {}
    md_r = host_run("cat /proc/mdstat 2>/dev/null")
    if md_r.returncode == 0:
        for line in md_r.stdout.splitlines():
            m = re.match(r'^(md\d+)\s*:\s*active\s+(\S+)\s+(.+)', line)
            if m:
                raid_status[f'/dev/{m.group(1)}'] = {
                    'state': 'active',
                    'level': m.group(2),
                    'members_line': m.group(3),
                }

    # Gather Samba shares
    samba_shares = {}
    try:
        smb_conf = host_run("cat /etc/samba/smb.conf 2>/dev/null").stdout or ""
        current_share = None
        for line in smb_conf.splitlines():
            line_s = line.strip()
            m = re.match(r'^\[(.+)\]$', line_s)
            if m:
                name = m.group(1)
                if name.lower() != 'global':
                    current_share = name
                    samba_shares[name] = {}
                else:
                    current_share = None
            elif current_share and '=' in line_s:
                k, v = line_s.split('=', 1)
                samba_shares[current_share][k.strip().lower()] = v.strip()
    except Exception:
        pass

    # Enrich system pool with shares
    if sys_pool:
        smp = sys_pool['mount_path']
        for sname, sdata in samba_shares.items():
            sp = sdata.get('path', '')
            if sp.startswith(smp) or sp.startswith('/home'):
                sys_pool['shares'].append({
                    'name': sname,
                    'protocol': 'samba',
                    'path': sp,
                })

    # Enrich each user-created pool with live data
    for pool in pools:
        mp = pool.get('mount_path', '')
        pool['usage'] = df_map.get(mp)
        pool['mounted'] = mp in df_map

        # RAID health
        rd = pool.get('raid_device')
        if rd and rd in raid_status:
            pool['raid_status'] = raid_status[rd]['state']
        elif rd:
            pool['raid_status'] = 'inactive'
        else:
            pool['raid_status'] = None

        # Associated shares
        share_name = pool.get('samba_share')
        pool['shares'] = []
        if share_name and share_name in samba_shares:
            pool['shares'].append({
                'name': share_name,
                'protocol': 'samba',
                'path': samba_shares[share_name].get('path', mp),
            })
        # Also find any other Samba shares pointing to this mount
        for sname, sdata in samba_shares.items():
            if sdata.get('path', '').startswith(mp) and sname != share_name:
                pool['shares'].append({
                    'name': sname,
                    'protocol': 'samba',
                    'path': sdata.get('path', ''),
                })

    # System volume first, then user pools (like Synology)
    all_pools = []
    if sys_pool:
        all_pools.append(sys_pool)
    all_pools.extend(pools)

    return jsonify({'pools': all_pools})


@storage_bp.route('/pool/<pool_name>/delete', methods=['POST'])
@admin_required
def pool_delete(pool_name):
    """Delete a storage pool: unmount, remove fstab, optionally destroy RAID."""
    data = request.get_json(force=True) if request.data else {}
    wipe = data.get('wipe', False)

    pools = _load_pools()
    pool = None
    for p in pools:
        if p.get('name') == pool_name:
            pool = p
            break
    if not pool:
        return jsonify({"error": f"Pool '{pool_name}' not found"}), 404

    mp = pool.get('mount_path', '')
    device = pool.get('device', '')
    raid_dev = pool.get('raid_device')
    share_name = pool.get('samba_share')
    steps = []

    # Remove Samba share
    if share_name:
        try:
            smb_conf = host_run("cat /etc/samba/smb.conf 2>/dev/null").stdout or ""
            pattern = r'\[' + re.escape(share_name) + r'\][^\[]*'
            new_conf = re.sub(pattern, '', smb_conf, flags=re.IGNORECASE).strip() + '\n'
            _host_write_file('/tmp/_smb_del.conf', new_conf)
            host_run("cp /tmp/_smb_del.conf /etc/samba/smb.conf && rm /tmp/_smb_del.conf")
            host_run("systemctl restart smbd nmbd 2>/dev/null || true")
            steps.append(f"Removed Samba share '{share_name}'")
        except Exception as e:
            steps.append(f"Warning: Samba share removal failed: {e}")

    # Unmount
    if mp:
        host_run(f"umount -l {Q(mp)} 2>/dev/null", timeout=10)
        steps.append(f"Unmounted {mp}")

    # Remove fstab entry
    if mp:
        _fstab_remove(mp)
        # Also try UUID-based removal
        uuid_r = host_run(f"blkid -s UUID -o value {Q(device)} 2>/dev/null")
        uuid = uuid_r.stdout.strip()
        if uuid:
            host_run(f"sed -i '/UUID={uuid}/d' /etc/fstab 2>/dev/null || true")
        steps.append("Removed fstab entry")

    # Stop RAID array
    if raid_dev and wipe:
        host_run(f"mdadm --stop {Q(raid_dev)} 2>/dev/null", timeout=30)
        # Zero superblocks on member disks
        for disk in pool.get('disks', []):
            host_run(f"mdadm --zero-superblock /dev/{Q(disk)} 2>/dev/null", timeout=10)
        steps.append(f"Stopped RAID array {raid_dev}")

    # Wipe filesystem signatures
    if wipe and device:
        host_run(f"wipefs -a {Q(device)} 2>/dev/null", timeout=10)
        steps.append(f"Wiped filesystem on {device}")

    # Remove mountpoint directory
    if mp:
        host_run(f"rmdir {Q(mp)} 2>/dev/null", timeout=5)

    # Remove from saved pools
    pools = [p for p in pools if p.get('name') != pool_name]
    _save_pools(pools)
    steps.append("Pool removed from configuration")

    _invalidate_drives_cache()
    return jsonify({"ok": True, "steps": steps})


# ── Storage Health Monitor ─────────────────────────────────────────────

_HEALTH_FILE = data_path('storage_health.json')
_HEALTH_INTERVAL = 300  # 5 minutes


def _health_monitor_loop():
    """Periodic storage health check — SMART, RAID, disk usage."""
    import gevent
    gevent.sleep(60)  # Wait for system to stabilize after boot
    logger = logging.getLogger('storage')

    while True:
        try:
            alerts = []
            now = time.strftime('%Y-%m-%dT%H:%M:%S')

            # 1) SMART health check — all non-removable disks
            r = _host_run_base("lsblk -dn -o NAME,TRAN,TYPE 2>/dev/null")
            if r.returncode == 0:
                for line in r.stdout.strip().splitlines():
                    parts = line.split()
                    if len(parts) < 3:
                        continue
                    dname, tran, dtype = parts[0], parts[1] if len(parts) > 1 else '', parts[-1]
                    if dtype != 'disk' or tran == 'usb':
                        continue
                    sr = _host_run_base(f"smartctl -H /dev/{_q_imported(dname)} 2>/dev/null", timeout=15)
                    if 'FAILED' in (sr.stdout or ''):
                        alerts.append({'type': 'smart', 'level': 'error', 'disk': dname,
                                       'message': f'SMART health FAILED on /dev/{dname}'})
                    elif sr.returncode not in (0, 4) and 'PASSED' not in (sr.stdout or ''):
                        pass  # SMART not available, skip

            # 2) RAID status check
            r = _host_run_base("cat /proc/mdstat 2>/dev/null")
            if r.returncode == 0 and r.stdout:
                current_md = None
                for line in r.stdout.splitlines():
                    m = re.match(r'^(md\d+)\s*:', line)
                    if m:
                        current_md = m.group(1)
                    if current_md and '_' in line:
                        bm = re.search(r'\[([U_]+)\]', line)
                        if bm and '_' in bm.group(1):
                            alerts.append({'type': 'raid', 'level': 'error', 'array': current_md,
                                           'message': f'RAID array /dev/{current_md} is DEGRADED ({bm.group(1)})'})
                            current_md = None

            # 3) Disk usage check (>90%)
            r = _host_run_base("df -B1 --output=target,pcent 2>/dev/null | tail -n +2")
            if r.returncode == 0:
                for line in r.stdout.strip().splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    parts = line.rsplit(None, 1)
                    if len(parts) < 2:
                        continue
                    mount, pct = parts[0].strip(), parts[1].replace('%', '').strip()
                    try:
                        pval = int(pct)
                    except ValueError:
                        continue
                    if pval >= 90 and not mount.startswith(('/snap', '/run', '/sys', '/proc', '/dev')):
                        alerts.append({'type': 'disk_usage', 'level': 'warning' if pval < 95 else 'error',
                                       'mount': mount, 'percent': pval,
                                       'message': f'Disk usage at {pval}% on {mount}'})

            # Save health state
            health = {'last_check': now, 'alerts': alerts, 'ok': len(alerts) == 0}
            try:
                with open(_HEALTH_FILE, 'w') as f:
                    json.dump(health, f, indent=2)
            except Exception as e:
                logger.warning('Failed to write health file: %s', e)

            # Send notifications for new alerts
            if alerts:
                try:
                    from blueprints.notifications import send_notification, push_inbox
                    for a in alerts:
                        cat = 'smart' if a['type'] == 'smart' else 'raid' if a['type'] == 'raid' else 'storage'
                        lvl = a.get('level', 'warning')
                        send_notification('\u26a0\ufe0f Storage Alert', a['message'], category=cat, level=lvl)
                        push_inbox('Storage Alert', a['message'], msg_type=lvl, category='storage',
                                   action_app='storage-manager', action_tab='diagnostics')
                except Exception as e:
                    logger.warning('Failed to send health notification: %s', e)

            # Emit via SocketIO for live dashboard
            if _socketio:
                _socketio.emit('storage_health', health)

        except Exception as e:
            logger.warning('Health monitor error: %s', e)

        import gevent
        gevent.sleep(_HEALTH_INTERVAL)


@storage_bp.route('/health')
@admin_required
def storage_health():
    """Get current storage health status."""
    try:
        with open(_HEALTH_FILE) as f:
            return jsonify(json.load(f))
    except (FileNotFoundError, json.JSONDecodeError):
        return jsonify({'last_check': None, 'alerts': [], 'ok': True})


# ── SMART Test Scheduling ──────────────────────────────────────────────

_SMART_SCHEDULE_FILE = data_path('smart_schedule.json')


def _load_smart_schedule():
    try:
        with open(_SMART_SCHEDULE_FILE) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {'tests': []}


def _save_smart_schedule(data):
    os.makedirs(os.path.dirname(_SMART_SCHEDULE_FILE), exist_ok=True)
    with open(_SMART_SCHEDULE_FILE, 'w') as f:
        json.dump(data, f, indent=2)


@storage_bp.route('/smart/test', methods=['POST'])
@admin_required
def smart_test_trigger():
    """Trigger a SMART self-test on a disk."""
    data = request.get_json(force=True)
    disk = data.get('disk', '').strip()
    test_type = data.get('type', 'short')  # short, long, conveyance

    if not disk or not re.match(r'^[a-zA-Z0-9]+$', disk):
        return jsonify({'error': 'Invalid disk name'}), 400
    if test_type not in ('short', 'long', 'conveyance'):
        return jsonify({'error': 'Invalid test type (short/long/conveyance)'}), 400

    r = _host_run_base(f"smartctl -t {_q_imported(test_type)} /dev/{_q_imported(disk)} 2>&1", timeout=15)

    # Parse expected completion time from output
    est_minutes = None
    for line in (r.stdout or '').splitlines():
        m = re.search(r'Please wait (\d+) minutes', line)
        if m:
            est_minutes = int(m.group(1))
            break

    if r.returncode in (0, 4):
        return jsonify({'ok': True, 'message': f'{test_type} test started on /dev/{disk}',
                        'estimated_minutes': est_minutes})
    else:
        return jsonify({'error': f'Failed to start test: {(r.stdout or r.stderr or "unknown error")[:200]}'}), 500


@storage_bp.route('/smart/test/result')
@admin_required
def smart_test_result():
    """Get SMART self-test log for a disk."""
    disk = request.args.get('disk', '').strip()
    if not disk or not re.match(r'^[a-zA-Z0-9]+$', disk):
        return jsonify({'error': 'Invalid disk name'}), 400

    r = _host_run_base(f"smartctl -l selftest /dev/{_q_imported(disk)} 2>&1", timeout=15)

    tests = []
    if r.returncode in (0, 4) and r.stdout:
        in_table = False
        for line in r.stdout.splitlines():
            if 'Num' in line and 'Test_Description' in line:
                in_table = True
                continue
            if in_table and line.strip():
                parts = line.split()
                if len(parts) >= 5 and parts[0].startswith('#'):
                    test_entry = {
                        'num': parts[0],
                        'type': parts[1] if len(parts) > 1 else '',
                        'status': ' '.join(parts[2:-2]) if len(parts) > 4 else parts[2] if len(parts) > 2 else '',
                        'remaining': parts[-2] if len(parts) > 3 else '',
                        'lifetime_hours': parts[-1] if len(parts) > 4 else '',
                    }
                    tests.append(test_entry)

    # Check if a test is currently running
    running = False
    progress = None
    r2 = _host_run_base(f"smartctl -c /dev/{_q_imported(disk)} 2>&1", timeout=10)
    if r2.returncode in (0, 4) and r2.stdout:
        for line in r2.stdout.splitlines():
            if 'Self-test execution status' in line and 'progress' in line.lower():
                running = True
                m = re.search(r'(\d+)%', line)
                if m:
                    progress = 100 - int(m.group(1))  # smartctl shows remaining %, we want completed %

    return jsonify({'tests': tests, 'running': running, 'progress': progress})


@storage_bp.route('/smart/schedule', methods=['GET'])
@admin_required
def smart_schedule_list():
    """Get all scheduled SMART tests."""
    return jsonify(_load_smart_schedule())


@storage_bp.route('/smart/schedule', methods=['POST'])
@admin_required
def smart_schedule_add():
    """Add a scheduled SMART test."""
    data = request.get_json(force=True)
    disk = data.get('disk', '').strip()
    test_type = data.get('type', 'short')
    frequency = data.get('frequency', 'weekly')  # daily, weekly, monthly

    if not disk or not re.match(r'^[a-zA-Z0-9]+$', disk):
        return jsonify({'error': 'Invalid disk name'}), 400
    if test_type not in ('short', 'long', 'conveyance'):
        return jsonify({'error': 'Invalid test type'}), 400
    if frequency not in ('daily', 'weekly', 'monthly'):
        return jsonify({'error': 'Invalid frequency'}), 400

    cron_map = {
        'daily': {'minute': '0', 'hour': '3', 'dom': '*', 'month': '*', 'dow': '*'},
        'weekly': {'minute': '0', 'hour': '3', 'dom': '*', 'month': '*', 'dow': '0'},
        'monthly': {'minute': '0', 'hour': '3', 'dom': '1', 'month': '*', 'dow': '*'},
    }
    cron = cron_map[frequency]

    schedule = _load_smart_schedule()

    # Check for duplicate
    for t in schedule.get('tests', []):
        if t['disk'] == disk and t['type'] == test_type:
            return jsonify({'error': f'Test already scheduled for {disk}'}), 409

    entry = {
        'id': f'{disk}_{test_type}_{int(time.time())}',
        'disk': disk,
        'type': test_type,
        'frequency': frequency,
        'cron': cron,
        'enabled': True,
        'created': time.strftime('%Y-%m-%dT%H:%M:%S'),
        'last_run': None,
        'last_result': None,
    }
    schedule.setdefault('tests', []).append(entry)
    _save_smart_schedule(schedule)

    # Register cron job
    cmd = f"smartctl -t {test_type} /dev/{disk}"
    _register_cron_job(cron, cmd, f'SMART {test_type} test on {disk}')

    return jsonify({'ok': True, 'test': entry})


@storage_bp.route('/smart/schedule/<test_id>', methods=['DELETE'])
@admin_required
def smart_schedule_delete(test_id):
    """Remove a scheduled SMART test."""
    schedule = _load_smart_schedule()
    tests = schedule.get('tests', [])
    target = None
    for t in tests:
        if t.get('id') == test_id:
            target = t
            break

    if not target:
        return jsonify({'error': 'Scheduled test not found'}), 404

    # Remove cron job
    cmd = f"smartctl -t {target['type']} /dev/{target['disk']}"
    _unregister_cron_job(cmd)

    schedule['tests'] = [t for t in tests if t.get('id') != test_id]
    _save_smart_schedule(schedule)
    return jsonify({'ok': True})


def _register_cron_job(cron, command, description):
    """Add a cron job to root crontab. Idempotent."""
    r = _host_run_base("sudo -n crontab -l 2>/dev/null || true")
    existing = r.stdout or ''
    if command in existing:
        return  # Already exists
    line = f"# DESC: {description}\n{cron['minute']} {cron['hour']} {cron['dom']} {cron['month']} {cron['dow']} {command}\n"
    new_crontab = existing.rstrip('\n') + '\n' + line
    _host_run_base(f"echo {_q_imported(new_crontab)} | sudo -n crontab -")


def _unregister_cron_job(command):
    """Remove a cron job from root crontab by command match."""
    r = _host_run_base("sudo -n crontab -l 2>/dev/null || true")
    if not r.stdout:
        return
    lines = r.stdout.splitlines()
    filtered = []
    skip_next = False
    for line in lines:
        if skip_next:
            skip_next = False
            continue
        if command in line:
            continue
        if line.startswith('# DESC:'):
            idx = lines.index(line)
            if idx + 1 < len(lines) and command in lines[idx + 1]:
                skip_next = True
                continue
        filtered.append(line)
    new_crontab = '\n'.join(filtered) + '\n'
    _host_run_base(f"echo {_q_imported(new_crontab)} | sudo -n crontab -")


# ── Storage Maintenance ────────────────────────────────────────────────

_MAINT_DB = os.path.join(os.environ.get('ETHOS_LOG_DIR', '/opt/ethos/logs'), 'maintenance.db')
_active_maintenance = {}  # {task_id: {type, target, started, pid}}


def _init_maint_db():
    """Initialize maintenance history SQLite database."""
    import sqlite3
    conn = sqlite3.connect(_MAINT_DB)
    conn.execute('''CREATE TABLE IF NOT EXISTS maintenance_history (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        target TEXT NOT NULL,
        started TEXT NOT NULL,
        finished TEXT,
        status TEXT DEFAULT 'running',
        result TEXT,
        duration_sec REAL
    )''')
    conn.commit()
    conn.close()


_init_maint_db()


@storage_bp.route('/maintenance/start', methods=['POST'])
@admin_required
def maintenance_start():
    """Start a maintenance task: scrub, raid-check, or trim."""
    data = request.get_json(force=True)
    mtype = data.get('type', '').strip()
    target = data.get('target', '').strip()

    if mtype not in ('scrub', 'raid-check', 'trim'):
        return jsonify({'error': 'Invalid type (scrub/raid-check/trim)'}), 400
    if not target:
        return jsonify({'error': 'Target required'}), 400

    # Validate target based on type
    if mtype == 'scrub':
        if not target.startswith('/') or '..' in target:
            return jsonify({'error': 'Invalid mount path'}), 400
        r = _host_run_base(f"stat -f -c %T {_q_imported(target)} 2>/dev/null")
        if 'btrfs' not in (r.stdout or '').lower():
            return jsonify({'error': f'{target} is not a btrfs filesystem'}), 400
        cmd = f"btrfs scrub start -B {_q_imported(target)}"

    elif mtype == 'raid-check':
        if not re.match(r'^md\d+$', target):
            return jsonify({'error': 'Invalid RAID device name'}), 400
        cmd = f"echo check | sudo -n tee /sys/block/{_q_imported(target)}/md/sync_action"

    elif mtype == 'trim':
        if not target.startswith('/') or '..' in target:
            return jsonify({'error': 'Invalid mount path'}), 400
        cmd = f"fstrim -v {_q_imported(target)}"

    # Check for duplicate running task
    for tid, task in _active_maintenance.items():
        if task['type'] == mtype and task['target'] == target and task['status'] == 'running':
            return jsonify({'error': f'{mtype} already running on {target}'}), 409

    task_id = f"{mtype}_{int(time.time())}"
    started = time.strftime('%Y-%m-%dT%H:%M:%S')

    # Record in DB
    import sqlite3
    conn = sqlite3.connect(_MAINT_DB)
    conn.execute('INSERT INTO maintenance_history (id, type, target, started) VALUES (?, ?, ?, ?)',
                 (task_id, mtype, target, started))
    conn.commit()
    conn.close()

    _active_maintenance[task_id] = {'type': mtype, 'target': target, 'started': started, 'status': 'running'}

    # Run in background
    def _run_task():
        logger = logging.getLogger('storage')
        result_text = ''
        status = 'completed'
        try:
            r = _host_run_base(cmd, timeout=7200)  # 2 hour timeout for scrub
            result_text = (r.stdout or '') + (r.stderr or '')
            if r.returncode != 0:
                status = 'failed'
                result_text = f'Exit code {r.returncode}: {result_text}'
        except Exception as e:
            status = 'failed'
            result_text = str(e)

        finished = time.strftime('%Y-%m-%dT%H:%M:%S')
        duration = time.time() - time.mktime(time.strptime(started, '%Y-%m-%dT%H:%M:%S'))

        try:
            conn2 = sqlite3.connect(_MAINT_DB)
            conn2.execute('UPDATE maintenance_history SET finished=?, status=?, result=?, duration_sec=? WHERE id=?',
                          (finished, status, result_text[:2000], duration, task_id))
            conn2.commit()
            conn2.close()
        except Exception as e2:
            logger.warning('Failed to update maintenance record: %s', e2)

        _active_maintenance[task_id]['status'] = status
        _active_maintenance[task_id]['finished'] = finished
        _active_maintenance[task_id]['result'] = result_text[:500]

        # Notify on failure
        if status == 'failed':
            try:
                from blueprints.notifications import send_notification, push_inbox
                send_notification('\u26a0\ufe0f Maintenance Failed', f'{mtype} on {target} failed: {result_text[:200]}',
                                  category='storage', level='warning')
                push_inbox('Maintenance Failed', f'{mtype} on {target} failed', msg_type='warning', category='storage')
            except Exception:
                pass

        if _socketio:
            _socketio.emit('maintenance_complete', {'task_id': task_id, 'status': status, 'type': mtype, 'target': target})

    if _socketio:
        _socketio.start_background_task(_run_task)
    else:
        import gevent
        gevent.spawn(_run_task)

    return jsonify({'ok': True, 'task_id': task_id, 'message': f'{mtype} started on {target}'})


@storage_bp.route('/maintenance/status')
@admin_required
def maintenance_status():
    """Get status of active maintenance tasks + RAID sync progress."""
    tasks = []
    for tid, task in list(_active_maintenance.items()):
        entry = {**task, 'id': tid}

        # For raid-check, get sync progress from /proc/mdstat
        if task['type'] == 'raid-check' and task['status'] == 'running':
            r = _host_run_base(f"cat /sys/block/{_q_imported(task['target'])}/md/sync_completed 2>/dev/null")
            if r.returncode == 0 and '/' in (r.stdout or ''):
                parts = r.stdout.strip().split('/')
                try:
                    done, total = int(parts[0].strip()), int(parts[1].strip())
                    entry['progress'] = round(done / total * 100, 1) if total > 0 else 0
                except (ValueError, ZeroDivisionError):
                    pass
            # Check if still running
            r2 = _host_run_base(f"cat /sys/block/{_q_imported(task['target'])}/md/sync_action 2>/dev/null")
            if (r2.stdout or '').strip() == 'idle':
                task['status'] = 'completed'
                entry['status'] = 'completed'

        # For scrub, get live progress from btrfs scrub status
        if task['type'] == 'scrub' and task['status'] == 'running':
            r = _host_run_base(f"btrfs scrub status {_q_imported(task['target'])} 2>/dev/null", timeout=5)
            if r.returncode == 0:
                info = _parse_scrub_status(r.stdout or '')
                if info['pct'] > 0:
                    entry['progress'] = info['pct']
                if info['rate']:
                    entry['rate'] = info['rate']

        tasks.append(entry)

    return jsonify({'tasks': tasks})


@storage_bp.route('/maintenance/history')
@admin_required
def maintenance_history():
    """Get maintenance history from SQLite."""
    limit = request.args.get('limit', 50, type=int)
    import sqlite3
    conn = sqlite3.connect(_MAINT_DB)
    conn.row_factory = sqlite3.Row
    rows = conn.execute('SELECT * FROM maintenance_history ORDER BY started DESC LIMIT ?', (limit,)).fetchall()
    conn.close()
    return jsonify({'history': [dict(r) for r in rows]})


@storage_bp.route('/maintenance/schedule', methods=['POST'])
@admin_required
def maintenance_schedule():
    """Schedule a recurring maintenance task via cron."""
    data = request.get_json(force=True)
    mtype = data.get('type', '').strip()
    target = data.get('target', '').strip()
    frequency = data.get('frequency', 'weekly')

    if mtype not in ('scrub', 'raid-check', 'trim'):
        return jsonify({'error': 'Invalid type'}), 400
    if not target:
        return jsonify({'error': 'Target required'}), 400
    if frequency not in ('daily', 'weekly', 'monthly'):
        return jsonify({'error': 'Invalid frequency'}), 400

    cron_map = {
        'daily': {'minute': '0', 'hour': '4', 'dom': '*', 'month': '*', 'dow': '*'},
        'weekly': {'minute': '0', 'hour': '4', 'dom': '*', 'month': '*', 'dow': '0'},
        'monthly': {'minute': '0', 'hour': '4', 'dom': '1', 'month': '*', 'dow': '*'},
    }
    cron = cron_map[frequency]

    if mtype == 'scrub':
        cmd = f"btrfs scrub start {target}"
    elif mtype == 'raid-check':
        cmd = f"echo check > /sys/block/{target}/md/sync_action"
    elif mtype == 'trim':
        cmd = f"fstrim {target}"

    _register_cron_job(cron, cmd, f'Storage maintenance: {mtype} on {target}')
    return jsonify({'ok': True, 'message': f'{mtype} scheduled {frequency} on {target}'})


@storage_bp.route('/maintenance/schedules')
@admin_required
def maintenance_schedules():
    """List active maintenance cron schedules."""
    r = _host_run_base("sudo -n crontab -l 2>/dev/null || true")
    if not r.stdout:
        return jsonify({'schedules': []})

    schedules = []
    lines = r.stdout.splitlines()
    for i, line in enumerate(lines):
        if 'Storage maintenance:' not in line and not (i + 1 < len(lines) and 'Storage maintenance:' in lines[i]):
            continue
        if line.startswith('# DESC: Storage maintenance:'):
            if i + 1 < len(lines):
                cron_line = lines[i + 1]
                desc = line.replace('# DESC: Storage maintenance: ', '')
                parts = cron_line.split(None, 5)
                if len(parts) >= 6:
                    minute, hour, dom, month, dow = parts[:5]
                    cmd = parts[5]
                    # Determine frequency
                    if dom == '1' and dow == '*':
                        freq = 'monthly'
                    elif dow in ('0', '7') and dom == '*':
                        freq = 'weekly'
                    else:
                        freq = 'daily'
                    # Determine type and target from desc or command
                    mtype = 'scrub' if 'scrub' in desc else 'raid-check' if 'raid' in desc else 'trim'
                    target = desc.split(' on ')[-1] if ' on ' in desc else ''
                    schedules.append({
                        'type': mtype, 'target': target, 'frequency': freq,
                        'cron': f'{minute} {hour} {dom} {month} {dow}',
                        'command': cmd,
                    })
    return jsonify({'schedules': schedules})


@storage_bp.route('/maintenance/schedule', methods=['DELETE'])
@admin_required
def maintenance_schedule_delete():
    """Remove a maintenance schedule."""
    data = request.get_json(force=True)
    mtype = data.get('type', '').strip()
    target = data.get('target', '').strip()
    if not mtype or not target:
        return jsonify({'error': 'type and target required'}), 400

    if mtype == 'scrub':
        cmd = f"btrfs scrub start {target}"
    elif mtype == 'raid-check':
        cmd = f"echo check > /sys/block/{target}/md/sync_action"
    elif mtype == 'trim':
        cmd = f"fstrim {target}"
    else:
        return jsonify({'error': 'Invalid type'}), 400

    _unregister_cron_job(cmd)
    return jsonify({'ok': True, 'message': f'Schedule removed for {mtype} on {target}'})


def _parse_scrub_status(output):
    """Parse btrfs scrub status output into a dict."""
    info = {'status': 'unknown', 'errors': None, 'started': None,
            'duration': None, 'total_bytes': 0, 'scrubbed_bytes': 0, 'rate': None, 'pct': 0}
    if not output:
        return info
    for line in output.splitlines():
        line = line.strip()
        if line.startswith('Scrub started:'):
            info['started'] = line.split(':', 1)[1].strip()
        elif line.startswith('Status:'):
            info['status'] = line.split(':', 1)[1].strip()
        elif line.startswith('Duration:'):
            info['duration'] = line.split(':', 1)[1].strip()
        elif line.startswith('Total to scrub:'):
            raw = line.split(':', 1)[1].strip()
            info['total_str'] = raw
            info['total_bytes'] = _parse_size_to_bytes(raw)
        elif line.startswith('Bytes scrubbed:'):
            raw = line.split(':', 1)[1].strip()
            m = re.match(r'([\d.]+\s*\S+)', raw)
            if m:
                info['scrubbed_bytes'] = _parse_size_to_bytes(m.group(1))
            pct_m = re.search(r'\(([\d.]+)%\)', raw)
            if pct_m:
                info['pct'] = float(pct_m.group(1))
        elif line.startswith('Rate:'):
            info['rate'] = line.split(':', 1)[1].strip()
        elif line.startswith('Error summary:'):
            info['errors'] = line.split(':', 1)[1].strip()
        elif 'no errors found' in line.lower():
            info['errors'] = 'no errors found'
    # Calculate pct from bytes if not parsed
    if info['pct'] == 0 and info['total_bytes'] > 0 and info['scrubbed_bytes'] > 0:
        info['pct'] = round(info['scrubbed_bytes'] / info['total_bytes'] * 100, 1)
    # Finished scrub = 100%
    if info['status'] == 'finished':
        info['pct'] = 100
    return info


def _parse_size_to_bytes(s):
    """Parse '107.38GiB' or '42.15MiB' etc. to bytes."""
    s = s.strip()
    m = re.match(r'([\d.]+)\s*(GiB|MiB|KiB|TiB|GB|MB|KB|TB|B)', s, re.IGNORECASE)
    if not m:
        return 0
    val = float(m.group(1))
    unit = m.group(2).lower()
    multipliers = {'b': 1, 'kib': 1024, 'kb': 1000, 'mib': 1024**2, 'mb': 10**6,
                   'gib': 1024**3, 'gb': 10**9, 'tib': 1024**4, 'tb': 10**12}
    return int(val * multipliers.get(unit, 1))


@storage_bp.route('/maintenance/scrub-info')
@admin_required
def maintenance_scrub_info():
    """Get btrfs scrub status for all mounted btrfs pools."""
    # Get btrfs mount points from findmnt (reliable)
    r = _host_run_base("findmnt -t btrfs -n -o TARGET 2>/dev/null")
    mounts = [p.strip() for p in (r.stdout or '').splitlines() if p.strip()]

    results = []
    for mount in mounts:
        r = _host_run_base(f"btrfs scrub status {_q_imported(mount)} 2>/dev/null", timeout=10)
        info = _parse_scrub_status(r.stdout or '')
        info['mount'] = mount
        info['name'] = os.path.basename(mount) or mount
        results.append(info)

    return jsonify({'pools': results})


@storage_bp.route('/app-usage')
@admin_required
def app_usage():
    """Return disk usage per known app directory on root and data partition.
    Used by Storage Manager to show what is consuming space."""
    results = []

    def _du(path, label, partition):
        if not os.path.isdir(path) and not os.path.isfile(path):
            return None
        r = _host_run_base(f'du -sb {_q_imported(path)} 2>/dev/null | cut -f1', timeout=15)
        try:
            size = int(r.stdout.strip())
        except (ValueError, AttributeError):
            return None
        return {'label': label, 'path': path, 'bytes': size, 'partition': partition}

    # Root partition consumers
    root_apps = [
        ('/var/lib/docker',      'Docker (dane)',        '/'),
        ('/var/lib/clamav',      'ClamAV DB',            '/'),
        ('/var/lib/minidlna',    'MiniDLNA DB',          '/'),
        ('/var/lib/apt',         'APT cache/lists',      '/'),
        ('/var/cache/apt',       'APT packages cache',   '/'),
        ('/var/log',             'Logi systemowe',       '/'),
        ('/tmp',                 'Pliki tymczasowe /tmp', '/'),
        ('/opt/ethos/venv',      'Python venv',          '/'),
    ]
    for path, label, part in root_apps:
        item = _du(path, label, part)
        if item:
            results.append(item)

    # Data partition consumers
    dd = _get_data_disk()
    if dd:
        data_apps = [
            (os.path.join(dd, 'docker'),    'Docker (dane)',    dd),
            (os.path.join(dd, 'clamav'),    'ClamAV DB',        dd),
            (os.path.join(dd, 'minidlna'),  'MiniDLNA DB',      dd),
            (os.path.join(dd, 'vms'),       'VM Manager',       dd),
            (os.path.join(dd, 'ethos', 'data', 'models'),    'Modele AI',        dd),
            (os.path.join(dd, 'ethos', 'data', 'surveillance'), 'Nadzór / nagrania', dd),
            (os.path.join(dd, 'ethos', 'data', 'video_thumbs'),  'Video miniatury', dd),
            (os.path.join(dd, 'ethos', 'backups'),  'Kopie zapasowe',   dd),
            (os.path.join(dd, 'ethos', 'uploads'),  'Przesłane pliki',  dd),
        ]
        for path, label, part in data_apps:
            item = _du(path, label, part)
            if item:
                results.append(item)

    # Sort by size descending
    results.sort(key=lambda x: x['bytes'], reverse=True)
    return jsonify({'items': results})


# ---------------------------------------------------------------------------
# /tmp cleanup
# ---------------------------------------------------------------------------

@storage_bp.route('/clean-tmp', methods=['GET'])
@admin_required
def clean_tmp_info():
    """Return /tmp usage stats: total, used, free, file count, and list of top items."""
    import shutil
    usage = shutil.disk_usage('/tmp')
    items = []
    try:
        for name in os.listdir('/tmp'):
            p = os.path.join('/tmp', name)
            try:
                r = _host_run_base(f'du -sb {_q_imported(p)} 2>/dev/null | cut -f1', timeout=10)
                size = int(r.stdout.strip()) if r.returncode == 0 and r.stdout.strip() else 0
                mtime = os.path.getmtime(p)
                items.append({'name': name, 'bytes': size, 'mtime': mtime, 'is_dir': os.path.isdir(p)})
            except (OSError, ValueError):
                pass
    except OSError:
        pass
    items.sort(key=lambda x: x['bytes'], reverse=True)
    return jsonify({
        'ok': True,
        'total': usage.total,
        'used': usage.used,
        'free': usage.free,
        'pct': round(usage.used * 100 / usage.total) if usage.total else 0,
        'items': items[:50],
    })


@storage_bp.route('/clean-tmp', methods=['POST'])
@admin_required
def clean_tmp():
    """Clean /tmp files older than specified max_age_minutes (default 60).
    Skips system sockets (.X11-unix, .ICE-unix, etc.) and systemd private dirs."""
    import shutil as _shutil
    data = request.get_json(force=True, silent=True) if request.is_json else {}
    if not isinstance(data, dict):
        data = {}
    max_age = max(0, int(data.get('max_age_minutes', 60)))
    cutoff = time.time() - max_age * 60

    # Protected prefixes — never remove these
    protected = {'.X11-unix', '.ICE-unix', '.XIM-unix', '.font-unix'}

    before_free = _shutil.disk_usage('/tmp').free
    removed = 0
    errors = []

    try:
        for name in os.listdir('/tmp'):
            if name in protected or name.startswith('systemd-private-'):
                continue
            p = os.path.join('/tmp', name)
            try:
                mtime = os.path.getmtime(p)
                if mtime >= cutoff:
                    continue
                if os.path.isdir(p):
                    _shutil.rmtree(p, ignore_errors=True)
                else:
                    os.unlink(p)
                removed += 1
            except OSError as e:
                errors.append(f'{name}: {e}')
    except OSError as e:
        return jsonify({'error': f'Cannot read /tmp: {e}'}), 500

    after_free = _shutil.disk_usage('/tmp').free
    freed = after_free - before_free

    try:
        from blueprints.eventlog import elog
        elog('storage', 'info', f'/tmp cleanup: removed {removed} items, freed {freed // (1024*1024)} MB')
    except Exception:
        pass

    return jsonify({
        'ok': True,
        'removed': removed,
        'freed': freed,
        'errors': errors[:10],
        'free_after': after_free,
    })


# ---------------------------------------------------------------------------
# Network Drive Mounts (SMB / NFS / WebDAV client-side mounts)
# ---------------------------------------------------------------------------

_NETMOUNT_DIR = '/mnt/network'
_NETMOUNT_CONF = data_path('network_mounts.json')


def _load_network_mounts():
    """Load saved network mount configurations."""
    try:
        with open(_NETMOUNT_CONF, 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []


def _save_network_mounts(mounts):
    """Persist network mount configurations."""
    _host_write_json(_NETMOUNT_CONF, mounts)


def _netmount_path(mount_id):
    """Return the mount point path for a given network mount ID."""
    return os.path.join(_NETMOUNT_DIR, mount_id)


def _is_mounted(path):
    """Check if a path is currently a mount point."""
    r = host_run(f"findmnt -n -o TARGET {Q(path)} 2>/dev/null", timeout=5)
    return r.returncode == 0 and path in r.stdout.strip()


def _mount_smb(cfg):
    """Mount an SMB/CIFS share. Returns (ok, error_msg)."""
    mp = _netmount_path(cfg['id'])
    host_run(f"mkdir -p {Q(mp)}")

    host_addr = cfg['host']
    share = cfg['share']
    username = cfg.get('username', 'guest')
    password = cfg.get('password', '')
    domain = cfg.get('domain', '')

    opts = ['rw', 'iocharset=utf8', 'file_mode=0777', 'dir_mode=0777', 'noperm']
    if username and username.lower() != 'guest':
        opts.append(f'username={username}')
        if password:
            opts.append(f'password={password}')
        if domain:
            opts.append(f'domain={domain}')
    else:
        opts.extend(['guest', 'username=guest'])

    # vers=3.0 first, fallback to auto
    for ver in ('3.0', '2.1', '1.0'):
        cmd = f"mount -t cifs //{Q(host_addr)}/{Q(share)} {Q(mp)} -o {','.join(opts)},vers={ver}"
        r = host_run(cmd, timeout=15)
        if r.returncode == 0:
            return True, ''
    return False, r.stderr.strip() if r else 'Mount failed'


def _mount_nfs(cfg):
    """Mount an NFS share. Returns (ok, error_msg)."""
    mp = _netmount_path(cfg['id'])
    host_run(f"mkdir -p {Q(mp)}")

    host_addr = cfg['host']
    export_path = cfg['share']

    opts = 'rw,soft,timeo=30,retrans=3'
    cmd = f"mount -t nfs {Q(host_addr)}:{Q(export_path)} {Q(mp)} -o {opts}"
    r = host_run(cmd, timeout=15)
    if r.returncode == 0:
        return True, ''
    # Fallback: nfs4
    cmd = f"mount -t nfs4 {Q(host_addr)}:{Q(export_path)} {Q(mp)} -o {opts}"
    r = host_run(cmd, timeout=15)
    if r.returncode == 0:
        return True, ''
    return False, r.stderr.strip()


@storage_bp.route('/network/mounts')
@admin_required
def network_mount_list():
    """List all saved network mounts with their current status."""
    mounts = _load_network_mounts()
    result = []
    for m in mounts:
        mp = _netmount_path(m['id'])
        mounted = _is_mounted(mp)
        usage = None
        if mounted:
            r = host_run(f"df -B1 {Q(mp)} 2>/dev/null | tail -1", timeout=5)
            parts = r.stdout.split()
            if len(parts) >= 5:
                try:
                    total = int(parts[1])
                    used = int(parts[2])
                    usage = {
                        'total': total,
                        'used': used,
                        'percent': round(used / total * 100, 1) if total > 0 else 0,
                    }
                except (ValueError, IndexError):
                    pass
        result.append({
            'id': m['id'],
            'name': m.get('name', ''),
            'protocol': m.get('protocol', 'smb'),
            'host': m.get('host', ''),
            'share': m.get('share', ''),
            'mount_path': mp,
            'mounted': mounted,
            'auto_mount': m.get('auto_mount', False),
            'usage': usage,
        })
    return jsonify({'mounts': result})


@storage_bp.route('/network/mount', methods=['POST'])
@admin_required
def network_mount_add():
    """Add and mount a new network drive."""
    data = request.json or {}
    if not isinstance(data, dict):
        data = {}
    protocol = data.get('protocol', 'smb').lower()
    host_addr = data.get('host', '').strip()
    share = data.get('share', '').strip().strip('/')
    name = data.get('name', '').strip()
    username = data.get('username', '').strip()
    password = data.get('password', '')
    domain = data.get('domain', '').strip()
    auto_mount = bool(data.get('auto_mount', True))

    if not host_addr:
        return jsonify({'error': 'Host address is required'}), 400
    if not share:
        return jsonify({'error': 'Share name / export path is required'}), 400
    if protocol not in ('smb', 'nfs'):
        return jsonify({'error': 'Protocol must be smb or nfs'}), 400

    # Ensure cifs-utils or nfs-common is installed
    if protocol == 'smb':
        if not check_tool('mount.cifs'):
            r = _apt_install('cifs-utils', timeout=60)
            if r.returncode != 0:
                return jsonify({'error': 'Failed to install cifs-utils'}), 500
    else:
        if not check_tool('mount.nfs'):
            r = _apt_install('nfs-common', timeout=60)
            if r.returncode != 0:
                return jsonify({'error': 'Failed to install nfs-common'}), 500

    # Generate ID
    safe_host = re.sub(r'[^a-zA-Z0-9._-]', '_', host_addr)
    safe_share = re.sub(r'[^a-zA-Z0-9._-]', '_', share)
    mount_id = f"{protocol}_{safe_host}_{safe_share}"

    if not name:
        name = f"{share} on {host_addr}"

    cfg = {
        'id': mount_id,
        'name': name,
        'protocol': protocol,
        'host': host_addr,
        'share': share,
        'username': username,
        'password': password,
        'domain': domain,
        'auto_mount': auto_mount,
    }

    # Check for duplicate
    mounts = _load_network_mounts()
    mounts = [m for m in mounts if m['id'] != mount_id]

    # Try to mount
    mp = _netmount_path(mount_id)
    if _is_mounted(mp):
        host_run(f"umount -l {Q(mp)}", timeout=10)

    if protocol == 'smb':
        ok, err = _mount_smb(cfg)
    else:
        ok, err = _mount_nfs(cfg)

    if not ok:
        host_run(f"rmdir {Q(mp)} 2>/dev/null", timeout=3)
        return jsonify({'error': f'Mount failed: {err}'}), 500

    # Save (without password in plain text — encode it)
    save_cfg = dict(cfg)
    if password:
        save_cfg['password'] = base64.b64encode(password.encode()).decode()
        save_cfg['_pw_enc'] = True
    mounts.append(save_cfg)
    _save_network_mounts(mounts)

    # Add to fstab if auto_mount
    if auto_mount:
        _netmount_fstab_add(cfg)

    _invalidate_drives_cache()
    return jsonify({
        'ok': True,
        'id': mount_id,
        'mount_path': mp,
        'name': name,
    })


@storage_bp.route('/network/unmount', methods=['POST'])
@admin_required
def network_mount_unmount():
    """Unmount a network drive (keep config)."""
    data = request.json or {}
    mount_id = data.get('id', '').strip()
    if not mount_id:
        return jsonify({'error': 'id is required'}), 400

    mp = _netmount_path(mount_id)
    if _is_mounted(mp):
        r = host_run(f"umount -l {Q(mp)}", timeout=15)
        if r.returncode != 0:
            return jsonify({'error': f'Unmount failed: {r.stderr.strip()}'}), 500

    _invalidate_drives_cache()
    return jsonify({'ok': True})


@storage_bp.route('/network/reconnect', methods=['POST'])
@admin_required
def network_mount_reconnect():
    """Reconnect (re-mount) a saved network drive."""
    data = request.json or {}
    mount_id = data.get('id', '').strip()
    if not mount_id:
        return jsonify({'error': 'id is required'}), 400

    mounts = _load_network_mounts()
    cfg = next((m for m in mounts if m['id'] == mount_id), None)
    if not cfg:
        return jsonify({'error': 'Network mount not found'}), 404

    # Decode password if encoded
    if cfg.get('_pw_enc') and cfg.get('password'):
        try:
            cfg['password'] = base64.b64decode(cfg['password']).decode()
        except Exception:
            pass

    mp = _netmount_path(mount_id)
    if _is_mounted(mp):
        host_run(f"umount -l {Q(mp)}", timeout=10)

    protocol = cfg.get('protocol', 'smb')
    if protocol == 'smb':
        ok, err = _mount_smb(cfg)
    else:
        ok, err = _mount_nfs(cfg)

    if not ok:
        return jsonify({'error': f'Mount failed: {err}'}), 500

    return jsonify({'ok': True, 'mount_path': mp})


@storage_bp.route('/network/remove', methods=['POST'])
@admin_required
def network_mount_remove():
    """Remove a network drive — unmount and delete config."""
    data = request.json or {}
    mount_id = data.get('id', '').strip()
    if not mount_id:
        return jsonify({'error': 'id is required'}), 400

    mp = _netmount_path(mount_id)
    if _is_mounted(mp):
        host_run(f"umount -l {Q(mp)}", timeout=15)
    host_run(f"rmdir {Q(mp)} 2>/dev/null", timeout=3)

    mounts = _load_network_mounts()
    mounts = [m for m in mounts if m['id'] != mount_id]
    _save_network_mounts(mounts)

    _netmount_fstab_remove(mount_id)

    _invalidate_drives_cache()
    return jsonify({'ok': True})


@storage_bp.route('/network/browse', methods=['POST'])
@admin_required
def network_browse():
    """Browse available SMB shares on a remote host."""
    data = request.json or {}
    host_addr = data.get('host', '').strip()
    username = data.get('username', '').strip()
    password = data.get('password', '')

    if not host_addr:
        return jsonify({'error': 'Host address is required'}), 400

    # Try smbclient -L to list shares
    if not check_tool('smbclient'):
        _apt_install('smbclient', timeout=60)

    auth_part = ''
    if username:
        auth_part = f"-U {Q(username + ('%' + password if password else '%'))}"
    else:
        auth_part = '-N'

    r = host_run(f"smbclient -L {Q(host_addr)} {auth_part} --no-pass 2>/dev/null || smbclient -L {Q(host_addr)} {auth_part} 2>&1", timeout=10)
    shares = []
    for line in r.stdout.splitlines():
        line = line.strip()
        # Parse smbclient output: "ShareName   Disk   Comment"
        if '\tDisk' in line or '  Disk  ' in line:
            parts = re.split(r'\s{2,}|\t', line.strip())
            if parts:
                share_name = parts[0].strip()
                comment = parts[2].strip() if len(parts) > 2 else ''
                if not share_name.endswith('$'):
                    shares.append({'name': share_name, 'comment': comment})

    return jsonify({'shares': shares})


@storage_bp.route('/network/scan')
@admin_required
def network_scan():
    """Scan local network for SMB/NFS servers."""
    servers = []

    # Use avahi-browse for mDNS discovery
    r = host_run("avahi-browse -t -r _smb._tcp 2>/dev/null | grep -E '^\\s+address|hostname' || true", timeout=8)
    seen = set()
    current_host = ''
    for line in r.stdout.splitlines():
        line = line.strip()
        if 'hostname' in line.lower():
            match = re.search(r'\[(.+?)\]', line)
            if match:
                current_host = match.group(1).rstrip('.')
        elif 'address' in line.lower():
            match = re.search(r'\[(.+?)\]', line)
            if match:
                addr = match.group(1)
                key = addr
                if key not in seen:
                    seen.add(key)
                    servers.append({
                        'host': addr,
                        'hostname': current_host or addr,
                        'protocols': ['smb'],
                    })

    # Fallback: nmap ping scan + SMB port check on local subnet
    if not servers:
        subnet = _detect_lan_subnet()
        if subnet:
            r = host_run(f"nmap -sn {Q(subnet)} --open -oG - 2>/dev/null | grep 'Status: Up' | awk '{{print $2}}' | head -20", timeout=15)
            for ip in r.stdout.strip().splitlines():
                ip = ip.strip()
                if ip and ip not in seen:
                    # Quick SMB port check
                    r2 = host_run(f"timeout 2 bash -c 'echo >/dev/tcp/{Q(ip)}/445' 2>/dev/null", timeout=5)
                    protocols = []
                    if r2.returncode == 0:
                        protocols.append('smb')
                    r3 = host_run(f"timeout 2 bash -c 'echo >/dev/tcp/{Q(ip)}/2049' 2>/dev/null", timeout=5)
                    if r3.returncode == 0:
                        protocols.append('nfs')
                    if protocols:
                        seen.add(ip)
                        servers.append({'host': ip, 'hostname': ip, 'protocols': protocols})

    return jsonify({'servers': servers})


def _netmount_fstab_add(cfg):
    """Add a network mount to fstab for auto-mount on boot."""
    mp = _netmount_path(cfg['id'])
    protocol = cfg.get('protocol', 'smb')

    if protocol == 'smb':
        creds_file = os.path.join(_NETMOUNT_DIR, f".{cfg['id']}.creds")
        username = cfg.get('username', 'guest')
        password = cfg.get('password', '')
        cred_content = f"username={username}\npassword={password}\n"
        raw = cred_content.encode('utf-8')
        b64 = base64.b64encode(raw).decode('ascii')
        host_run(f"mkdir -p {Q(_NETMOUNT_DIR)}")
        host_run(f"echo '{b64}' | base64 -d > {Q(creds_file)} && chmod 600 {Q(creds_file)}")

        entry = f"//{cfg['host']}/{cfg['share']}  {mp}  cifs  credentials={creds_file},iocharset=utf8,file_mode=0777,dir_mode=0777,noperm,noauto,x-systemd.automount,_netdev  0  0"
    else:
        entry = f"{cfg['host']}:{cfg['share']}  {mp}  nfs  rw,soft,timeo=30,retrans=3,noauto,x-systemd.automount,_netdev  0  0"

    # Remove old entry if exists, then append
    _netmount_fstab_remove(cfg['id'])
    tag = f"# ethos-netmount:{cfg['id']}"
    host_run(f"echo {Q(tag)} >> /etc/fstab && echo {Q(entry)} >> /etc/fstab")
    host_run("systemctl daemon-reload", timeout=10)


def _netmount_fstab_remove(mount_id):
    """Remove a network mount from fstab."""
    tag = f"ethos-netmount:{mount_id}"
    host_run(f"sed -i '/{tag}/d' /etc/fstab && sed -i '\\|{_NETMOUNT_DIR}/{mount_id}|d' /etc/fstab")
    host_run("systemctl daemon-reload", timeout=10)


def _auto_mount_network_drives():
    """Called at startup — mount all network drives flagged auto_mount."""
    mounts = _load_network_mounts()
    for cfg in mounts:
        if not cfg.get('auto_mount', False):
            continue
        mp = _netmount_path(cfg['id'])
        if _is_mounted(mp):
            continue
        # Decode password
        if cfg.get('_pw_enc') and cfg.get('password'):
            try:
                cfg['password'] = base64.b64decode(cfg['password']).decode()
            except Exception:
                pass
        protocol = cfg.get('protocol', 'smb')
        try:
            if protocol == 'smb':
                _mount_smb(cfg)
            else:
                _mount_nfs(cfg)
        except Exception as e:
            logging.getLogger(__name__).warning("Auto-mount %s failed: %s", cfg['id'], e)
