/* ═══════════════════════════════════════════════════════════
   EthOS — Resource Monitor
   CPU, RAM, GPU, Dyski, Sieć, Procesy, USB, Docker
   ═══════════════════════════════════════════════════════════ */

AppRegistry['resource-monitor'] = function (appDef) {
    createWindow('resource-monitor', {
        title: t('Monitor zasobów'),
        icon: appDef.icon,
        iconColor: appDef.color,
        width: 1100,
        height: 700,
        onRender: (body) => renderResourcesApp(body),
    });
};

function renderResourcesApp(body) {
    const sections = ['overview','cpu','ram','gpu','disks','network','processes','usb'];
    const sectionLabels = {
        overview: `<i class="fas fa-tachometer-alt"></i> ${t('Przegląd')}`,
        cpu: '<i class="fas fa-microchip"></i> CPU',
        ram: '<i class="fas fa-memory"></i> RAM',
        gpu: '<i class="fas fa-tv"></i> GPU',
        disks: '<i class="fas fa-hdd"></i> Dyski',
        network: `<i class="fas fa-network-wired"></i> ${t('Sieć')}`,
        processes: '<i class="fas fa-list-alt"></i> Procesy',
        usb: '<i class="fas fa-usb"></i> USB',
    };

    body.innerHTML = `
    <div class="res-app">
        <div class="res-sidebar">
            ${sections.map((s,i) => `<div class="res-nav ${i===0?'active':''}" data-section="${s}">${sectionLabels[s]}</div>`).join('')}
            <div class="res-nav-footer" id="res-conn"><i class="fas fa-circle" style="font-size:8px"></i> Łączenie...</div>
        </div>
        <div class="res-main">
            ${sections.map((s,i) => `<div class="res-section ${i===0?'active':''}" id="res-sec-${s}"></div>`).join('')}
        </div>
    </div>`;

    const $ = (sel) => body.querySelector(sel);
    let currentSection = 'overview';
    let lastData = null;
    let charts = {};
    let cpuHistory = [];
    let ramHistory = [];
    let netHistory = [];

    // Nav
    body.querySelectorAll('.res-nav[data-section]').forEach(nav => {
        nav.onclick = () => {
            currentSection = nav.dataset.section;
            body.querySelectorAll('.res-nav').forEach(n => n.classList.remove('active'));
            body.querySelectorAll('.res-section').forEach(s => s.classList.remove('active'));
            nav.classList.add('active');
            $(`#res-sec-${currentSection}`).classList.add('active');
            if (lastData) updateSection(currentSection, lastData);
        };
    });

    function fmt(bytes) {
        if (bytes == null) return '—';
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1048576) return (bytes/1024).toFixed(1) + ' KB';
        if (bytes < 1073741824) return (bytes/1048576).toFixed(1) + ' MB';
        return (bytes/1073741824).toFixed(2) + ' GB';
    }
    function fmtSpeed(bytes) {
        if (bytes == null) return '0 B/s';
        if (bytes < 1024) return bytes.toFixed(0) + ' B/s';
        if (bytes < 1048576) return (bytes/1024).toFixed(1) + ' KB/s';
        return (bytes/1048576).toFixed(1) + ' MB/s';
    }
    function pct(val) { return val != null ? val.toFixed(1) + '%' : '—'; }

    function bar(percent, color) {
        const p = Math.min(100, Math.max(0, percent || 0));
        return `<div class="res-bar"><div class="res-bar-fill" style="width:${p}%;background:${color || 'var(--accent)'}"></div></div>`;
    }

    function updateAll(data) {
        lastData = data;
        const conn = $('#res-conn');
        conn.innerHTML = '<i class="fas fa-circle" style="font-size:8px;color:#2dd4a8"></i> Online';

        // Save history
        const cpu = data.cpu || {};
        const ram = data.ram || {};
        const net = data.network || {};
        const ts = new Date().toLocaleTimeString('pl', {hour:'2-digit',minute:'2-digit',second:'2-digit'});
        cpuHistory.push({t:ts, v: cpu.total_percent || 0});
        ramHistory.push({t:ts, v: ram.percent || 0});
        netHistory.push({t:ts, down: net.speed_download || 0, up: net.speed_upload || 0});
        if (cpuHistory.length > 60) cpuHistory.shift();
        if (ramHistory.length > 60) ramHistory.shift();
        if (netHistory.length > 60) netHistory.shift();

        updateSection(currentSection, data);
    }

    function updateSection(section, data) {
        const el = $(`#res-sec-${section}`);
        switch(section) {
            case 'overview': renderOverview(el, data); break;
            case 'cpu': renderCPU(el, data); break;
            case 'ram': renderRAM(el, data); break;
            case 'gpu': renderGPU(el, data); break;
            case 'disks': renderDisks(el, data); break;
            case 'network': renderNetwork(el, data); break;
            case 'processes': renderProcesses(el, data); break;
            case 'usb': renderUSB(el, data); break;
        }
    }

    function renderOverview(el, data) {
        const cpu = data.cpu || {};
        const ram = data.ram || {};
        const gpu = (data.gpu && data.gpu.length) ? data.gpu[0] : {};
        const net = data.network || {};
        const disks = data.disks || [];
        const procs = (data.processes || []).slice(0, 5);

        el.innerHTML = `
        <div class="res-grid-4">
            <div class="res-card">
                <div class="res-card-hdr"><i class="fas fa-microchip"></i> CPU</div>
                <div class="res-big-val">${pct(cpu.total_percent)}</div>
                ${bar(cpu.total_percent, '#3b82f6')}
                <div class="res-card-stats">
                    <span>Rdzenie: ${cpu.cores || '—'}</span>
                    <span>${cpu.freq_current ? (cpu.freq_current/1000).toFixed(2)+' GHz' : ''}</span>
                    <span>${cpu.temperature != null ? cpu.temperature+'°C' : ''}</span>
                </div>
            </div>
            <div class="res-card">
                <div class="res-card-hdr"><i class="fas fa-memory"></i> RAM</div>
                <div class="res-big-val">${pct(ram.percent)}</div>
                ${bar(ram.percent, '#8b5cf6')}
                <div class="res-card-stats">
                    <span>Użyte: ${fmt(ram.used)}</span>
                    <span>Całk.: ${fmt(ram.total)}</span>
                </div>
            </div>
            <div class="res-card">
                <div class="res-card-hdr"><i class="fas fa-tv"></i> GPU</div>
                <div class="res-big-val">${gpu.load != null ? pct(gpu.load) : '<span style="font-size:.7em;opacity:.5">Nie wykryto</span>'}</div>
                ${bar(gpu.load, '#f59e0b')}
                <div class="res-card-stats">
                    <span>${gpu.name || '<span style="opacity:.5;font-size:.8em">Zainstaluj sterowniki GPU</span>'}</span>
                    <span>${gpu.temperature != null ? gpu.temperature+'°C' : ''}</span>
                </div>
            </div>
            <div class="res-card">
                <div class="res-card-hdr"><i class="fas fa-network-wired"></i> Sieć</div>
                <div class="res-net-speeds">
                    <div><i class="fas fa-arrow-down" style="color:#2dd4a8"></i> ${fmtSpeed(net.speed_download)}</div>
                    <div><i class="fas fa-arrow-up" style="color:#3b82f6"></i> ${fmtSpeed(net.speed_upload)}</div>
                </div>
                <div class="res-card-stats">
                    <span>↓ ${fmt(net.bytes_recv)}</span>
                    <span>↑ ${fmt(net.bytes_sent)}</span>
                </div>
            </div>
        </div>
        <div class="res-grid-2" style="margin-top:12px">
            <div class="res-card">
                <div class="res-card-hdr"><i class="fas fa-hdd"></i> Dyski</div>
                <div class="res-card-body">${disks.map(d => {
                    const color = d.percent > 90 ? '#ef4444' : d.percent > 70 ? '#eab308' : '#10b981';
                    const isUsb = !!d.is_usb;
                    const isExt = !isUsb && d.mountpoint.startsWith('/media/');
                    const icon = isUsb ? 'fa-usb' : isExt ? 'fa-hdd' : (d.mountpoint === '/' ? 'fa-server' : 'fa-hdd');
                    const icoColor = isUsb ? '#a78bfa' : isExt ? '#f59e0b' : '#3b82f6';
                    const name = d.label || (d.mountpoint === '/' ? 'System' : d.mountpoint.split('/').pop() || d.mountpoint);
                    return `
                    <div style="display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid rgba(255,255,255,0.04);">
                        <i class="fas ${icon}" style="color:${icoColor};width:16px;text-align:center;font-size:12px;"></i>
                        <span style="font-size:12px;font-weight:600;min-width:80px;">${name}</span>
                        <div style="flex:1;display:flex;align-items:center;gap:8px;">
                            ${bar(d.percent, color)}
                            <span style="font-size:11px;font-weight:700;color:${color};min-width:36px;text-align:right;">${pct(d.percent)}</span>
                        </div>
                        <span style="font-size:10px;color:var(--text-muted);white-space:nowrap;">${fmt(d.used)} / ${fmt(d.total)}</span>
                    </div>`;
                }).join('') || '<p style="color:var(--text-muted)">Brak danych</p>'}</div>
            </div>
            <div class="res-card">
                <div class="res-card-hdr"><i class="fas fa-list-alt"></i> Top procesy (CPU)</div>
                <table class="res-proc-table"><thead><tr><th>PID</th><th>Nazwa</th><th>CPU</th><th>RAM</th></tr></thead>
                <tbody>${procs.map(p => `
                    <tr><td>${p.pid}</td><td>${p.name}</td><td>${pct(p.cpu_percent)}</td><td>${fmt(p.memory_rss)}</td></tr>
                `).join('')}</tbody></table>
            </div>
        </div>`;
    }

    function renderCPU(el, data) {
        const cpu = data.cpu || {};
        const perCore = cpu.per_core || [];
        el.innerHTML = `
        <h3><i class="fas fa-microchip"></i> Procesor: ${cpu.brand || '—'}</h3>
        <div class="res-info-bar">
            <span>Rdzenie: ${cpu.cores || '—'} (${cpu.threads || '—'} wątków)</span>
            <span>Częstotliwość: ${cpu.freq_current ? (cpu.freq_current/1000).toFixed(2)+' GHz' : '—'}</span>
            <span>Temperatura: ${cpu.temperature != null ? cpu.temperature+'°C' : '—'}</span>
            <span>Użycie: ${pct(cpu.total_percent)}</span>
        </div>
        <div class="res-card" style="margin-top:12px">
            <div class="res-card-hdr">Użycie per rdzeń</div>
            <div class="res-core-grid">${perCore.map((v,i) => `
                <div class="res-core-item">
                    <span>Core ${i}</span>
                    ${bar(v, '#3b82f6')}
                    <span>${pct(v)}</span>
                </div>`).join('')}</div>
        </div>
        <div class="res-card" style="margin-top:12px">
            <div class="res-card-hdr">CPU Top procesy</div>
            <table class="res-proc-table"><thead><tr><th>PID</th><th>Nazwa</th><th>CPU %</th><th>RAM</th><th>Status</th><th>Użytkownik</th></tr></thead>
            <tbody>${(data.processes||[]).sort((a,b)=>(b.cpu_percent||0)-(a.cpu_percent||0)).slice(0,10).map(p => `
                <tr><td>${p.pid}</td><td>${p.name}</td><td>${pct(p.cpu_percent)}</td><td>${fmt(p.memory_rss)}</td><td>${p.status||''}</td><td>${p.username||''}</td></tr>
            `).join('')}</tbody></table>
        </div>`;
    }

    function renderRAM(el, data) {
        const ram = data.ram || {};
        el.innerHTML = `
        <h3><i class="fas fa-memory"></i> Pamięć RAM</h3>
        <div class="res-info-bar">
            <span>Całkowita: ${fmt(ram.total)}</span>
            <span>Użyta: ${fmt(ram.used)} (${pct(ram.percent)})</span>
            <span>Dostępna: ${fmt(ram.available)}</span>
            <span>Cache: ${fmt(ram.cached)}</span>
            <span>Swap: ${fmt(ram.swap_used)} / ${fmt(ram.swap_total)}</span>
        </div>
        <div class="res-card" style="margin-top:12px">
            ${bar(ram.percent, '#8b5cf6')}
            <div style="text-align:center;font-size:1.5em;margin:8px 0">${pct(ram.percent)}</div>
        </div>
        <div class="res-card" style="margin-top:12px">
            <div class="res-card-hdr">RAM Top procesy</div>
            <table class="res-proc-table"><thead><tr><th>PID</th><th>Nazwa</th><th>RAM %</th><th>RAM</th><th>CPU %</th><th>Status</th></tr></thead>
            <tbody>${(data.processes||[]).sort((a,b)=>(b.memory_percent||0)-(a.memory_percent||0)).slice(0,10).map(p => `
                <tr><td>${p.pid}</td><td>${p.name}</td><td>${pct(p.memory_percent)}</td><td>${fmt(p.memory_rss)}</td><td>${pct(p.cpu_percent)}</td><td>${p.status||''}</td></tr>
            `).join('')}</tbody></table>
        </div>`;
    }

    function renderGPU(el, data) {
        // Don't overwrite the GPU section while install is in progress or waiting for reboot
        if (_gpuInstalling) return;

        const gpus = data.gpu || [];
        if (!gpus.length) {
            // Check if we already have detected hardware cached
            if (!el._gpuDetected) {
                el.innerHTML = `<div class="res-empty">
                    <i class="fas fa-tv" style="font-size:2.5rem;opacity:.4;margin-bottom:12px"></i>
                    <p style="font-size:1.1rem;margin-bottom:8px">Brak wykrytego GPU</p>
                    <p style="opacity:.5">Wykrywanie sprzętu…</p>
                </div>`;
                fetch('/api/resources/gpu/detect', {headers:{'Authorization':'Bearer '+NAS.token}}).then(r => r.json()).then(hw => {
                    el._gpuDetected = hw;
                    _renderGpuNoDriver(el, hw);
                }).catch(() => {
                    _renderGpuNoDriver(el, {cards: []});
                });
            } else {
                _renderGpuNoDriver(el, el._gpuDetected);
            }
            return;
        }
        el._gpuDetected = null;
        el.innerHTML = gpus.map(g => `
        <div class="res-card">
            <div class="res-card-hdr"><i class="fas fa-tv"></i> ${g.name || 'GPU'}</div>
            <div class="res-grid-2">
                <div>
                    <span>Obciążenie:</span>
                    ${bar(g.load, '#f59e0b')}
                    <span class="res-big-val">${pct(g.load)}</span>
                </div>
                <div>
                    <span>VRAM: ${fmt(g.memory_used)} / ${fmt(g.memory_total)}</span>
                    ${bar(g.memory_total ? ((g.memory_used||0)/g.memory_total*100) : 0, '#ef4444')}
                </div>
            </div>
            <div class="res-info-bar" style="margin-top:8px">
                <span>Temperatura: ${g.temperature != null ? g.temperature+'°C':'—'}</span>
                <span>Driver: ${g.driver || '—'}</span>
            </div>
        </div>`).join('');
    }

    let _gpuInstallListener = null;
    let _gpuInstalling = false;  // true while install is running or waiting for reboot

    function _renderGpuNoDriver(el, hw) {
        const cards = hw.cards || [];
        const vendorIcons = {nvidia: 'fa-bolt', amd: 'fa-fire', intel: 'fa-microchip', unknown: 'fa-question-circle'};
        const vendorColors = {nvidia: '#76b900', amd: '#ed1c24', intel: '#0071c5', unknown: '#888'};

        if (!cards.length) {
            el.innerHTML = `<div class="res-empty">
                <i class="fas fa-tv" style="font-size:2.5rem;opacity:.4;margin-bottom:12px"></i>
                <p style="font-size:1.1rem;margin-bottom:8px">Brak wykrytego GPU</p>
                <p style="font-size:.85rem;opacity:.6;max-width:480px;line-height:1.6;margin:0 auto">
                    Nie wykryto karty graficznej w systemie.
                </p>
            </div>`;
            return;
        }

        el.innerHTML = cards.map((c, i) => `
        <div class="res-card" style="margin-bottom:12px">
            <div class="res-card-hdr">
                <i class="fas ${vendorIcons[c.vendor]||vendorIcons.unknown}" style="color:${vendorColors[c.vendor]||vendorColors.unknown}"></i>
                ${c.name || 'Karta graficzna'}
            </div>
            <div style="padding:12px 16px">
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
                    <span style="font-size:.85rem;opacity:.7">Producent:</span>
                    <span style="font-weight:600;text-transform:uppercase">${c.vendor}</span>
                </div>
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
                    <span style="font-size:.85rem;opacity:.7">Pakiety:</span>
                    <span style="font-size:.85rem;font-family:monospace">${(c.packages||[]).join(', ') || '—'}</span>
                </div>
                ${c.driver_installed ? `
                <div style="margin-top:12px;display:flex;align-items:center;gap:8px;padding:10px 16px;
                            background:rgba(34,197,94,.12);border-radius:8px;border:1px solid rgba(34,197,94,.3)">
                    <i class="fas fa-check-circle" style="color:#22c55e;font-size:1.1rem"></i>
                    <span style="font-size:.9rem;font-weight:600;color:#22c55e">Sterowniki zainstalowane</span>
                </div>` : (c.packages_installed && c.reboot_required) ? `
                <div style="margin-top:12px;display:flex;align-items:center;gap:8px;padding:10px 16px;
                            background:rgba(245,158,11,.12);border-radius:8px;border:1px solid rgba(245,158,11,.35)">
                    <i class="fas fa-exclamation-triangle" style="color:#f59e0b;font-size:1.1rem"></i>
                    <span style="font-size:.9rem;font-weight:600;color:#f59e0b">Sterowniki zainstalowane, wymagany restart systemu</span>
                </div>
                <div style="margin-top:10px;display:flex;gap:8px;align-items:center">
                    <button onclick="fetch('/api/power/action',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+NAS.token},body:JSON.stringify({action:'reboot'})}).then(()=>{this.disabled=true;this.innerHTML='<i class=\\'fas fa-spinner fa-spin\\'></i> Restartowanie…'})"
                        style="background:#ef4444;color:#fff;border:none;padding:8px 20px;border-radius:6px;cursor:pointer;
                               font-size:.85rem;font-weight:600;display:flex;align-items:center;gap:6px">
                        <i class="fas fa-redo"></i> Uruchom ponownie
                    </button>
                </div>` : c.install_cmd ? `
                <div id="gpu-install-area-${i}" style="margin-top:12px">
                    <button onclick="window._gpuInstallDriver(${i})"
                        class="res-gpu-install-btn"
                        style="background:${vendorColors[c.vendor]||'#3b82f6'};color:#fff;border:none;padding:10px 24px;
                               border-radius:8px;cursor:pointer;font-size:.95rem;font-weight:600;
                               display:flex;align-items:center;gap:8px;transition:opacity .2s">
                        <i class="fas fa-download"></i> Pobierz i zainstaluj sterowniki
                    </button>
                </div>` : `<p style="opacity:.5;font-size:.85rem">Brak automatycznej instalacji dla tego producenta.</p>`}
            </div>
        </div>`).join('');

        // Bind install handler
        window._gpuInstallDriver = (cardIndex) => {
            const area = el.querySelector('#gpu-install-area-' + cardIndex);
            if (!area) return;
            _gpuInstalling = true;
            area.innerHTML = `
                <div style="margin-top:4px">
                    <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
                        <i class="fas fa-spinner fa-spin" style="color:#f59e0b"></i>
                        <span id="gpu-install-status" style="font-size:.85rem">Rozpoczynanie…</span>
                    </div>
                    <div style="background:rgba(255,255,255,.08);border-radius:6px;height:22px;overflow:hidden;position:relative">
                        <div id="gpu-install-bar" style="height:100%;width:0%;background:linear-gradient(90deg,#f59e0b,#22c55e);
                             border-radius:6px;transition:width .4s ease"></div>
                        <span id="gpu-install-pct" style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);
                              font-size:.75rem;font-weight:700">0%</span>
                    </div>
                    <div id="gpu-install-detail" style="margin-top:6px;font-size:.75rem;opacity:.5;
                         font-family:monospace;max-height:60px;overflow-y:auto;word-break:break-all"></div>
                </div>`;

            // Register socketio listener
            if (_gpuInstallListener && NAS.socket) NAS.socket.off('gpu_driver_progress', _gpuInstallListener);
            _gpuInstallListener = (ev) => {
                const barEl = document.getElementById('gpu-install-bar');
                const pctEl = document.getElementById('gpu-install-pct');
                const statusEl = document.getElementById('gpu-install-status');
                const detailEl = document.getElementById('gpu-install-detail');
                if (barEl) barEl.style.width = ev.progress + '%';
                if (pctEl) pctEl.textContent = ev.progress + '%';
                if (statusEl) statusEl.textContent = ev.message || '';
                if (detailEl && ev.detail) detailEl.textContent = ev.detail;

                if (ev.phase === 'done') {
                    if (statusEl) statusEl.innerHTML = '<span style="color:#22c55e"><i class="fas fa-check-circle"></i> ' + ev.message + '</span>';
                    if (barEl) barEl.style.background = 'linear-gradient(90deg,#22c55e,#16a34a)';
                    // Clear cached detection so next render re-fetches fresh state
                    el._gpuDetected = null;
                    if (ev.reboot_required) {
                        const rebootArea = document.createElement('div');
                        rebootArea.style.cssText = 'margin-top:10px';
                        rebootArea.innerHTML = `<button onclick="fetch('/api/power/action',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+NAS.token},body:JSON.stringify({action:'reboot'})}).then(()=>{this.disabled=true;this.innerHTML='<i class=\\'fas fa-spinner fa-spin\\'></i> Restartowanie…'})"
                            style="background:#ef4444;color:#fff;border:none;padding:8px 20px;border-radius:6px;cursor:pointer;
                                   font-size:.85rem;font-weight:600;display:flex;align-items:center;gap:6px">
                            <i class="fas fa-redo"></i> Uruchom ponownie
                        </button>`;
                        area.appendChild(rebootArea);
                    }
                } else if (ev.phase === 'error') {
                    if (statusEl) statusEl.innerHTML = '<span style="color:#ef4444"><i class="fas fa-exclamation-triangle"></i> ' + ev.message + '</span>';
                    if (barEl) barEl.style.background = '#ef4444';
                    _gpuInstalling = false;
                }
            };
            if (NAS.socket) NAS.socket.on('gpu_driver_progress', _gpuInstallListener);

            // Trigger install
            fetch('/api/resources/gpu/install', {
                method: 'POST',
                headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + NAS.token},
                body: JSON.stringify({card_index: cardIndex})
            }).then(r => r.json()).then(res => {
                if (res.error) {
                    const statusEl = document.getElementById('gpu-install-status');
                    if (statusEl) statusEl.innerHTML = '<span style="color:#ef4444">' + res.error + '</span>';
                }
            }).catch(err => {
                const statusEl = document.getElementById('gpu-install-status');
                if (statusEl) statusEl.innerHTML = `<span style="color:#ef4444">${t('Błąd połączenia')}</span>`;
            });
        };
    }

    function renderDisks(el, data) {
        const disks = data.disks || [];

        function diskCat(d) {
            if (d.is_usb) return 'usb';
            if (d.mountpoint.startsWith('/media/')) return 'ext';
            return 'sys';
        }
        function diskIcon(d) {
            const c = diskCat(d);
            if (c === 'usb') return 'fa-usb';
            if (c === 'ext') return 'fa-hdd';
            return d.mountpoint === '/' ? 'fa-server' : 'fa-hdd';
        }
        function diskIconColor(d) {
            const c = diskCat(d);
            if (c === 'usb') return '#a78bfa';
            if (c === 'ext') return '#f59e0b';
            return '#3b82f6';
        }
        function diskLabel(d) {
            if (d.label) return d.label;
            if (d.mountpoint === '/') return 'System /';
            const parts = d.mountpoint.split('/');
            return parts[parts.length - 1] || d.mountpoint;
        }
        function diskColor(p) { return p > 90 ? '#ef4444' : p > 70 ? '#eab308' : '#10b981'; }

        function renderCard(d) {
            const color = diskColor(d.percent);
            const modelLine = d.model ? `<span style="color:#94a3b8;font-style:italic">${d.model}</span>` : '';
            return `
            <div class="ddisk-card">
                <div class="ddisk-icon" style="color:${diskIconColor(d)}"><i class="fas ${diskIcon(d)}"></i></div>
                <div class="ddisk-info">
                    <div class="ddisk-name">${diskLabel(d)} ${modelLine}</div>
                    <div class="ddisk-meta">${d.device} · ${d.fstype || '?'} · ${d.mountpoint}</div>
                    <div class="ddisk-bar-wrap">
                        <div class="ddisk-bar"><div class="ddisk-bar-fill" style="width:${d.percent}%;background:${color}"></div></div>
                        <span class="ddisk-pct" style="color:${color}">${pct(d.percent)}</span>
                    </div>
                    <div class="ddisk-sizes">
                        <span><b>${fmt(d.used)}</b> zajęte</span>
                        <span><b>${fmt(d.free)}</b> wolne</span>
                        <span>z <b>${fmt(d.total)}</b></span>
                    </div>
                </div>
            </div>`;
        }

        function renderGroup(title, icon, list) {
            if (!list.length) return '';
            return `<div class="ddisk-group"><div class="ddisk-group-title"><i class="fas ${icon}"></i> ${title}</div>
                <div class="ddisk-group-cards">${list.map(renderCard).join('')}</div></div>`;
        }

        const sys = disks.filter(d => diskCat(d) === 'sys');
        const ext = disks.filter(d => diskCat(d) === 'ext');
        const usb = disks.filter(d => diskCat(d) === 'usb');

        el.innerHTML = `<h3><i class="fas fa-hdd"></i> Dyski i pamięć masowa</h3>` +
            renderGroup('Dyski systemowe', 'fa-server', sys) +
            renderGroup(t('Dyski zewnętrzne'), 'fa-hdd', ext) +
            renderGroup('Dyski USB', 'fa-usb', usb) +
            (disks.length === 0 ? `<div class="res-empty"><p>${t('Brak dysków')}</p></div>` : '');
    }

    function renderNetwork(el, data) {
        const net = data.network || {};
        const ifaces = net.interfaces || [];
        el.innerHTML = `
        <h3><i class="fas fa-network-wired"></i> Sieć</h3>
        <div class="res-grid-2">
            <div class="res-card">
                <div class="res-card-hdr"><i class="fas fa-arrow-down" style="color:#2dd4a8"></i> Download</div>
                <div class="res-big-val">${fmtSpeed(net.speed_download)}</div>
                <span style="color:var(--text-muted)">Łącznie: ${fmt(net.bytes_recv)}</span>
            </div>
            <div class="res-card">
                <div class="res-card-hdr"><i class="fas fa-arrow-up" style="color:#3b82f6"></i> Upload</div>
                <div class="res-big-val">${fmtSpeed(net.speed_upload)}</div>
                <span style="color:var(--text-muted)">Łącznie: ${fmt(net.bytes_sent)}</span>
            </div>
        </div>
        ${ifaces.length ? `
        <div class="res-card" style="margin-top:12px">
            <div class="res-card-hdr">Interfejsy</div>
            <table class="res-proc-table"><thead><tr><th>Interfejs</th><th>IP</th><th>↓ Speed</th><th>↑ Speed</th></tr></thead>
            <tbody>${ifaces.map(i => `
                <tr><td>${i.name}</td><td>${i.addresses ? i.addresses.join(', ') : '—'}</td>
                <td>${fmtSpeed(i.speed_download)}</td><td>${fmtSpeed(i.speed_upload)}</td></tr>
            `).join('')}</tbody></table>
        </div>` : ''}`;
    }

    function renderProcesses(el, data) {
        const procs = data.processes || [];
        // Keep search state
        let search = '';
        const existingInput = el.querySelector('#res-proc-search');
        if (existingInput) search = existingInput.value;

        const filtered = search ? procs.filter(p => p.name.toLowerCase().includes(search.toLowerCase())) : procs;

        el.innerHTML = `
        <h3><i class="fas fa-list-alt"></i> Procesy (${procs.length})</h3>
        <div class="res-proc-controls">
            <input type="text" id="res-proc-search" class="fm-input" placeholder="Szukaj procesu..." value="${search}" style="max-width:300px">
        </div>
        <div class="res-card" style="margin-top:8px;max-height:450px;overflow-y:auto">
            <table class="res-proc-table"><thead><tr>
                <th>PID</th><th>Nazwa</th><th>CPU %</th><th>RAM %</th><th>RAM</th><th>Status</th><th>Użytkownik</th><th>Akcja</th>
            </tr></thead>
            <tbody>${filtered.slice(0, 100).map(p => `
                <tr><td>${p.pid}</td><td title="${p.cmdline||''}">${p.name}</td><td>${pct(p.cpu_percent)}</td>
                <td>${pct(p.memory_percent)}</td><td>${fmt(p.memory_rss)}</td>
                <td>${p.status||''}</td><td>${p.username||''}</td>
                <td><button class="fm-toolbar-btn btn-red btn-sm" data-kill="${p.pid}" data-name="${p.name}"><i class="fas fa-times"></i></button></td></tr>
            `).join('')}</tbody></table>
        </div>`;

        el.querySelector('#res-proc-search').oninput = (e) => {
            search = e.target.value;
            renderProcesses(el, data);
        };

        el.querySelectorAll('button[data-kill]').forEach(btn => {
            btn.onclick = async () => {
                if (!confirm(`Zakończyć proces ${btn.dataset.name} (PID: ${btn.dataset.kill})?`)) return;
                try {
                    await api(`/resources/kill/${btn.dataset.kill}`, {method:'POST'});
                    toast(t('Proces zakończony'), 'success');
                } catch(e) { toast(t('Błąd'), 'error'); }
            };
        });
    }

    function renderUSB(el, data) {
        const devices = data.usb || [];

        const classIcons = {
            '03': 'fa-keyboard', '07': 'fa-print', '08': 'fa-hdd',
            '09': 'fa-sitemap', '0e': 'fa-video', 'e0': 'fa-broadcast-tower',
            '01': 'fa-music', '06': 'fa-camera',
        };

        el.innerHTML = `<h3><i class="fas fa-usb"></i> Urządzenia USB (${devices.length})</h3>` +
            (devices.length ? devices.map(d => {
                const icon = classIcons[d.device_class] || 'fa-usb';
                const name = d.product || t('Nieznane urządzenie');
                const mfr = d.manufacturer || '';
                const cls = d.device_class_name || '';
                const speed = d.speed ? d.speed + ' Mbit/s' : '';
                const power = d.power || '';
                return `
            <div class="res-card" style="margin-top:8px">
                <div class="res-card-hdr" style="display:flex;align-items:center;gap:8px">
                    <i class="fas ${icon}" style="color:#a78bfa"></i>
                    <span>${name}</span>
                    ${cls ? `<span style="font-size:10px;padding:2px 6px;background:rgba(167,139,250,.12);color:#a78bfa;border-radius:4px;font-weight:600">${cls}</span>` : ''}
                </div>
                <div class="res-info-bar" style="gap:12px;flex-wrap:wrap">
                    ${mfr ? `<span><i class="fas fa-industry" style="opacity:.5;margin-right:4px"></i>${mfr}</span>` : ''}
                    <span><i class="fas fa-barcode" style="opacity:.5;margin-right:4px"></i>${d.vendor_id}:${d.product_id}</span>
                    <span><i class="fas fa-plug" style="opacity:.5;margin-right:4px"></i>Bus ${d.bus}, Dev ${d.device}</span>
                    ${speed ? `<span><i class="fas fa-tachometer-alt" style="opacity:.5;margin-right:4px"></i>${speed}</span>` : ''}
                    ${power ? `<span><i class="fas fa-bolt" style="opacity:.5;margin-right:4px"></i>${power}</span>` : ''}
                    ${d.serial ? `<span><i class="fas fa-fingerprint" style="opacity:.5;margin-right:4px"></i>${d.serial.substring(0, 20)}</span>` : ''}
                </div>
            </div>`;
            }).join('') : `<div class="res-empty"><p>${t('Brak urządzeń USB')}</p></div>`);
    }

    // Listen on socketio for resources_update
    if (NAS.socket) {
        const handler = (data) => { updateAll(data); };
        NAS.socket.on('resources_update', handler);
        // Clean up on window close
        const win = body.closest('.window');
        if (win) {
            const orig = win._onClose;
            win._onClose = () => { NAS.socket.off('resources_update', handler); if (orig) orig(); };
        }
    }

    // Initial load
    (async () => {
        try {
            const d = await api('/resources/all');
            updateAll(d);
        } catch(e) {
            $(`#res-sec-overview`).innerHTML = `<div class="res-empty"><p>${t('Błąd ładowania danych')}</p></div>`;
        }
    })();
}
