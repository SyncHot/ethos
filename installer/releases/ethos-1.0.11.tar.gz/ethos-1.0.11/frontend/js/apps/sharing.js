/* ═══════════════════════════════════════════════════════════
   EthOS — Udostępnianie (Multi-protocol file sharing)
   Samba · NFS · DLNA · WebDAV · SFTP · FTP
   Tabs only appear for protocols installed via App Store.
   ═══════════════════════════════════════════════════════════ */

AppRegistry['sharing'] = function (appDef) {
    createWindow('sharing', {
        title: t('Udostępnianie'),
        icon: appDef.icon,
        iconColor: appDef.color,
        width: 820,
        height: 560,
        onRender: (body) => renderSharingApp(body),
        onClose: () => { /* no intervals/sockets to clean */ },
    });
};

/* ── helpers ────────────────────────────────── */
function _shBadge(ok, label) {
    if (ok === null) return `<span class="fm-badge" style="background:rgba(100,100,100,.12);color:var(--text-muted)">${label || '…'}</span>`;
    if (ok === 'off') return `<span class="fm-badge" style="background:rgba(234,179,8,.12);color:#eab308">${label || t('Wyłączony')}</span>`;
    return ok
        ? `<span class="fm-badge fm-badge-green">${label || t('Aktywny')}</span>`
        : `<span class="fm-badge" style="background:rgba(239,68,68,.12);color:#ef4444">${label || t('Nieaktywny')}</span>`;
}

/* All 6 protocols — order matters for sidebar */
const _SH_ALL_PROTOS = [
    { id: 'samba',  pkgId: 'sharing-samba',  icon: 'fa-windows',      label: 'Samba' },
    { id: 'nfs',    pkgId: 'sharing-nfs',    icon: 'fa-network-wired', label: 'NFS' },
    { id: 'dlna',   pkgId: 'sharing-dlna',   icon: 'fa-photo-video',  label: 'DLNA' },
    { id: 'webdav', pkgId: 'sharing-webdav', icon: 'fa-globe',        label: 'WebDAV' },
    { id: 'sftp',   pkgId: 'sharing-sftp',   icon: 'fa-lock',         label: 'SFTP' },
    { id: 'ftp',    pkgId: 'sharing-ftp',    icon: 'fa-upload',       label: 'FTP' },
];

/* ── main render ────────────────────────────── */
async function renderSharingApp(body) {
    const $ = (s) => body.querySelector(s);

    /* Show loading state */
    body.innerHTML = `<div style="display:flex;align-items:center;justify-content:center;height:100%;color:var(--text-muted)"><i class="fas fa-spinner fa-spin" style="margin-right:8px"></i>${t('Ładowanie…')}</div>`;

    /* Fetch installed packages to determine which tabs to show */
    let installedProtos;
    try {
        const pkgs = await api('/ethos-packages');
        const installed = new Set(pkgs.filter(p => p.installed).map(p => p.id));
        installedProtos = _SH_ALL_PROTOS.filter(p => installed.has(p.pkgId));
    } catch (e) {
        installedProtos = _SH_ALL_PROTOS; /* fallback: show all */
    }

    /* Empty state — no protocols installed */
    if (!installedProtos.length) {
        body.innerHTML = `
        <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;gap:16px;padding:40px;text-align:center">
            <i class="fas fa-share-alt" style="font-size:48px;color:var(--text-muted);opacity:.4"></i>
            <h3 style="margin:0;font-size:16px;color:var(--text)">${t('Brak zainstalowanych protokołów')}</h3>
            <p style="margin:0;font-size:13px;color:var(--text-muted);max-width:340px">
                ${t('Zainstaluj protokoły udostępniania (Samba, NFS, DLNA, WebDAV, SFTP, FTP) w')}
                <a href="#" id="sh-goto-store" style="color:#6366f1;text-decoration:underline">${t('App Store')}</a>.
            </p>
        </div>`;
        const link = $('#sh-goto-store');
        if (link) link.onclick = (e) => { e.preventDefault(); if (typeof openApp === 'function') openApp('app-store'); };
        return;
    }

    /* ── Layout: left sidebar + right panel ──
       body IS the .window-body (flex:1; overflow:auto).
       We make it a flex-row container directly so sidebar + panel
       sit side by side without needing height:100% on a wrapper. */
    body.style.cssText = 'display:flex;flex-direction:row;overflow:hidden;padding:0';
    body.innerHTML = `
        <div class="sh-sidebar" style="width:150px;min-width:150px;flex-shrink:0;border-right:1px solid var(--border);display:flex;flex-direction:column;padding:8px 0;overflow-y:auto;background:var(--bg-secondary,rgba(0,0,0,.02))">
            ${installedProtos.map(p => `
                <button class="sh-tab" data-tab="${p.id}" style="
                    display:flex;align-items:center;gap:8px;padding:10px 14px;
                    border:none;background:none;cursor:pointer;text-align:left;
                    font-size:13px;color:var(--text-muted);transition:all .15s;
                    border-left:3px solid transparent;width:100%;
                "><i class="fas ${p.icon}" style="font-size:12px;width:16px;text-align:center"></i><span>${p.label}</span></button>
            `).join('')}
        </div>
        <div id="sh-panel" style="flex:1;overflow-y:auto;padding:16px 20px"></div>`;

    let activeTab = null;

    function switchTab(id) {
        activeTab = id;
        body.querySelectorAll('.sh-tab').forEach(b => {
            const active = b.dataset.tab === id;
            b.style.borderLeftColor = active ? '#6366f1' : 'transparent';
            b.style.color = active ? 'var(--text)' : 'var(--text-muted)';
            b.style.fontWeight = active ? '600' : '400';
            b.style.background = active ? 'rgba(99,102,241,.06)' : 'none';
        });
        const render = { samba: renderSamba, nfs: renderNFS, dlna: renderDLNA, webdav: renderWebDAV, sftp: renderSFTP, ftp: renderFTP };
        (render[id] || render.samba)($('#sh-panel'));
    }

    body.querySelectorAll('.sh-tab').forEach(b => b.onclick = () => switchTab(b.dataset.tab));
    switchTab(installedProtos[0].id);

    /* ══════════════════════════════════════════
       SAMBA tab
       ══════════════════════════════════════════ */
    function renderSamba(panel) {
        const st = { shares: [] };
        panel.innerHTML = `
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap">
            <span style="font-weight:600;font-size:15px"><i class="fab fa-windows" style="margin-right:6px;color:#6366f1"></i>Samba</span>
            <span id="sh-smb-status"></span>
            <div style="flex:1"></div>
            <button class="fm-toolbar-btn btn-green" id="sh-smb-add"><i class="fas fa-plus"></i> ${t('Dodaj')}</button>
            <button class="fm-toolbar-btn" id="sh-smb-ref" title="${t('Odśwież')}"><i class="fas fa-sync-alt"></i></button>
        </div>
        <div id="sh-smb-list"></div>
        <div id="sh-smb-form" style="display:none"></div>
        <div style="margin-top:14px;border-top:1px solid var(--border);padding-top:12px">
            <h4 style="font-size:13px"><i class="fas fa-key" style="color:#eab308"></i> ${t('Hasło Samba')}</h4>
            <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:6px">
                <input type="text" id="sh-smb-pwu" class="fm-input" placeholder="${t('Użytkownik')}" style="width:140px">
                <input type="password" id="sh-smb-pwp" class="fm-input" placeholder="${t('Hasło')}" style="width:160px">
                <button class="fm-toolbar-btn btn-green" id="sh-smb-pwb"><i class="fas fa-save"></i> ${t('Ustaw')}</button>
            </div>
        </div>`;

        async function load() {
            try {
                const [shares, status] = await Promise.all([api('/storage/samba/shares'), api('/storage/samba/status')]);
                st.shares = shares || [];
                panel.querySelector('#sh-smb-status').innerHTML = _shBadge(status.running);
                renderList();
            } catch (e) { panel.querySelector('#sh-smb-list').innerHTML = `<div style="color:#ef4444">${t('Błąd')}: ${e.message}</div>`; }
        }

        function renderList() {
            const w = panel.querySelector('#sh-smb-list');
            if (!st.shares.length) { w.innerHTML = `<div style="text-align:center;padding:20px;color:var(--text-muted)">${t('Brak udziałów')}</div>`; return; }
            w.innerHTML = `<table style="width:100%;border-collapse:collapse;font-size:13px">
                <thead><tr style="border-bottom:1px solid var(--border);color:var(--text-muted);font-size:12px">
                    <th style="text-align:left;padding:6px">${t('Nazwa')}</th><th style="text-align:left;padding:6px">${t('Ścieżka')}</th>
                    <th style="text-align:center;padding:6px">${t('Gość')}</th><th style="text-align:center;padding:6px">${t('Zapis')}</th><th></th>
                </tr></thead><tbody>${st.shares.map(s => `<tr style="border-bottom:1px solid var(--border)">
                    <td style="padding:6px;font-weight:500">${s.name}</td>
                    <td style="padding:6px;color:var(--text-muted);font-size:12px">${s.path}</td>
                    <td style="text-align:center;padding:6px">${s.guest_ok ? '<i class="fas fa-check" style="color:#10b981"></i>' : '<i class="fas fa-times" style="color:var(--text-muted)"></i>'}</td>
                    <td style="text-align:center;padding:6px">${s.writable ? '<i class="fas fa-check" style="color:#10b981"></i>' : '<i class="fas fa-times" style="color:var(--text-muted)"></i>'}</td>
                    <td style="text-align:right;padding:6px">
                        <button class="fm-toolbar-btn btn-sm sh-sme" data-name="${s.name}" data-path="${s.path}" data-guest="${s.guest_ok}" data-writable="${s.writable}"><i class="fas fa-pen"></i></button>
                        <button class="fm-toolbar-btn btn-sm btn-red sh-smd" data-name="${s.name}"><i class="fas fa-trash"></i></button>
                    </td></tr>`).join('')}</tbody></table>`;
            w.querySelectorAll('.sh-sme').forEach(b => b.onclick = () => showForm({ name: b.dataset.name, path: b.dataset.path, guest_ok: b.dataset.guest === 'true', writable: b.dataset.writable === 'true' }));
            w.querySelectorAll('.sh-smd').forEach(b => b.onclick = async () => { if (!await confirmDialog(t('Usunąć udział'), t('Usunąć') + ` "${b.dataset.name}"?`)) return; await api('/storage/samba/share', { method: 'DELETE', body: { name: b.dataset.name } }); toast(t('Usunięto'), 'success'); load(); });
        }

        function showForm(s) {
            const f = panel.querySelector('#sh-smb-form');
            f.style.display = '';
            f.innerHTML = `<div style="border-top:1px solid var(--border);padding-top:10px;margin-top:8px">
                <h4 style="font-size:13px;margin-bottom:6px">${s ? t('Edytuj') : t('Nowy udział')}</h4>
                <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
                    <input type="text" id="sh-sf-n" class="fm-input" placeholder="${t('Nazwa')}" value="${s?.name || ''}" style="width:140px" ${s ? 'readonly' : ''}>
                    <div style="display:flex;gap:0;align-items:center"><input type="text" id="sh-sf-p" class="fm-input" placeholder="${t('Ścieżka')}" value="${s?.path || ''}" style="width:200px;border-radius:6px 0 0 6px" readonly><button class="fm-toolbar-btn" id="sh-sf-browse" style="border-radius:0 6px 6px 0;margin-left:-1px" title="${t('Przeglądaj')}"><i class="fas fa-folder-open"></i></button></div>
                    <label style="font-size:12px;display:flex;align-items:center;gap:4px"><input type="checkbox" id="sh-sf-g" ${!s || s.guest_ok ? 'checked' : ''}> ${t('Gość')}</label>
                    <label style="font-size:12px;display:flex;align-items:center;gap:4px"><input type="checkbox" id="sh-sf-w" ${!s || s.writable ? 'checked' : ''}> ${t('Zapis')}</label>
                    <button class="fm-toolbar-btn btn-green" id="sh-sf-ok"><i class="fas fa-save"></i></button>
                    <button class="fm-toolbar-btn" id="sh-sf-x"><i class="fas fa-times"></i></button>
                </div></div>`;
            panel.querySelector('#sh-sf-browse').onclick = () => openDirPicker(panel.querySelector('#sh-sf-p').value || '/home', t('Wybierz folder'), p => { panel.querySelector('#sh-sf-p').value = p; });
            panel.querySelector('#sh-sf-ok').onclick = async () => {
                const n = panel.querySelector('#sh-sf-n').value.trim(), p = panel.querySelector('#sh-sf-p').value.trim();
                if (!n || !p) { toast(t('Podaj nazwę i ścieżkę'), 'warning'); return; }
                try {
                    const resp = await api('/storage/samba/share', { method: 'POST', body: { name: n, path: p, guest_ok: panel.querySelector('#sh-sf-g').checked, writable: panel.querySelector('#sh-sf-w').checked } });
                    if (resp.error) { toast(t('Błąd: ') + resp.error, 'error'); return; }
                    toast(t('Udział zapisany'), 'success'); f.style.display = 'none'; load();
                } catch (e) { toast(t('Błąd zapisu: ') + (e.message || 'nieznany'), 'error'); }
            };
            panel.querySelector('#sh-sf-x').onclick = () => { f.style.display = 'none'; };
        }

        panel.querySelector('#sh-smb-add').onclick = () => showForm(null);
        panel.querySelector('#sh-smb-ref').onclick = () => load();
        panel.querySelector('#sh-smb-pwb').onclick = async () => {
            const u = panel.querySelector('#sh-smb-pwu').value.trim(), p = panel.querySelector('#sh-smb-pwp').value;
            if (!u || !p) { toast(t('Podaj użytkownika i hasło'), 'warning'); return; }
            try {
                const resp = await api('/storage/samba/password', { method: 'POST', body: { username: u, password: p } });
                if (resp.error) { toast(t('Błąd: ') + resp.error, 'error'); return; }
                toast(t('Hasło ustawione'), 'success'); panel.querySelector('#sh-smb-pwp').value = '';
            } catch(e) { toast(t('Błąd ustawiania hasła: ') + e.message, 'error'); }
        };
        load();
    }

    /* ══════════════════════════════════════════
       NFS tab
       ══════════════════════════════════════════ */
    function renderNFS(panel) {
        panel.innerHTML = `
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap">
            <span style="font-weight:600;font-size:15px"><i class="fas fa-network-wired" style="margin-right:6px;color:#6366f1"></i>NFS</span>
            <span id="sh-nfs-st"></span>
            <div style="flex:1"></div>
            <button class="fm-toolbar-btn btn-green" id="sh-nfs-add"><i class="fas fa-plus"></i> ${t('Dodaj eksport')}</button>
            <button class="fm-toolbar-btn" id="sh-nfs-ref"><i class="fas fa-sync-alt"></i></button>
        </div>
        <p style="font-size:12px;color:var(--text-muted);margin-bottom:10px">${t('NFS — szybkie udostępnianie dla klientów Linux/Mac. Idealne do montowania katalogów na wielu maszynach.')}</p>
        <div id="sh-nfs-list"></div>
        <div id="sh-nfs-form" style="display:none"></div>`;

        async function load() {
            try {
                const [exports, status] = await Promise.all([api('/storage/nfs/exports'), api('/storage/nfs/status')]);
                panel.querySelector('#sh-nfs-st').innerHTML = _shBadge(status.running);
                renderList(exports.exports || []);
            } catch (e) { panel.querySelector('#sh-nfs-list').innerHTML = `<div style="color:#ef4444">${e.message}</div>`; }
        }

        function renderList(exports) {
            const w = panel.querySelector('#sh-nfs-list');
            if (!exports.length) { w.innerHTML = `<div style="text-align:center;padding:20px;color:var(--text-muted)">${t('Brak eksportów NFS')}</div>`; return; }
            w.innerHTML = `<table style="width:100%;border-collapse:collapse;font-size:13px">
                <thead><tr style="border-bottom:1px solid var(--border);color:var(--text-muted);font-size:12px">
                    <th style="text-align:left;padding:6px">${t('Ścieżka')}</th><th style="text-align:left;padding:6px">${t('Klienci / opcje')}</th><th></th>
                </tr></thead><tbody>${exports.map(e => `<tr style="border-bottom:1px solid var(--border)">
                    <td style="padding:6px;font-weight:500">${e.path}</td>
                    <td style="padding:6px;color:var(--text-muted);font-size:12px">${e.clients}</td>
                    <td style="text-align:right;padding:6px"><button class="fm-toolbar-btn btn-sm btn-red sh-nfsd" data-path="${e.path}"><i class="fas fa-trash"></i></button></td>
                </tr>`).join('')}</tbody></table>`;
            w.querySelectorAll('.sh-nfsd').forEach(b => b.onclick = async () => {
                if (!await confirmDialog(t('Usunąć eksport'), t('Usunąć eksport') + ` "${b.dataset.path}"?`)) return;
                await api('/storage/nfs/export', { method: 'DELETE', body: { path: b.dataset.path } });
                toast(t('Usunięto'), 'success'); load();
            });
        }

        function showForm() {
            const f = panel.querySelector('#sh-nfs-form');
            f.style.display = '';
            f.innerHTML = `<div style="border-top:1px solid var(--border);padding-top:10px;margin-top:8px">
                <h4 style="font-size:13px;margin-bottom:6px">${t('Nowy eksport NFS')}</h4>
                <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
                    <div style="display:flex;gap:0;align-items:center"><input type="text" id="sh-nf-p" class="fm-input" placeholder="${t('Ścieżka np. /home/media')}" style="width:200px;border-radius:6px 0 0 6px" readonly><button class="fm-toolbar-btn" id="sh-nf-browse" style="border-radius:0 6px 6px 0;margin-left:-1px" title="Przeglądaj"><i class="fas fa-folder-open"></i></button></div>
                    <input type="text" id="sh-nf-n" class="fm-input" placeholder="${t('Sieć np. 192.168.1.0/24 lub *')}" value="*" style="width:180px">
                    <button class="fm-toolbar-btn btn-green" id="sh-nf-ok"><i class="fas fa-save"></i></button>
                    <button class="fm-toolbar-btn" id="sh-nf-x"><i class="fas fa-times"></i></button>
                </div></div>`;
            panel.querySelector('#sh-nf-browse').onclick = () => openDirPicker('/home', t('Wybierz folder do eksportu'), p => { panel.querySelector('#sh-nf-p').value = p; });
            panel.querySelector('#sh-nf-ok').onclick = async () => {
                const p = panel.querySelector('#sh-nf-p').value.trim(), n = panel.querySelector('#sh-nf-n').value.trim();
                if (!p) { toast(t('Podaj ścieżkę'), 'warning'); return; }
                await api('/storage/nfs/export', { method: 'POST', body: { path: p, network: n } });
                toast(t('Dodano'), 'success'); f.style.display = 'none'; load();
            };
            panel.querySelector('#sh-nf-x').onclick = () => { f.style.display = 'none'; };
        }

        panel.querySelector('#sh-nfs-add').onclick = () => showForm();
        panel.querySelector('#sh-nfs-ref').onclick = () => load();
        load();
    }

    /* ══════════════════════════════════════════
       DLNA tab
       ══════════════════════════════════════════ */
    function renderDLNA(panel) {
        panel.innerHTML = `
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap">
            <span style="font-weight:600;font-size:15px"><i class="fas fa-photo-video" style="margin-right:6px;color:#6366f1"></i>DLNA / UPnP</span>
            <span id="sh-dlna-st"></span>
            <div style="flex:1"></div>
            <button class="fm-toolbar-btn" id="sh-dlna-rescan" title="${t('Reskan')}"><i class="fas fa-sync-alt"></i> ${t('Reskan')}</button>
            <button class="fm-toolbar-btn" id="sh-dlna-ref"><i class="fas fa-sync-alt"></i></button>
        </div>
        <p style="font-size:12px;color:var(--text-muted);margin-bottom:10px">${t('DLNA streamuje media (filmy, muzykę, zdjęcia) do Smart TV, konsol i innych urządzeń w sieci.')}</p>
        <div id="sh-dlna-cfg"></div>`;

        async function load() {
            try {
                const [status, config] = await Promise.all([api('/storage/dlna/status'), api('/storage/dlna/config').catch(() => ({ dirs: [], friendly_name: 'EthOS' }))]);
                panel.querySelector('#sh-dlna-st').innerHTML = _shBadge(status.running);
                renderCfg(config);
            } catch (e) { panel.querySelector('#sh-dlna-cfg').innerHTML = `<div style="color:#ef4444">${e.message}</div>`; }
        }

        function renderCfg(config) {
            const w = panel.querySelector('#sh-dlna-cfg');
            const dirs = config.dirs || [];
            w.innerHTML = `
            <div style="margin-bottom:10px">
                <label style="font-size:12px;font-weight:500">${t('Nazwa urządzenia')}:</label>
                <input type="text" id="sh-dlna-name" class="fm-input" value="${config.friendly_name || 'EthOS'}" style="width:200px;margin-left:8px">
            </div>
            <label style="font-size:12px;font-weight:500">${t('Katalogi z mediami')}:</label>
            <div id="sh-dlna-dirs" style="margin:6px 0">${dirs.map((d, i) => `<div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">
                <div style="display:flex;gap:0;align-items:center;flex:1"><input type="text" class="fm-input sh-dlna-dir" value="${d}" style="flex:1;border-radius:6px 0 0 6px" readonly><button class="fm-toolbar-btn sh-dlna-br" style="border-radius:0 6px 6px 0;margin-left:-1px" title="Przeglądaj"><i class="fas fa-folder-open"></i></button></div>
                <button class="fm-toolbar-btn btn-sm btn-red sh-dlna-rm" data-i="${i}"><i class="fas fa-minus"></i></button>
            </div>`).join('')}</div>
            <div style="display:flex;gap:8px;margin-top:8px">
                <button class="fm-toolbar-btn" id="sh-dlna-adddir"><i class="fas fa-plus"></i> ${t('Dodaj katalog')}</button>
                <button class="fm-toolbar-btn btn-green" id="sh-dlna-save"><i class="fas fa-save"></i> ${t('Zapisz')}</button>
            </div>`;

            function _dlnaBrowseBind(btn) {
                btn.onclick = () => {
                    const inp = btn.parentElement.querySelector('.sh-dlna-dir');
                    openDirPicker(inp.value || '/home', t('Wybierz katalog mediów'), p => { inp.value = p; });
                };
            }
            w.querySelectorAll('.sh-dlna-br').forEach(_dlnaBrowseBind);

            panel.querySelector('#sh-dlna-adddir').onclick = () => {
                const d = document.createElement('div');
                d.style.cssText = 'display:flex;align-items:center;gap:6px;margin-bottom:4px';
                d.innerHTML = `<div style="display:flex;gap:0;align-items:center;flex:1"><input type="text" class="fm-input sh-dlna-dir" placeholder="/home/media" style="flex:1;border-radius:6px 0 0 6px" readonly><button class="fm-toolbar-btn sh-dlna-br" style="border-radius:0 6px 6px 0;margin-left:-1px" title="Przeglądaj"><i class="fas fa-folder-open"></i></button></div><button class="fm-toolbar-btn btn-sm btn-red sh-dlna-rmx"><i class="fas fa-minus"></i></button>`;
                _dlnaBrowseBind(d.querySelector('.sh-dlna-br'));
                d.querySelector('.sh-dlna-rmx').onclick = () => d.remove();
                panel.querySelector('#sh-dlna-dirs').appendChild(d);
            };
            w.querySelectorAll('.sh-dlna-rm').forEach(b => b.onclick = () => b.parentElement.remove());
            panel.querySelector('#sh-dlna-save').onclick = async () => {
                const ds = [...panel.querySelectorAll('.sh-dlna-dir')].map(i => i.value.trim()).filter(Boolean);
                const name = panel.querySelector('#sh-dlna-name').value.trim() || 'EthOS';
                await api('/storage/dlna/config', { method: 'POST', body: { dirs: ds, friendly_name: name } });
                toast(t('Zapisano i zrestartowano DLNA'), 'success'); load();
            };
        }

        panel.querySelector('#sh-dlna-rescan').onclick = async () => { await api('/storage/dlna/rescan', { method: 'POST' }); toast(t('Reskan rozpoczęty'), 'success'); };
        panel.querySelector('#sh-dlna-ref').onclick = () => load();
        load();
    }

    /* ══════════════════════════════════════════
       WebDAV tab
       ══════════════════════════════════════════ */
    function renderWebDAV(panel) {
        panel.innerHTML = `
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap">
            <span style="font-weight:600;font-size:15px"><i class="fas fa-globe" style="margin-right:6px;color:#6366f1"></i>WebDAV</span>
            <span id="sh-dav-st"></span>
            <div style="flex:1"></div>
            <button class="fm-toolbar-btn btn-green" id="sh-dav-add"><i class="fas fa-plus"></i> ${t('Dodaj')}</button>
            <button class="fm-toolbar-btn" id="sh-dav-ref"><i class="fas fa-sync-alt"></i></button>
        </div>
        <p style="font-size:12px;color:var(--text-muted);margin-bottom:10px">${t('WebDAV — dostęp do plików przez HTTP. Działa z Windows Explorer, macOS Finder, i aplikacjami mobilnymi.')}</p>
        <div id="sh-dav-list"></div>
        <div id="sh-dav-form" style="display:none"></div>`;

        async function load() {
            try {
                const [status, shares] = await Promise.all([api('/storage/webdav/status'), api('/storage/webdav/shares').catch(() => ({ shares: [], port: 8888 }))]);
                panel.querySelector('#sh-dav-st').innerHTML = _shBadge(status.running, status.running ? `Port ${shares.port}` : null);
                renderList(shares.shares || [], shares.port);
            } catch (e) { panel.querySelector('#sh-dav-list').innerHTML = `<div style="color:#ef4444">${e.message}</div>`; }
        }

        function renderList(shares, port) {
            const w = panel.querySelector('#sh-dav-list');
            if (!shares.length) { w.innerHTML = `<div style="text-align:center;padding:20px;color:var(--text-muted)">${t('Brak udziałów WebDAV')}</div>`; return; }
            w.innerHTML = `<table style="width:100%;border-collapse:collapse;font-size:13px">
                <thead><tr style="border-bottom:1px solid var(--border);color:var(--text-muted);font-size:12px">
                    <th style="text-align:left;padding:6px">URL</th><th style="text-align:left;padding:6px">${t('Ścieżka')}</th><th></th>
                </tr></thead><tbody>${shares.map(s => `<tr style="border-bottom:1px solid var(--border)">
                    <td style="padding:6px;font-weight:500">:${port}${s.url_path}</td>
                    <td style="padding:6px;color:var(--text-muted);font-size:12px">${s.fs_path}</td>
                    <td style="text-align:right;padding:6px"><button class="fm-toolbar-btn btn-sm btn-red sh-davd" data-url="${s.url_path}"><i class="fas fa-trash"></i></button></td>
                </tr>`).join('')}</tbody></table>`;
            w.querySelectorAll('.sh-davd').forEach(b => b.onclick = async () => {
                if (!await confirmDialog(t('Usunąć udział WebDAV'), t('Usunąć udział WebDAV?'))) return;
                await api('/storage/webdav/share', { method: 'DELETE', body: { url_path: b.dataset.url } }); toast(t('Usunięto'), 'success'); load();
            });
        }

        function showForm() {
            const f = panel.querySelector('#sh-dav-form');
            f.style.display = '';
            f.innerHTML = `<div style="border-top:1px solid var(--border);padding-top:10px;margin-top:8px">
                <h4 style="font-size:13px;margin-bottom:6px">${t('Nowy udział WebDAV')}</h4>
                <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
                    <div style="display:flex;gap:0;align-items:center"><input type="text" id="sh-dv-p" class="fm-input" placeholder="${t('Ścieżka np. /home/share')}" style="width:200px;border-radius:6px 0 0 6px" readonly><button class="fm-toolbar-btn" id="sh-dv-browse" style="border-radius:0 6px 6px 0;margin-left:-1px" title="${t('Przeglądaj')}"><i class="fas fa-folder-open"></i></button></div>
                    <input type="text" id="sh-dv-u" class="fm-input" placeholder="${t('URL np. /share')}" style="width:140px">
                    <input type="text" id="sh-dv-un" class="fm-input" placeholder="${t('Login (opcja)')}" style="width:120px">
                    <input type="password" id="sh-dv-pw" class="fm-input" placeholder="${t('Hasło (opcja)')}" style="width:120px">
                    <button class="fm-toolbar-btn btn-green" id="sh-dv-ok"><i class="fas fa-save"></i></button>
                    <button class="fm-toolbar-btn" id="sh-dv-x"><i class="fas fa-times"></i></button>
                </div></div>`;
            panel.querySelector('#sh-dv-browse').onclick = () => openDirPicker('/home', t('Wybierz folder WebDAV'), p => { panel.querySelector('#sh-dv-p').value = p; });
            panel.querySelector('#sh-dv-ok').onclick = async () => {
                const p = panel.querySelector('#sh-dv-p').value.trim();
                if (!p) { toast(t('Podaj ścieżkę'), 'warning'); return; }
                await api('/storage/webdav/share', { method: 'POST', body: {
                    path: p,
                    url_path: panel.querySelector('#sh-dv-u').value.trim(),
                    username: panel.querySelector('#sh-dv-un').value.trim(),
                    password: panel.querySelector('#sh-dv-pw').value,
                }});
                toast(t('Dodano'), 'success'); f.style.display = 'none'; load();
            };
            panel.querySelector('#sh-dv-x').onclick = () => { f.style.display = 'none'; };
        }

        panel.querySelector('#sh-dav-add').onclick = () => showForm();
        panel.querySelector('#sh-dav-ref').onclick = () => load();
        load();
    }

    /* ══════════════════════════════════════════
       SFTP tab
       ══════════════════════════════════════════ */
    function renderSFTP(panel) {
        panel.innerHTML = `
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap">
            <span style="font-weight:600;font-size:15px"><i class="fas fa-lock" style="margin-right:6px;color:#6366f1"></i>SFTP</span>
            <span id="sh-sftp-st"></span>
            <div style="flex:1"></div>
            <button class="fm-toolbar-btn" id="sh-sftp-ref"><i class="fas fa-sync-alt"></i></button>
        </div>
        <p style="font-size:12px;color:var(--text-muted);margin-bottom:10px">${t('SFTP — bezpieczny transfer plików przez SSH. Szyfrowany, nie wymaga dodatkowych usług.')}</p>
        <div id="sh-sftp-toggle" style="margin-bottom:14px"></div>
        <div id="sh-sftp-users"></div>`;

        async function load() {
            try {
                const [status, users] = await Promise.all([api('/storage/sftp/status'), api('/storage/sftp/users')]);
                panel.querySelector('#sh-sftp-st').innerHTML = _shBadge(status.running && status.sftp_enabled);

                const toggleEl = panel.querySelector('#sh-sftp-toggle');
                toggleEl.innerHTML = `<label style="display:flex;align-items:center;gap:8px;cursor:pointer">
                    <input type="checkbox" id="sh-sftp-en" ${status.sftp_enabled ? 'checked' : ''}>
                    <span style="font-size:13px">${t('SFTP włączony')}</span>
                </label>`;
                panel.querySelector('#sh-sftp-en').onchange = async (e) => {
                    await api('/storage/sftp/toggle', { method: 'POST', body: { enable: e.target.checked } });
                    toast(e.target.checked ? t('SFTP włączony') : t('SFTP wyłączony'), 'success'); load();
                };

                const w = panel.querySelector('#sh-sftp-users');
                const ul = users.users || [];
                if (!ul.length) { w.innerHTML = `<div style="color:var(--text-muted)">${t('Brak użytkowników')}</div>`; return; }
                w.innerHTML = `<label style="font-size:12px;font-weight:500">${t('Użytkownicy z dostępem SFTP')}:</label>
                <table style="width:100%;border-collapse:collapse;font-size:13px;margin-top:6px">
                    <thead><tr style="border-bottom:1px solid var(--border);color:var(--text-muted);font-size:12px">
                        <th style="text-align:left;padding:6px">${t('Użytkownik')}</th><th style="text-align:left;padding:6px">${t('Katalog domowy')}</th>
                    </tr></thead><tbody>${ul.map(u => `<tr style="border-bottom:1px solid var(--border)">
                        <td style="padding:6px;font-weight:500">${u.username}</td>
                        <td style="padding:6px;color:var(--text-muted);font-size:12px">${u.home}</td>
                    </tr>`).join('')}</tbody></table>`;
            } catch (e) { panel.querySelector('#sh-sftp-users').innerHTML = `<div style="color:#ef4444">${e.message}</div>`; }
        }

        panel.querySelector('#sh-sftp-ref').onclick = () => load();
        load();
    }

    /* ══════════════════════════════════════════
       FTP tab
       ══════════════════════════════════════════ */
    function renderFTP(panel) {
        panel.innerHTML = `
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap">
            <span style="font-weight:600;font-size:15px"><i class="fas fa-upload" style="margin-right:6px;color:#6366f1"></i>FTP</span>
            <span id="sh-ftp-st"></span>
            <div style="flex:1"></div>
            <button class="fm-toolbar-btn" id="sh-ftp-ref"><i class="fas fa-sync-alt"></i></button>
        </div>
        <p style="font-size:12px;color:var(--text-muted);margin-bottom:10px">${t('FTP — klasyczny protokół transferu. Dla starszych urządzeń i kamer IP. Użyj SFTP jeśli możliwe.')}</p>
        <div id="sh-ftp-ctl"></div>`;

        async function load() {
            try {
                const status = await api('/storage/ftp/status');
                const el = panel.querySelector('#sh-ftp-st');
                const ctl = panel.querySelector('#sh-ftp-ctl');

                el.innerHTML = _shBadge(status.running);
                ctl.innerHTML = `<label style="display:flex;align-items:center;gap:8px;cursor:pointer">
                    <input type="checkbox" id="sh-ftp-en" ${status.running ? 'checked' : ''}>
                    <span style="font-size:13px">${t('Serwer FTP włączony')}</span>
                </label>
                <p style="font-size:12px;color:var(--text-muted);margin-top:8px">${t('Użytkownicy systemowi logują się do swoich katalogów domowych.')}</p>`;
                panel.querySelector('#sh-ftp-en').onchange = async (e) => {
                    await api('/storage/ftp/toggle', { method: 'POST', body: { enable: e.target.checked } });
                    toast(e.target.checked ? t('FTP włączony') : t('FTP wyłączony'), 'success'); load();
                };
            } catch (e) { panel.querySelector('#sh-ftp-ctl').innerHTML = `<div style="color:#ef4444">${e.message}</div>`; }
        }

        panel.querySelector('#sh-ftp-ref').onclick = () => load();
        load();
    }
}
